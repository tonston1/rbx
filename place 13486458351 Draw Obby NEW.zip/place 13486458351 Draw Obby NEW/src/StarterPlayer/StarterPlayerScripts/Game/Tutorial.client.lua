-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:32
-- Luau version 6, Types version 3
-- Time taken: 0.001126 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Button"))
local LocalPlayer = game:GetService("Players").LocalPlayer
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
local any_GetPlayerReplica_result1 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Profiles")):GetPlayerReplica(LocalPlayer)
if not any_GetPlayerReplica_result1 then
	any_GetPlayerReplica_result1 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Profiles")):WaitForPlayerReplica(LocalPlayer)
end
local any_new_result1_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Maid")).new()
if any_GetPlayerReplica_result1.Data.timesPlayed == 1 then
	local Draw = PlayerGui:WaitForChild("MainUI").Buttons.Draw
	module_upvr:Highlight(Draw)
	module_upvr:Arrow(Draw)
	local Play_upvr = PlayerGui:WaitForChild("DrawUI").Buttons.Play
	any_new_result1_upvr.connection = require(ReplicatedStorage.Libraries.Game.Draw).Started:Connect(function() -- Line 28
		--[[ Upvalues[3]:
			[1]: module_upvr (readonly)
			[2]: Play_upvr (readonly)
			[3]: any_new_result1_upvr (readonly)
		]]
		module_upvr:Highlight(Play_upvr)
		module_upvr:Arrow(Play_upvr)
		any_new_result1_upvr.connection = nil
	end)
end