-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:26
-- Luau version 6, Types version 3
-- Time taken: 0.001021 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local LocalPlayer = game:GetService("Players").LocalPlayer
local any_GetPlayerReplica_result1_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Profiles")):GetPlayerReplica(LocalPlayer)
if not any_GetPlayerReplica_result1_upvr then
	any_GetPlayerReplica_result1_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Profiles")):WaitForPlayerReplica(LocalPlayer)
end
local Draw_upvr = require(ReplicatedStorage.Libraries.Game.Draw)
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Button"))
return function(arg1) -- Line 15
	--[[ Upvalues[3]:
		[1]: Draw_upvr (readonly)
		[2]: any_GetPlayerReplica_result1_upvr (readonly)
		[3]: module_upvr (readonly)
	]]
	Draw_upvr:Enable()
	if any_GetPlayerReplica_result1_upvr.Data.timesPlayed == 1 and any_GetPlayerReplica_result1_upvr.Data.stage == 1 then
		module_upvr:StopHighlight(arg1)
		module_upvr:StopArrow(arg1)
		Draw_upvr:Hint({{0.4, -1}, {0.6, -1}})
	end
end