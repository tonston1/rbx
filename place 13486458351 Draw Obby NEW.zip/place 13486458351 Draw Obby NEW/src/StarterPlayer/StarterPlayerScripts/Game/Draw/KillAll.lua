-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:30
-- Luau version 6, Types version 3
-- Time taken: 0.000502 seconds

local module_upvr = require(game:GetService("ReplicatedStorage"):WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Sales"))
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local MarketplaceService_upvr = game:GetService("MarketplaceService")
return function(arg1) -- Line 13
	--[[ Upvalues[3]:
		[1]: module_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: MarketplaceService_upvr (readonly)
	]]
	module_upvr:Set(LocalPlayer_upvr, 1585079578, true)
	MarketplaceService_upvr:PromptProductPurchase(LocalPlayer_upvr, 1585079578)
end