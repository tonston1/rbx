-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:25
-- Luau version 6, Types version 3
-- Time taken: 0.005436 seconds

-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Draw_upvr = require(ReplicatedStorage.Libraries.Game.Draw)
local module_upvr_3 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Button"))
local module = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Profiles"))
local MarketplaceService_upvr = game:GetService("MarketplaceService")
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Sales"))
local module_upvr_2 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Gamepasses"))
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local Stage_upvr = LocalPlayer_upvr:WaitForChild("leaderstats"):WaitForChild("Stage")
local PlayerGui = LocalPlayer_upvr:WaitForChild("PlayerGui")
local DrawUI_upvr = PlayerGui:WaitForChild("DrawUI")
local MainUI_upvr = PlayerGui:WaitForChild("MainUI")
local any_GetPlayerReplica_result1_upvr = module:GetPlayerReplica(LocalPlayer_upvr)
if not any_GetPlayerReplica_result1_upvr then
	any_GetPlayerReplica_result1_upvr = module:WaitForPlayerReplica(LocalPlayer_upvr)
end
local tbl_3_upvr = {"Hint"}
Draw_upvr:Load(Stage_upvr.Value)
Stage_upvr:GetPropertyChangedSignal("Value"):Connect(function() -- Line 35, Named "setStage"
	--[[ Upvalues[2]:
		[1]: Draw_upvr (readonly)
		[2]: Stage_upvr (readonly)
	]]
	Draw_upvr:Load(Stage_upvr.Value)
end)
for _, v_upvr in ipairs({MainUI_upvr.KillAll, MainUI_upvr.Buttons.Draw, MainUI_upvr.Buttons.Skip, DrawUI_upvr.Buttons.Play, DrawUI_upvr.Buttons.Clear, DrawUI_upvr.Buttons.Hint}) do
	local Button = v_upvr:FindFirstChild("Button")
	Button.MouseButton1Down:Connect(function() -- Line 48
		--[[ Upvalues[2]:
			[1]: module_upvr_3 (readonly)
			[2]: v_upvr (readonly)
		]]
		module_upvr_3:Press(v_upvr, true)
	end)
	local Name_upvr = v_upvr.Name
	Button.MouseButton1Up:Connect(function() -- Line 52
		--[[ Upvalues[3]:
			[1]: Name_upvr (readonly)
			[2]: module_upvr_3 (readonly)
			[3]: v_upvr (readonly)
		]]
		local SOME = script:FindFirstChild(Name_upvr)
		if not SOME then
		elseif module_upvr_3:GetPressing(v_upvr) then
			module_upvr_3:Release(v_upvr, true)
			module_upvr_3:Shine()
			require(SOME)(v_upvr)
		end
	end)
	Button.MouseEnter:Connect(function() -- Line 64
		--[[ Upvalues[2]:
			[1]: module_upvr_3 (readonly)
			[2]: v_upvr (readonly)
		]]
		module_upvr_3:Hover(v_upvr, true)
	end)
	Button.MouseLeave:Connect(function() -- Line 68
		--[[ Upvalues[2]:
			[1]: module_upvr_3 (readonly)
			[2]: v_upvr (readonly)
		]]
		module_upvr_3:Release(v_upvr, true)
	end)
end
module:GetReplica("Game"):ConnectOnClientEvent(function(arg1, ...) -- Line 74
	--[[ Upvalues[2]:
		[1]: tbl_3_upvr (readonly)
		[2]: Draw_upvr (readonly)
	]]
	if not table.find(tbl_3_upvr, arg1) then
	else
		Draw_upvr:Hint(({...})[1])
	end
end)
Name_upvr = ')'
DrawUI_upvr.Buttons.Hint.Content.Label.Text = "Hints("..any_GetPlayerReplica_result1_upvr.Data.hints..Name_upvr
any_GetPlayerReplica_result1_upvr:ListenToWrite("Hint", function() -- Line 84, Named "updateHints"
	--[[ Upvalues[2]:
		[1]: DrawUI_upvr (readonly)
		[2]: any_GetPlayerReplica_result1_upvr (readonly)
	]]
	DrawUI_upvr.Buttons.Hint.Content.Label.Text = "Hints("..any_GetPlayerReplica_result1_upvr.Data.hints..')'
end)
Name_upvr = MainUI_upvr.Buttons
Name_upvr = any_GetPlayerReplica_result1_upvr.Data.skips
Name_upvr.Skip.Content.Label.Text = "Skips("..Name_upvr..')'
function Name_upvr() -- Line 93, Named "updateSkips"
	--[[ Upvalues[2]:
		[1]: MainUI_upvr (readonly)
		[2]: any_GetPlayerReplica_result1_upvr (readonly)
	]]
	MainUI_upvr.Buttons.Skip.Content.Label.Text = "Skips("..any_GetPlayerReplica_result1_upvr.Data.skips..')'
end
any_GetPlayerReplica_result1_upvr:ListenToWrite("Skip", Name_upvr)
Name_upvr = DrawUI_upvr.Buttons
local tbl_2 = {}
Name_upvr = {}
local var48 = Name_upvr
var48.Start = 1
var48.End = 6
var48.Increment = 0.2
var48.DefaultValue = 2
tbl_2.SliderData = var48
var48 = TweenInfo.new(0.1, Enum.EasingStyle.Quad)
tbl_2.MoveInfo = var48
local any_new_result1 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Slider")).new(Name_upvr.Scale.Holder, tbl_2)
function var48(arg1) -- Line 108
	--[[ Upvalues[4]:
		[1]: DrawUI_upvr (readonly)
		[2]: module_upvr_2 (readonly)
		[3]: LocalPlayer_upvr (readonly)
		[4]: Draw_upvr (readonly)
	]]
	DrawUI_upvr.Buttons.Scale.Label.Text = "Brush size: "..arg1
	if module_upvr_2:Owns(LocalPlayer_upvr, 185566439) then
		Draw_upvr:SetDiameter(arg1)
	end
end
any_new_result1.Changed:Connect(var48)
any_new_result1:Track()
var48 = DrawUI_upvr.Buttons.Scale.Holder
function var48() -- Line 120
	--[[ Upvalues[4]:
		[1]: module_upvr_2 (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: module_upvr (readonly)
		[4]: MarketplaceService_upvr (readonly)
	]]
	if not module_upvr_2:Owns(LocalPlayer_upvr, 185566439) then
		module_upvr:Set(LocalPlayer_upvr, 185566439, true)
		MarketplaceService_upvr:PromptGamePassPurchase(LocalPlayer_upvr, 185566439)
	end
end
var48.Slider.MouseButton1Down:Connect(var48)
local tbl = {}
var48 = DrawUI_upvr.Buttons.Shapes
var48 = DrawUI_upvr.Buttons.Shapes.Truss
tbl[1] = var48.Circle
tbl[2] = var48
tbl[3] = DrawUI_upvr.Buttons.Shapes.Square
var48 = tbl
for _, v_2_upvr in ipairs(var48) do
	v_2_upvr.Activated:Connect(function() -- Line 136
		--[[ Upvalues[6]:
			[1]: module_upvr_2 (readonly)
			[2]: LocalPlayer_upvr (readonly)
			[3]: Draw_upvr (readonly)
			[4]: v_2_upvr (readonly)
			[5]: module_upvr (readonly)
			[6]: MarketplaceService_upvr (readonly)
		]]
		if module_upvr_2:Owns(LocalPlayer_upvr, 185566597) then
			Draw_upvr:SetShape(v_2_upvr.Name)
		else
			module_upvr:Set(LocalPlayer_upvr, 185566597, true)
			MarketplaceService_upvr:PromptGamePassPurchase(LocalPlayer_upvr, 185566597)
		end
	end)
end
any_GetPlayerReplica_result1_upvr:ListenToWrite("Stage", function() -- Line 147
	--[[ Upvalues[4]:
		[1]: any_GetPlayerReplica_result1_upvr (readonly)
		[2]: module_upvr_2 (readonly)
		[3]: LocalPlayer_upvr (readonly)
		[4]: DrawUI_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [30] 23. Error Block 5 start (CF ANALYSIS FAILED)
	DrawUI_upvr.Buttons.Shapes.Visible = false
	do
		return
	end
	-- KONSTANTERROR: [30] 23. Error Block 5 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [39] 29. Error Block 6 start (CF ANALYSIS FAILED)
	DrawUI_upvr.Buttons.Shapes.Visible = true
	DrawUI_upvr.Buttons.Scale.Visible = true
	-- KONSTANTERROR: [39] 29. Error Block 6 end (CF ANALYSIS FAILED)
end)