-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:29
-- Luau version 6, Types version 3
-- Time taken: 0.001472 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local module = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Profiles"))
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local any_GetPlayerReplica_result1_upvr = module:GetPlayerReplica(LocalPlayer_upvr)
if not any_GetPlayerReplica_result1_upvr then
	any_GetPlayerReplica_result1_upvr = module:WaitForPlayerReplica(LocalPlayer_upvr)
end
local any_GetReplica_result1_upvr = module:GetReplica("Game")
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Sales"))
local MarketplaceService_upvr = game:GetService("MarketplaceService")
return function(arg1) -- Line 15
	--[[ Upvalues[5]:
		[1]: any_GetPlayerReplica_result1_upvr (readonly)
		[2]: any_GetReplica_result1_upvr (readonly)
		[3]: module_upvr (readonly)
		[4]: LocalPlayer_upvr (readonly)
		[5]: MarketplaceService_upvr (readonly)
	]]
	if 0 < any_GetPlayerReplica_result1_upvr.Data.hints then
		any_GetReplica_result1_upvr:FireServer("Hint")
	else
		module_upvr:Set(LocalPlayer_upvr, 1556898125, true)
		MarketplaceService_upvr:PromptProductPurchase(LocalPlayer_upvr, 1556898125)
	end
end