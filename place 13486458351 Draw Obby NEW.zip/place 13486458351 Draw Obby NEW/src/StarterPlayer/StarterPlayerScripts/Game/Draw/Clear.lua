-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:29
-- Luau version 6, Types version 3
-- Time taken: 0.000402 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Draw_upvr = require(ReplicatedStorage.Libraries.Game.Draw)
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Button"))
return function(arg1) -- Line 6
	--[[ Upvalues[2]:
		[1]: Draw_upvr (readonly)
		[2]: module_upvr (readonly)
	]]
	Draw_upvr:Clear()
	module_upvr:StopHighlight(arg1)
end