-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:31
-- Luau version 6, Types version 3
-- Time taken: 0.001233 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Checkpoint_upvr = require(ReplicatedStorage.Libraries.Game.Checkpoint)
local LocalPlayer = game:GetService("Players").LocalPlayer
local any_GetPlayerReplica_result1_upvr = require(ReplicatedStorage.Libraries.Modules.Profiles):GetPlayerReplica(LocalPlayer)
if not any_GetPlayerReplica_result1_upvr then
	any_GetPlayerReplica_result1_upvr = require(ReplicatedStorage.Libraries.Modules.Profiles):WaitForPlayerReplica(LocalPlayer)
end
Checkpoint_upvr:Init(any_GetPlayerReplica_result1_upvr.Data.stage)
local len_upvr = #workspace:WaitForChild("Stages"):GetChildren()
local TweenService_upvr = game:GetService("TweenService")
local Progress_upvr = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("Progress")
local function updateStage() -- Line 22
	--[[ Upvalues[4]:
		[1]: any_GetPlayerReplica_result1_upvr (readonly)
		[2]: len_upvr (readonly)
		[3]: TweenService_upvr (readonly)
		[4]: Progress_upvr (readonly)
	]]
	local var9 = any_GetPlayerReplica_result1_upvr.Data.stage / len_upvr
	TweenService_upvr:Create(Progress_upvr.Percent, TweenInfo.new(0.3), {
		Size = UDim2.new(0.987 * var9, 0, 0.764, 0);
	}):Play()
	Progress_upvr.Label.Text = "stage "..any_GetPlayerReplica_result1_upvr.Data.stage..'/'..len_upvr.." ("..math.ceil(var9 * 100).."%)"
end
updateStage()
any_GetPlayerReplica_result1_upvr:ListenToWrite("Stage", updateStage)
any_GetPlayerReplica_result1_upvr:ListenToWrite("Stage", function() -- Line 33
	--[[ Upvalues[2]:
		[1]: Checkpoint_upvr (readonly)
		[2]: any_GetPlayerReplica_result1_upvr (readonly)
	]]
	Checkpoint_upvr:Reward()
	Checkpoint_upvr:Set(any_GetPlayerReplica_result1_upvr.Data.stage)
end)