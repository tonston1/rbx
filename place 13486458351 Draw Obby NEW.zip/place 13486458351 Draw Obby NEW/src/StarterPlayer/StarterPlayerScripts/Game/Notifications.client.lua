-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:24
-- Luau version 6, Types version 3
-- Time taken: 0.000719 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local tbl_upvr = {"Notification"}
local Notification_upvr = require(ReplicatedStorage.Libraries.Classes.Notification)
local EffectUI_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("EffectUI")
require(ReplicatedStorage.Libraries.Modules.Profiles):GetReplica("Game"):ConnectOnClientEvent(function(arg1, ...) -- Line 17
	--[[ Upvalues[3]:
		[1]: tbl_upvr (readonly)
		[2]: Notification_upvr (readonly)
		[3]: EffectUI_upvr (readonly)
	]]
	if not table.find(tbl_upvr, arg1) then
	else
		local args_list = {...}
		local _2_upvr = args_list[2]
		local _1_upvr = args_list[1]
		task.spawn(function() -- Line 24
			--[[ Upvalues[4]:
				[1]: Notification_upvr (copied, readonly)
				[2]: EffectUI_upvr (copied, readonly)
				[3]: _2_upvr (readonly)
				[4]: _1_upvr (readonly)
			]]
			Notification_upvr.new("Notification", EffectUI_upvr.List, _2_upvr, _1_upvr)
		end)
	end
end)