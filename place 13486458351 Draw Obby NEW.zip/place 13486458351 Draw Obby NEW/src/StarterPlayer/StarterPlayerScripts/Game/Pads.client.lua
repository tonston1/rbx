-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:35
-- Luau version 6, Types version 3
-- Time taken: 0.001745 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players_upvr = game:GetService("Players")
for _, v in ipairs(workspace:WaitForChild("Pads"):GetChildren()) do
	for _, v_2 in ipairs(v:GetChildren()) do
		local tonumber_result1_upvr = tonumber(v_2.Name)
		if tonumber_result1_upvr then
			local LocalPlayer_upvr = Players_upvr.LocalPlayer
			local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Sales"))
			local module_upvr_2 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Gamepasses"))
			local MarketplaceService_upvr = game:GetService("MarketplaceService")
			v_2:FindFirstChild("Pad").Touched:Connect(function(arg1) -- Line 24
				--[[ Upvalues[6]:
					[1]: Players_upvr (readonly)
					[2]: LocalPlayer_upvr (readonly)
					[3]: module_upvr (readonly)
					[4]: module_upvr_2 (readonly)
					[5]: tonumber_result1_upvr (readonly)
					[6]: MarketplaceService_upvr (readonly)
				]]
				local var19
				if var19 then
					var19 = arg1.Parent
				end
				local any_GetPlayerFromCharacter_result1 = Players_upvr:GetPlayerFromCharacter(var19)
				if any_GetPlayerFromCharacter_result1 and any_GetPlayerFromCharacter_result1 == LocalPlayer_upvr and not module_upvr.active[tostring(LocalPlayer_upvr.UserId)] and not module_upvr_2:Owns(LocalPlayer_upvr, tonumber_result1_upvr) then
					module_upvr:Set(LocalPlayer_upvr, tonumber_result1_upvr, true)
					MarketplaceService_upvr:PromptGamePassPurchase(LocalPlayer_upvr, tonumber_result1_upvr)
				end
			end)
		end
	end
end