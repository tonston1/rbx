-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:34
-- Luau version 6, Types version 3
-- Time taken: 0.001616 seconds

local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local Backpack_upvr = LocalPlayer_upvr:WaitForChild("PlayerGui"):WaitForChild("MainUI").Buttons.Backpack
local var7_upvw
local module_upvr = require(game:GetService("ReplicatedStorage"):WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Gamepasses"))
local MarketplaceService_upvr = game:GetService("MarketplaceService")
local function equip_upvr(arg1, arg2) -- Line 24, Named "equip"
	--[[ Upvalues[5]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: Backpack_upvr (readonly)
		[3]: var7_upvw (read and write)
		[4]: module_upvr (readonly)
		[5]: MarketplaceService_upvr (readonly)
	]]
	if arg2 == Enum.UserInputState.Begin then
		local SOME = LocalPlayer_upvr.Backpack:FindFirstChild(arg1)
		local SOME_2 = Backpack_upvr:FindFirstChild(arg1)
		if var7_upvw then
			var7_upvw.Content.ImageColor3 = Color3.fromRGB(255, 255, 255)
			var7_upvw = nil
		end
		if SOME then
			LocalPlayer_upvr.Character.Humanoid:EquipTool(SOME)
			SOME_2.Content.ImageColor3 = Color3.fromRGB(220, 220, 220)
			var7_upvw = SOME_2
			return
		end
		LocalPlayer_upvr.Character.Humanoid:UnequipTools()
		local GamepassId = Backpack_upvr[arg1]:GetAttribute("GamepassId")
		if not module_upvr:Owns(LocalPlayer_upvr, GamepassId) then
			MarketplaceService_upvr:PromptGamePassPurchase(LocalPlayer_upvr, GamepassId)
		end
	end
end
for _, v_upvr in ipairs(Backpack_upvr:GetChildren()) do
	if v_upvr:FindFirstChild("Button") then
		v_upvr.Button.Activated:Connect(function() -- Line 54
			--[[ Upvalues[2]:
				[1]: equip_upvr (readonly)
				[2]: v_upvr (readonly)
			]]
			equip_upvr(v_upvr.Name, Enum.UserInputState.Begin)
		end)
		game:GetService("ContextActionService"):BindAction(v_upvr.Name, equip_upvr, false, ({Enum.KeyCode.One, Enum.KeyCode.Two, Enum.KeyCode.Three})[v_upvr.LayoutOrder])
	end
end
LocalPlayer_upvr.CharacterAdded:Connect(function() -- Line 62
	--[[ Upvalues[2]:
		[1]: var7_upvw (read and write)
		[2]: Backpack_upvr (readonly)
	]]
	if var7_upvw then
		var7_upvw.Content.ImageColor3 = Color3.fromRGB(255, 255, 255)
		var7_upvw = nil
	end
	for _, v_2 in ipairs(Backpack_upvr:GetChildren()) do
		if v_2:FindFirstChild("Cooldown") then
			v_2.Cooldown.Visible = false
		end
	end
end)