-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:36
-- Luau version 6, Types version 3
-- Time taken: 0.002654 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Button"))
local TweenService_upvr = game:GetService("TweenService")
local module_upvr_2 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("SoundEffect"))
local module_upvr_3 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Menu"))
for _, v in ipairs(game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):GetChildren()) do
	local Exit = v:FindFirstChild("Exit", true)
	if Exit and Exit:IsA("Frame") then
		(function(arg1) -- Line 13, Named "exitButton"
			--[[ Upvalues[4]:
				[1]: module_upvr (readonly)
				[2]: TweenService_upvr (readonly)
				[3]: module_upvr_2 (readonly)
				[4]: module_upvr_3 (readonly)
			]]
			local Button = arg1:FindFirstChild("Button")
			local Content_upvr = arg1:FindFirstChild("Content")
			Button.MouseButton1Down:Connect(function() -- Line 17
				--[[ Upvalues[4]:
					[1]: module_upvr (copied, readonly)
					[2]: arg1 (readonly)
					[3]: TweenService_upvr (copied, readonly)
					[4]: Content_upvr (readonly)
				]]
				module_upvr:Press(arg1, 0.8)
				TweenService_upvr:Create(Content_upvr, TweenInfo.new(0.1), {
					Size = UDim2.new(0.7, 0, 0.7, 0);
				}):Play()
			end)
			Button.MouseButton1Up:Connect(function() -- Line 24
				--[[ Upvalues[6]:
					[1]: module_upvr (copied, readonly)
					[2]: arg1 (readonly)
					[3]: module_upvr_2 (copied, readonly)
					[4]: module_upvr_3 (copied, readonly)
					[5]: TweenService_upvr (copied, readonly)
					[6]: Content_upvr (readonly)
				]]
				if module_upvr:GetPressing(arg1) then
					module_upvr:Release(arg1)
					module_upvr:Shine()
					module_upvr_2.new("Menu"):Play()
					module_upvr_3:Close(true)
					TweenService_upvr:Create(Content_upvr, TweenInfo.new(0.2), {
						Size = UDim2.new(1, 0, 1, 0);
					}):Play()
				end
			end)
			Button.MouseEnter:Connect(function() -- Line 36
				--[[ Upvalues[5]:
					[1]: module_upvr (copied, readonly)
					[2]: arg1 (readonly)
					[3]: module_upvr_2 (copied, readonly)
					[4]: TweenService_upvr (copied, readonly)
					[5]: Content_upvr (readonly)
				]]
				module_upvr:Hover(arg1)
				module_upvr_2.new("Hover"):Play()
				TweenService_upvr:Create(Content_upvr, TweenInfo.new(0.12), {
					Size = UDim2.new(1.1, 0, 1.1, 0);
				}):Play()
			end)
			Button.MouseLeave:Connect(function() -- Line 44
				--[[ Upvalues[4]:
					[1]: TweenService_upvr (copied, readonly)
					[2]: Content_upvr (readonly)
					[3]: module_upvr (copied, readonly)
					[4]: arg1 (readonly)
				]]
				TweenService_upvr:Create(Content_upvr, TweenInfo.new(0.2), {
					Size = UDim2.new(1, 0, 1, 0);
				}):Play()
				module_upvr:Release(arg1)
			end)
		end)(Exit)
	end
end