-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:40
-- Luau version 6, Types version 3
-- Time taken: 0.000588 seconds

local SocialService_upvr = game:GetService("SocialService")
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
return function(arg1) -- Line 11
	--[[ Upvalues[2]:
		[1]: SocialService_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
	]]
	local pcall_result1, pcall_result2 = pcall(function() -- Line 12
		--[[ Upvalues[2]:
			[1]: SocialService_upvr (copied, readonly)
			[2]: LocalPlayer_upvr (copied, readonly)
		]]
		return SocialService_upvr:CanSendGameInviteAsync(LocalPlayer_upvr)
	end)
	if pcall_result1 and pcall_result2 then
		return pcall(function() -- Line 17
			--[[ Upvalues[2]:
				[1]: SocialService_upvr (copied, readonly)
				[2]: LocalPlayer_upvr (copied, readonly)
			]]
			SocialService_upvr:PromptGameInvite(LocalPlayer_upvr)
		end)
	end
end