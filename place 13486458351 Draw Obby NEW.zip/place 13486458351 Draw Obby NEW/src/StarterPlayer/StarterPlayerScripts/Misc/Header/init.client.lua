-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:38
-- Luau version 6, Types version 3
-- Time taken: 0.001279 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Button_upvr = require(ReplicatedStorage.Libraries.Modules.Button)
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("SoundEffect"))
local MainUI = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
for _, v_upvr in ipairs({MainUI.Games, MainUI.Invite, MainUI.Mute}) do
	v_upvr.MouseButton1Down:Connect(function() -- Line 20
		--[[ Upvalues[2]:
			[1]: Button_upvr (readonly)
			[2]: v_upvr (readonly)
		]]
		Button_upvr:Press(v_upvr, false)
	end)
	v_upvr.MouseButton1Up:Connect(function() -- Line 24
		--[[ Upvalues[3]:
			[1]: Button_upvr (readonly)
			[2]: v_upvr (readonly)
			[3]: module_upvr (readonly)
		]]
		if Button_upvr:GetPressing(v_upvr) then
			module_upvr.new("Menu"):Play()
			Button_upvr:Release(v_upvr, false)
			Button_upvr:Shine()
			require(script:FindFirstChild(v_upvr.Name))(v_upvr)
		end
	end)
	v_upvr.MouseEnter:Connect(function() -- Line 34
		--[[ Upvalues[3]:
			[1]: module_upvr (readonly)
			[2]: Button_upvr (readonly)
			[3]: v_upvr (readonly)
		]]
		module_upvr.new("Hover"):Play()
		Button_upvr:Hover(v_upvr, false)
	end)
	v_upvr.MouseLeave:Connect(function() -- Line 39
		--[[ Upvalues[2]:
			[1]: Button_upvr (readonly)
			[2]: v_upvr (readonly)
		]]
		Button_upvr:Release(v_upvr, false)
	end)
end