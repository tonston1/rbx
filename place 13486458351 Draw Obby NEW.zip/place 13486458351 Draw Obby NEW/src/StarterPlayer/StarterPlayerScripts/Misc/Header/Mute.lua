-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:39
-- Luau version 6, Types version 3
-- Time taken: 0.000637 seconds

local tbl_upvr = {
	[true] = "rbxassetid://13399838236";
	[false] = "rbxassetid://13399839673";
}
local var3_upvw = true
local TweenService_upvr = game:GetService("TweenService")
local Music_upvr = game:GetService("SoundService"):WaitForChild("Music")
return function(arg1) -- Line 18
	--[[ Upvalues[4]:
		[1]: var3_upvw (read and write)
		[2]: tbl_upvr (readonly)
		[3]: TweenService_upvr (readonly)
		[4]: Music_upvr (readonly)
	]]
	local var6
	if var3_upvw then
		var6 = 0
	else
		var6 = 0.5
	end
	var3_upvw = not var3_upvw
	arg1.Icon.Image = tbl_upvr[var3_upvw]
	TweenService_upvr:Create(Music_upvr, TweenInfo.new(0.3), {
		Volume = var6;
	}):Play()
end