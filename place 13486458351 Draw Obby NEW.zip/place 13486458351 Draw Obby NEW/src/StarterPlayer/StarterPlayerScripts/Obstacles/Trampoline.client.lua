-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:22
-- Luau version 6, Types version 3
-- Time taken: 0.003326 seconds

local CollectionService = game:GetService("CollectionService")
local Players_upvr = game:GetService("Players")
local module_upvr = require(game:GetService("ReplicatedStorage"):WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("SoundEffect"))
local TweenService_upvr = game:GetService("TweenService")
local StarterPlayer_upvr = game:GetService("StarterPlayer")
local LocalPlayer_upvr = Players_upvr.LocalPlayer
CollectionService:GetInstanceAddedSignal("Trampoline"):Connect(function(arg1) -- Line 18, Named "tagTrampoline"
	--[[ Upvalues[5]:
		[1]: Players_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
		[3]: TweenService_upvr (readonly)
		[4]: module_upvr (readonly)
		[5]: StarterPlayer_upvr (readonly)
	]]
	local var13_upvw = true
	local Size_upvr_2 = arg1:WaitForChild("Visual").Value.Size
	arg1.Touched:Connect(function(arg1_2) -- Line 22
		--[[ Upvalues[8]:
			[1]: var13_upvw (read and write)
			[2]: Players_upvr (copied, readonly)
			[3]: LocalPlayer_upvr (copied, readonly)
			[4]: TweenService_upvr (copied, readonly)
			[5]: arg1 (readonly)
			[6]: Size_upvr_2 (readonly)
			[7]: module_upvr (copied, readonly)
			[8]: StarterPlayer_upvr (copied, readonly)
		]]
		-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
		local var15
		if not var13_upvw then
		else
			local Parent = arg1_2.Parent
			if Parent then
				var15 = "Humanoid"
				local SOME_2 = Parent:FindFirstChild(var15)
			end
			if Players_upvr:GetPlayerFromCharacter(Parent) ~= LocalPlayer_upvr then
				var15 = false
			else
				var15 = true
			end
			if var15 and SOME_2 then
				var13_upvw = false
				TweenService_upvr:Create(arg1.Visual.Value, TweenInfo.new(0.1), {
					Size = Size_upvr_2 * 0.7;
				}):Play()
				task.wait(0.1)
				SOME_2.JumpHeight = arg1:GetAttribute("Jump") or 50
				SOME_2:ChangeState(Enum.HumanoidStateType.Jumping)
				SOME_2.StateChanged:Wait()
				task.wait(0.05)
				module_upvr.new("Bounce", arg1.Position):Play()
				TweenService_upvr:Create(arg1.Visual.Value, TweenInfo.new(0.5, Enum.EasingStyle.Elastic), {
					Size = Size_upvr_2;
				}):Play()
				SOME_2.JumpHeight = StarterPlayer_upvr.CharacterJumpHeight
				var13_upvw = true
			end
		end
	end)
end)
for _, v_upvr in ipairs(CollectionService:GetTagged("Trampoline")) do
	local var24_upvw = true
	local Size_upvr = v_upvr:WaitForChild("Visual").Value.Size
	v_upvr.Touched:Connect(function(arg1) -- Line 22
		--[[ Upvalues[8]:
			[1]: var24_upvw (read and write)
			[2]: Players_upvr (readonly)
			[3]: LocalPlayer_upvr (readonly)
			[4]: TweenService_upvr (readonly)
			[5]: v_upvr (readonly)
			[6]: Size_upvr (readonly)
			[7]: module_upvr (readonly)
			[8]: StarterPlayer_upvr (readonly)
		]]
		-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
		local var26
		if not var24_upvw then
		else
			local Parent_2 = arg1.Parent
			if Parent_2 then
				var26 = "Humanoid"
				local SOME = Parent_2:FindFirstChild(var26)
			end
			if Players_upvr:GetPlayerFromCharacter(Parent_2) ~= LocalPlayer_upvr then
				var26 = false
			else
				var26 = true
			end
			if var26 and SOME then
				var24_upvw = false
				TweenService_upvr:Create(v_upvr.Visual.Value, TweenInfo.new(0.1), {
					Size = Size_upvr * 0.7;
				}):Play()
				task.wait(0.1)
				SOME.JumpHeight = v_upvr:GetAttribute("Jump") or 50
				SOME:ChangeState(Enum.HumanoidStateType.Jumping)
				SOME.StateChanged:Wait()
				task.wait(0.05)
				module_upvr.new("Bounce", v_upvr.Position):Play()
				TweenService_upvr:Create(v_upvr.Visual.Value, TweenInfo.new(0.5, Enum.EasingStyle.Elastic), {
					Size = Size_upvr;
				}):Play()
				SOME.JumpHeight = StarterPlayer_upvr.CharacterJumpHeight
				var24_upvw = true
			end
		end
	end)
end