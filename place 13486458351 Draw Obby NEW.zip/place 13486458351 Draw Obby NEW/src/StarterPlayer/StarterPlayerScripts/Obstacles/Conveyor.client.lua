-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:22
-- Luau version 6, Types version 3
-- Time taken: 0.000506 seconds

local CollectionService = game:GetService("CollectionService")
CollectionService:GetInstanceAddedSignal("Conveyor"):Connect(function(arg1) -- Line 5, Named "tagConveyor"
	arg1.Velocity = (arg1:GetAttribute("Speed") or 20) * arg1.CFrame.LookVector
end)
for _, v in ipairs(CollectionService:GetTagged("Conveyor")) do
	v.Velocity = (v:GetAttribute("Speed") or 20) * v.CFrame.LookVector
end