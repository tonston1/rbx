-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:21
-- Luau version 6, Types version 3
-- Time taken: 0.001602 seconds

local CollectionService = game:GetService("CollectionService")
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
CollectionService:GetInstanceAddedSignal("Lava"):Connect(function(arg1) -- Line 8, Named "tagLava"
	--[[ Upvalues[1]:
		[1]: LocalPlayer_upvr (readonly)
	]]
	if arg1:IsA("BasePart") then
		arg1.Touched:Connect(function(arg1_2) -- Line 10
			--[[ Upvalues[1]:
				[1]: LocalPlayer_upvr (copied, readonly)
			]]
			-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
			local var6 = arg1_2
			if var6 then
				var6 = arg1_2.Parent
			end
			if var6 then
			end
			if var6 then
				local Humanoid = var6:FindFirstChild("Humanoid")
			end
			if Humanoid and 0 < Humanoid.Health and game.Players:GetPlayerFromCharacter(var6) == LocalPlayer_upvr then
				var6.Humanoid.Health = 0
			end
		end)
	end
end)
for _, v in ipairs(CollectionService:GetTagged("Lava")) do
	if v:IsA("BasePart") then
		v.Touched:Connect(function(arg1) -- Line 10
			--[[ Upvalues[1]:
				[1]: LocalPlayer_upvr (readonly)
			]]
			-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
			local var12 = arg1
			if var12 then
				var12 = arg1.Parent
			end
			if var12 then
			end
			if var12 then
				local Humanoid_2 = var12:FindFirstChild("Humanoid")
			end
			if Humanoid_2 and 0 < Humanoid_2.Health and game.Players:GetPlayerFromCharacter(var12) == LocalPlayer_upvr then
				var12.Humanoid.Health = 0
			end
		end)
	end
end