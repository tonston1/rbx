-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:12
-- Luau version 6, Types version 3
-- Time taken: 0.000570 seconds

return {
	UpdateCharacterState = Instance.new("BindableEvent", script);
	CharacterJumpChange = Instance.new("BindableEvent", script);
	UpdateStaminaState = Instance.new("BindableEvent", script);
	UpdateTemporaryPowerState = Instance.new("BindableEvent", script);
	EndTemporaryPowerState = Instance.new("BindableEvent", script);
	MobileButtonPressBegan = Instance.new("BindableEvent", script);
	MobileButtonPressHeld = Instance.new("BindableEvent", script);
	MobileButtonPressEnd = Instance.new("BindableEvent", script);
	GameFinishedLoad = Instance.new("BindableEvent", script);
	OnPackOpenFinished = Instance.new("BindableEvent", script);
	OnDailyRewardAvaliable = Instance.new("BindableEvent", script);
	TopBarLoaded = Instance.new("BindableEvent", script);
	AbilityActivated = Instance.new("BindableEvent", script);
	Block = Instance.new("BindableEvent", script);
	Jump = Instance.new("BindableEvent", script);
	DisableJump = Instance.new("BindableEvent", script);
}