-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:15
-- Luau version 6, Types version 3
-- Time taken: 0.001692 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local WriteLibraries = ReplicatedStorage.Libraries.Modules.WriteLibraries
local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local tbl_upvr = {}
game.Players.PlayerAdded:Connect(function(arg1) -- Line 19
	--[[ Upvalues[1]:
		[1]: tbl_upvr (readonly)
	]]
	tbl_upvr[arg1] = {}
end)
game.Players.PlayerRemoving:Connect(function(arg1) -- Line 23
	--[[ Upvalues[1]:
		[1]: tbl_upvr (readonly)
	]]
	tbl_upvr[arg1] = nil
end)
local module_upvr = {
	UpdateCharacterState = "UpdateCharacterState";
	SpawnBallOnPlayer = "SpawnBallOnPlayer";
	PlayerJoinTeam = "JoinTeam";
	PlayerLeaveTeam = "LeaveTeam";
	JoinRandomTeam = "JoinRandomTeam";
	ServerUpdatePartyData = "ServerUpdatePartyData";
	ServerLeaveParty = "ServerLeaveParty";
	ServerInviteToParty = "ServerInviteToParty";
	ClientRecieveInvite = "ClientRecieveInvite";
	ClientAcceptParty = "ClientAcceptParty";
	ServerJoinParty = "ServerJoinParty";
	ServerDeclinePartyInvite = "ServerDeclinePartyInvite";
	ServerKickPartyMember = "ServerKickPartyMember";
	ServerStartQueue = "ServerStartQueue";
	ServerLeaveQueue = "ServerLeaveQueue";
	ServerChangeRegion = "ServerChangeRegion";
	ServerSendNotification = "ServerSendNotification";
	LeaveOrJoinGameSuccess = "LeaveOrJoinGameSuccess";
	ChangeConfiguration = "ChangeConfiguration";
	ChangeMobileButtonConfiguration = "ChangeMobileButtonConfiguration";
	ShakePlayerCamera = "ShakePlayerCamera";
	PlayClientSound = "PlayClientSound";
	PlayEndGameTransition = "PlayEndGameTransition";
	PlayEndGameRank = "PlayEndGameRank";
	SendBallToPlayers = "SendBallToPlayers";
	ClientHitBall = "ClientHitBall";
	OnPlayerHitBall = "OnPlayerHitBall";
	OnPlayerHitBallNotifyAll = "OnPlayerHitBallNotifyAll";
	OnPlayerScore = "OnPlayerScore";
	OnPlayerBallLand = "OnPlayerBallLand";
	OnPlayerAce = "OnPlayerAce";
	DoTutorial = "DoTutorial";
	TeleportMain = "TeleportMain";
	TutorialSkip = "SkipTutorial";
	DoPractice = "DoPractice";
	DoProServer = "DoProServer";
	DoAFKServer = "DoAFKServer";
	PlayerSpawnedBall = "PlayerSpawnedBall";
	PlayerTurnToServe = "PlayerTurnToServe";
	ServerCrateReward = "CrateReward";
	IsBallHitType = function(arg1) -- Line 105, Named "IsBallHitType"
		if not arg1 then
			return false
		end
		if not arg1.ballId or type(arg1.ballId) ~= "string" then
			return false
		end
		if not arg1.characterState or type(arg1.characterState) ~= "string" then
			return false
		end
		return true
	end;
}
local Profiles_upvr = require(ReplicatedStorage.Libraries.Modules.Profiles)
local var10_upvr = not any_IsServer_result1_upvr
task.spawn(function() -- Line 112
	--[[ Upvalues[4]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: Profiles_upvr (readonly)
		[3]: module_upvr (readonly)
		[4]: var10_upvr (readonly)
	]]
	if any_IsServer_result1_upvr then
		local any_GetReplica_result1_upvr = Profiles_upvr:GetReplica("Game")
		function module_upvr.OnPlayerTurnToServe(arg1) -- Line 116
			--[[ Upvalues[2]:
				[1]: any_GetReplica_result1_upvr (readonly)
				[2]: module_upvr (copied, readonly)
			]]
			any_GetReplica_result1_upvr:FireClient(arg1, module_upvr.PlayerTurnToServe)
		end
	end
	any_GetReplica_result1_upvr = var10_upvr
	if any_GetReplica_result1_upvr then
		any_GetReplica_result1_upvr = Profiles_upvr:GetReplica("Game")
		function module_upvr.JoinAFKServer() -- Line 124
			--[[ Upvalues[2]:
				[1]: any_GetReplica_result1_upvr (readonly)
				[2]: module_upvr (copied, readonly)
			]]
			any_GetReplica_result1_upvr:FireServer(module_upvr.DoAFKServer)
		end
	end
end)
return module_upvr