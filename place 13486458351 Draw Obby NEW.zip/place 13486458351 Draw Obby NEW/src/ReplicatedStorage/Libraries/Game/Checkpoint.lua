-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:10
-- Luau version 6, Types version 3
-- Time taken: 0.001511 seconds

local TweenService_upvr = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Stages_upvr = workspace:WaitForChild("Stages")
local module = {
	star = script.Star;
}
local RunService_upvr = game:GetService("RunService")
function module.Init(arg1, arg2) -- Line 16
	--[[ Upvalues[2]:
		[1]: Stages_upvr (readonly)
		[2]: RunService_upvr (readonly)
	]]
	local SOME = Stages_upvr:FindFirstChild(arg2 + 1)
	if not SOME then
	else
		arg1.star.CFrame = SOME.Checkpoint.CFrame * CFrame.new(0, -3, 0)
		arg1.star.Parent = workspace
		RunService_upvr.Heartbeat:Connect(function() -- Line 22
			--[[ Upvalues[1]:
				[1]: arg1 (readonly)
			]]
			local star = arg1.star
			star.CFrame *= CFrame.Angles(0, 0.017453292519943295, 0)
		end)
	end
end
function module.Set(arg1, arg2) -- Line 28
	--[[ Upvalues[2]:
		[1]: Stages_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	local SOME_2 = Stages_upvr:FindFirstChild(arg2 + 1)
	if not SOME_2 then
		arg1.star.Transparency = 1
	else
		arg1.star.Transparency = 0
		TweenService_upvr:Create(arg1.star, TweenInfo.new(2), {
			CFrame = SOME_2.Checkpoint.CFrame * CFrame.new(0, -3, 0);
		}):Play()
	end
end
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("SoundEffect"))
local module_2_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("VisualEffect"))
function module.Reward(arg1) -- Line 44
	--[[ Upvalues[3]:
		[1]: TweenService_upvr (readonly)
		[2]: module_upvr (readonly)
		[3]: module_2_upvr (readonly)
	]]
	local clone = arg1.star:Clone()
	clone.Material = Enum.Material.Neon
	clone.Parent = workspace
	TweenService_upvr:Create(clone, TweenInfo.new(0.5), {
		Size = arg1.star.Size + Vector3.new(30, 30, 30);
		Transparency = 1;
		CFrame = clone.CFrame * CFrame.Angles(0, math.pi, 0);
	}):Play()
	module_upvr.new("Hard", nil):Play()
	module_2_upvr.new("Stars", arg1.star.Position):Play(1.5)
end
return module