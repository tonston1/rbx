-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:09
-- Luau version 6, Types version 3
-- Time taken: 0.000351 seconds

local Parent_upvr = script.Parent.Parent
script.Parent:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- Line 4
	--[[ Upvalues[1]:
		[1]: Parent_upvr (readonly)
	]]
	script.Parent.TileSize = UDim2.new(0, Parent_upvr.AbsoluteSize.X / 40, 0, Parent_upvr.AbsoluteSize.X / 40)
end)