-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:08
-- Luau version 6, Types version 3
-- Time taken: 0.011445 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local module_4_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Maid"))
local RunService_upvr = game:GetService("RunService")
local CollectionService_upvr = game:GetService("CollectionService")
local module_upvr_2 = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("TablePlus"))
local module_3_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Collisions"))
local module_5_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("CoreGui"))
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
local PlayerGui = LocalPlayer_upvr:WaitForChild("PlayerGui")
local DrawUI_upvr = PlayerGui:WaitForChild("DrawUI")
local MainUI_upvr = PlayerGui:WaitForChild("MainUI")
local Viewport_2_upvr = DrawUI_upvr:WaitForChild("Viewport")
local Arrow_upvr = Viewport_2_upvr:WaitForChild("Arrow")
local Canvas_upvr = DrawUI_upvr:WaitForChild("Canvas")
local Stages_upvr = workspace:WaitForChild("Stages")
local BindableEvent_upvr = Instance.new("BindableEvent")
local any_GetGuiInset_result1_upvr, _ = game:GetService("GuiService"):GetGuiInset()
local function getTime_upvr(arg1) -- Line 37, Named "getTime"
	local os_date_result1 = os.date("*t")
	local var20 = ""
	if os_date_result1.hour == 24 or os_date_result1.hour < 12 then
		var20 = "AM"
	elseif os_date_result1.hour == 12 or 12 < os_date_result1.hour then
		var20 = "PM"
	end
	if var20 == "PM" or os_date_result1.hour == 24 then
		os_date_result1.hour -= 12
		if os_date_result1.hour == 0 then
			os_date_result1.hour = 12
		end
	end
	os_date_result1.min = string.format("%02d", os_date_result1.min)
	return os_date_result1.hour..':'..os_date_result1.min..var20, os_date_result1.month..'/'..os_date_result1.day..'/'..os_date_result1.year
end
local module = {
	stage = nil;
	stageMaid = module_4_upvr.new();
	hint = 0;
	map = nil;
	mapCFrame = nil;
	mapSize = nil;
	anchored = false;
	ink = 100;
	width = 0;
	shape = nil;
	maid = module_4_upvr.new();
	borderMaid = module_4_upvr.new();
	iconMaid = module_4_upvr.new();
	currentLine = {};
	diameter = 2;
	mapLengthY = nil;
	mapLengthZ = nil;
	mapStartY = nil;
	mapEndY = nil;
	mapStartZ = nil;
	mapEndZ = nil;
	startX = nil;
	endX = nil;
	startY = nil;
	endY = nil;
	drawingConnection = nil;
	drawMaid = module_4_upvr.new();
	enableMaid = module_4_upvr.new();
	Started = BindableEvent_upvr.Event;
}
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Gamepasses"))
local Assets_upvr = ReplicatedStorage:WaitForChild("Assets")
function module.Load(arg1, arg2) -- Line 100
	--[[ Upvalues[10]:
		[1]: Stages_upvr (readonly)
		[2]: getTime_upvr (readonly)
		[3]: module_3_upvr (readonly)
		[4]: module_upvr (readonly)
		[5]: LocalPlayer_upvr (readonly)
		[6]: DrawUI_upvr (readonly)
		[7]: CollectionService_upvr (readonly)
		[8]: module_4_upvr (readonly)
		[9]: RunService_upvr (readonly)
		[10]: Assets_upvr (readonly)
	]]
	local SOME = Stages_upvr:FindFirstChild(arg2)
	local getTime_result1, getTime_upvr_result2 = getTime_upvr(tick())
	if not SOME then
		warn("Map number "..arg2.." doesn't exist!")
	else
		if arg1.stage then
			module_3_upvr:AddToGroup(arg1.stage, "Other")
		end
		local Anchored = SOME:GetAttribute("Anchored")
		arg1.anchored = Anchored
		if module_upvr:Owns(LocalPlayer_upvr, 185566305) then
			Anchored = 10000
		else
			Anchored = SOME:GetAttribute("Ink")
		end
		arg1.ink = Anchored
		arg1.width = SOME:GetAttribute("Width")
		arg1.shape = SOME:GetAttribute("Shape") or "Circle"
		module_3_upvr:AddToGroup(SOME, "Default")
		arg1:Viewport(arg2)
		arg1:Clear()
		DrawUI_upvr.Gravity.Visible = not arg1.anchored
		DrawUI_upvr.Details.Stage.Text = "stage "..arg2.." of "..(#Stages_upvr:GetChildren())
		DrawUI_upvr.Details.Date.Text = getTime_upvr_result2..' '..getTime_result1
		arg1.stage = SOME
		arg1.stageMaid:Destroy()
		for _, v_3_upvr in ipairs(arg1.stage.Map:GetChildren()) do
			if CollectionService_upvr:HasTag(v_3_upvr, "Boulder") then
				local any_new_result1 = module_4_upvr.new()
				local var37_upvw = 0
				local BoulderFrequency_upvr = v_3_upvr:GetAttribute("BoulderFrequency")
				local Adjust_upvr = v_3_upvr:GetAttribute("Adjust")
				local BoulderLifetime_upvr = v_3_upvr:GetAttribute("BoulderLifetime")
				any_new_result1.connection = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 134
					--[[ Upvalues[8]:
						[1]: var37_upvw (read and write)
						[2]: BoulderFrequency_upvr (readonly)
						[3]: Assets_upvr (copied, readonly)
						[4]: v_3_upvr (readonly)
						[5]: Adjust_upvr (readonly)
						[6]: arg1 (readonly)
						[7]: module_4_upvr (copied, readonly)
						[8]: BoulderLifetime_upvr (readonly)
					]]
					if BoulderFrequency_upvr <= var37_upvw then
						var37_upvw = 0
						local clone_3 = Assets_upvr.Obstacles.Boulder:Clone()
						clone_3.CFrame = v_3_upvr.CFrame * CFrame.new(Random.new():NextInteger(-v_3_upvr.Size.X / 2, v_3_upvr.Size.X / 2), 0, 0) + Adjust_upvr
						clone_3.Parent = arg1.stage
						local any_new_result1_5 = module_4_upvr.new()
						any_new_result1_5.boulder = clone_3
						arg1.stageMaid[any_new_result1_5] = any_new_result1_5
						task.wait(BoulderLifetime_upvr)
						any_new_result1_5:Destroy()
					else
						var37_upvw += arg1_2
					end
				end)
				arg1.stageMaid[any_new_result1] = any_new_result1
			end
		end
	end
end
local Square_upvr = script.Square
local Circle_2_upvr = script.Circle
local Truss2D_upvr = script.Truss2D
local Cube_upvr = script.Cube
local Cylinder_upvr = script.Cylinder
local Truss_upvr = script.Truss
local Drawing_upvr = workspace:WaitForChild("Drawing")
local module_2_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Button"))
function module.Circle(arg1, arg2, arg3) -- Line 159
	--[[ Upvalues[16]:
		[1]: module_upvr_2 (readonly)
		[2]: Square_upvr (readonly)
		[3]: Circle_2_upvr (readonly)
		[4]: Truss2D_upvr (readonly)
		[5]: Viewport_2_upvr (readonly)
		[6]: Canvas_upvr (readonly)
		[7]: Cube_upvr (readonly)
		[8]: Cylinder_upvr (readonly)
		[9]: Truss_upvr (readonly)
		[10]: module_3_upvr (readonly)
		[11]: Drawing_upvr (readonly)
		[12]: module_4_upvr (readonly)
		[13]: RunService_upvr (readonly)
		[14]: DrawUI_upvr (readonly)
		[15]: any_GetGuiInset_result1_upvr (readonly)
		[16]: module_2_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [12] 8. Error Block 2 start (CF ANALYSIS FAILED)
	do
		return
	end
	-- KONSTANTERROR: [12] 8. Error Block 2 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [13] 9. Error Block 3 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [13] 9. Error Block 3 end (CF ANALYSIS FAILED)
end
function module.Erase(arg1, arg2) -- Line 294
	--[[ Upvalues[2]:
		[1]: module_upvr_2 (readonly)
		[2]: DrawUI_upvr (readonly)
	]]
	arg1.drawMaid[arg2] = nil
	DrawUI_upvr.Ink.Percent.Size = UDim2.new((0.993) * ((arg1.ink - module_upvr_2:Count(arg1.drawMaid._tasks)) / arg1.ink), 0, 0.764, 0)
end
function module.Between(arg1, arg2, arg3) -- Line 302
	--[[ Upvalues[2]:
		[1]: Canvas_upvr (readonly)
		[2]: any_GetGuiInset_result1_upvr (readonly)
	]]
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	if not arg2 then
	else
		if not arg3 then return end
		local var59 = arg3.AbsolutePosition.Y - arg2.AbsolutePosition.Y
		local var60 = arg3.AbsolutePosition.X - arg2.AbsolutePosition.X
		local var61 = var59 / var60
		if var61 <= (-math.huge) or math.huge <= var61 then
			for i_4 = 1, math.abs(var59 / arg2.AbsoluteSize.X) do
				arg1:Circle((arg2.AbsolutePosition.X + arg2.AbsoluteSize.X / 2) / Canvas_upvr.AbsoluteSize.X, (arg2.AbsolutePosition.Y + arg2.AbsoluteSize.Y * i_4 * math.sign(var61) + any_GetGuiInset_result1_upvr.Y + arg2.AbsoluteSize.Y / 2) / Canvas_upvr.AbsoluteSize.Y)
				local var62
			end
			return
		end
		local squareroot = math.sqrt(math.pow(var59, 2) + math.pow(var60, 2))
		for i_5 = 1, squareroot / arg2.AbsoluteSize.X do
			arg1:Circle((arg2.AbsolutePosition.X + (var60) / (squareroot / arg2.AbsoluteSize.X) * i_5 + arg2.AbsoluteSize.X / 2) / Canvas_upvr.AbsoluteSize.X, (var62 * (arg2.AbsolutePosition.X + (var60) / (squareroot / arg2.AbsoluteSize.X) * i_5 - arg3.AbsolutePosition.X) + arg3.AbsolutePosition.Y + any_GetGuiInset_result1_upvr.Y + arg2.AbsoluteSize.Y / 2) / Canvas_upvr.AbsoluteSize.Y)
			local _
		end
	end
end
local any_new_result1_2_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Mouse")).new()
function module.Enable(arg1) -- Line 332
	--[[ Upvalues[9]:
		[1]: module_5_upvr (readonly)
		[2]: DrawUI_upvr (readonly)
		[3]: MainUI_upvr (readonly)
		[4]: Viewport_2_upvr (readonly)
		[5]: any_new_result1_2_upvr (readonly)
		[6]: BindableEvent_upvr (readonly)
		[7]: RunService_upvr (readonly)
		[8]: Canvas_upvr (readonly)
		[9]: any_GetGuiInset_result1_upvr (readonly)
	]]
	module_5_upvr:Enable({
		[Enum.CoreGuiType.PlayerList] = false;
		[Enum.CoreGuiType.Backpack] = false;
		[Enum.CoreGuiType.EmotesMenu] = false;
		[Enum.CoreGuiType.Health] = false;
		[Enum.CoreGuiType.Chat] = false;
	})
	DrawUI_upvr.Enabled = true
	MainUI_upvr.Enabled = false
	arg1.startX = Viewport_2_upvr.AbsolutePosition.X
	arg1.endX = Viewport_2_upvr.AbsolutePosition.X + Viewport_2_upvr.AbsoluteSize.X
	arg1.startY = Viewport_2_upvr.AbsolutePosition.Y
	arg1.endY = Viewport_2_upvr.AbsolutePosition.Y + Viewport_2_upvr.AbsoluteSize.Y
	arg1.maid.changeConnection = Viewport_2_upvr:GetPropertyChangedSignal("AbsolutePosition"):Connect(function() -- Line 347
		--[[ Upvalues[2]:
			[1]: arg1 (readonly)
			[2]: Viewport_2_upvr (copied, readonly)
		]]
		arg1.startX = Viewport_2_upvr.AbsolutePosition.X
		arg1.endX = Viewport_2_upvr.AbsolutePosition.X + Viewport_2_upvr.AbsoluteSize.X
		arg1.startY = Viewport_2_upvr.AbsolutePosition.Y
		arg1.endY = Viewport_2_upvr.AbsolutePosition.Y + Viewport_2_upvr.AbsoluteSize.Y
	end)
	arg1.enableMaid.drawActivateConnection = any_new_result1_2_upvr.Activated:Connect(function(arg1_3) -- Line 354
		--[[ Upvalues[6]:
			[1]: BindableEvent_upvr (copied, readonly)
			[2]: arg1 (readonly)
			[3]: RunService_upvr (copied, readonly)
			[4]: any_new_result1_2_upvr (copied, readonly)
			[5]: Canvas_upvr (copied, readonly)
			[6]: any_GetGuiInset_result1_upvr (copied, readonly)
		]]
		if arg1_3 then
		else
			BindableEvent_upvr:Fire()
			local var70_upvw
			arg1.enableMaid.draw = RunService_upvr.Heartbeat:Connect(function() -- Line 359
				--[[ Upvalues[5]:
					[1]: any_new_result1_2_upvr (copied, readonly)
					[2]: var70_upvw (read and write)
					[3]: Canvas_upvr (copied, readonly)
					[4]: any_GetGuiInset_result1_upvr (copied, readonly)
					[5]: arg1 (copied, readonly)
				]]
				any_new_result1_2_upvr:SetViewportPosition()
				local any_GetPosition_result1 = any_new_result1_2_upvr:GetPosition()
				if not var70_upvw then
					var70_upvw = arg1:Circle(any_GetPosition_result1.X / Canvas_upvr.AbsoluteSize.X, (any_GetPosition_result1.Y + any_GetGuiInset_result1_upvr.Y) / Canvas_upvr.AbsoluteSize.Y)
				else
					local any_Circle_result1 = arg1:Circle(any_GetPosition_result1.X / Canvas_upvr.AbsoluteSize.X, (any_GetPosition_result1.Y + any_GetGuiInset_result1_upvr.Y) / Canvas_upvr.AbsoluteSize.Y)
					arg1:Between(any_Circle_result1, var70_upvw)
					var70_upvw = any_Circle_result1
				end
			end)
		end
	end)
	arg1.enableMaid.drawDeactivateConnection = any_new_result1_2_upvr.Deactivated:Connect(function() -- Line 381
		--[[ Upvalues[1]:
			[1]: arg1 (readonly)
		]]
		for _, v in ipairs(arg1.currentLine) do
			v.Anchored = false
		end
		arg1.currentLine = {}
		arg1.enableMaid.draw = nil
	end)
end
function module.Disable(arg1) -- Line 397
	--[[ Upvalues[3]:
		[1]: module_5_upvr (readonly)
		[2]: DrawUI_upvr (readonly)
		[3]: MainUI_upvr (readonly)
	]]
	module_5_upvr:Enable({
		[Enum.CoreGuiType.PlayerList] = true;
		[Enum.CoreGuiType.Backpack] = false;
		[Enum.CoreGuiType.EmotesMenu] = true;
		[Enum.CoreGuiType.Health] = true;
		[Enum.CoreGuiType.Chat] = true;
	})
	DrawUI_upvr.Enabled = false
	MainUI_upvr.Enabled = true
	arg1.enableMaid:Destroy()
end
function module.Clear(arg1) -- Line 413
	--[[ Upvalues[1]:
		[1]: DrawUI_upvr (readonly)
	]]
	arg1:HideHint()
	arg1.hint += 1
	DrawUI_upvr.Ink.Percent.Size = UDim2.new(0.993, 0, 0.764, 0)
	arg1.drawMaid:Destroy()
end
function module.Viewport(arg1, arg2) -- Line 424
	--[[ Upvalues[4]:
		[1]: Stages_upvr (readonly)
		[2]: Viewport_2_upvr (readonly)
		[3]: CollectionService_upvr (readonly)
		[4]: module_4_upvr (readonly)
	]]
	local SOME_2 = Stages_upvr:FindFirstChild(arg2)
	if not SOME_2 then
	else
		arg1.iconMaid:Destroy()
		arg1.borderMaid:Destroy()
		arg1.maid.map = SOME_2.Map:Clone()
		local any_GetBoundingBox_result1, any_GetBoundingBox_result2 = arg1.maid.map:GetBoundingBox()
		arg1.mapCFrame = any_GetBoundingBox_result1
		arg1.mapSize = any_GetBoundingBox_result2
		arg1.mapStartY = arg1.mapCFrame.Y - arg1.mapSize.Y / 2
		arg1.mapEndY = arg1.mapCFrame.Y + arg1.mapSize.Y / 2
		arg1.mapStartZ = arg1.mapCFrame.Z - arg1.mapSize.Z / 2
		arg1.mapEndZ = arg1.mapCFrame.Z + arg1.mapSize.Z / 2
		arg1.mapLengthY = math.max(arg1.mapStartY, arg1.mapEndY) - math.min(arg1.mapStartY, arg1.mapEndY)
		arg1.mapLengthZ = math.max(arg1.mapStartZ, arg1.mapEndZ) - math.min(arg1.mapStartZ, arg1.mapEndZ)
		arg1.maid.cam = Instance.new("Camera")
		arg1.maid.cam.FieldOfView = 1
		arg1.maid.cam.Parent = Viewport_2_upvr
		local X = arg1.mapSize.X
		local Y = arg1.mapSize.Y
		local Z = arg1.mapSize.Z
		if Z < X then
		else
		end
		if X < Z then
		else
		end
		local var88 = Z / Y
		print(Z, Y, var88)
		arg1.maid.aspectRatio = Instance.new("UIAspectRatioConstraint")
		arg1.maid.aspectRatio.AspectRatio = var88
		arg1.maid.aspectRatio.Parent = Viewport_2_upvr
		arg1.maid.cam.CFrame = arg1.mapCFrame * CFrame.Angles(0, (-math.pi/2), 0) * CFrame.new(0, 0, (Y) / (math.tan(math.rad(arg1.maid.cam.FieldOfView / 2)) * 2) + X / 2)
		Viewport_2_upvr.CurrentCamera = arg1.maid.cam
		arg1.maid.map.Parent = Viewport_2_upvr
		for _, v_4 in ipairs(arg1.maid.map:GetChildren()) do
			if CollectionService_upvr:HasTag(v_4, "Border") then
				local clone_2 = script.Border:Clone()
				clone_2.Position = UDim2.new((v_4.Position.Z - v_4.Size.Z / 2 - arg1.mapStartZ) / (arg1.mapEndZ - arg1.mapStartZ), 0, 1 - (v_4.Position.Y - v_4.Size.Y / 2 - arg1.mapStartY) / (arg1.mapEndY - arg1.mapStartY), 0)
				clone_2.Size = UDim2.new(v_4.Size.Z / arg1.mapLengthZ, 0, v_4.Size.Y / arg1.mapLengthY, 0)
				clone_2.Parent = Viewport_2_upvr
				local any_new_result1_4 = module_4_upvr.new()
				any_new_result1_4.border = v_4
				any_new_result1_4.gui = clone_2
				arg1.borderMaid[any_new_result1_4] = any_new_result1_4
			elseif CollectionService_upvr:HasTag(v_4, "Icon") then
				local clone = script.Icon:Clone()
				clone.Image = v_4:GetAttribute("Icon")
				clone.Position = UDim2.new((v_4.Position.Z - v_4.Size.Z / 2 - arg1.mapStartZ) / (arg1.mapEndZ - arg1.mapStartZ), 0, 1 - (v_4.Position.Y - v_4.Size.Y / 2 - arg1.mapStartY) / (arg1.mapEndY - arg1.mapStartY), 0)
				clone.Size = UDim2.new(v_4.Size.Z / arg1.mapLengthZ, 0, v_4.Size.Y / arg1.mapLengthY, 0)
				clone.Parent = Viewport_2_upvr
				local any_new_result1_3 = module_4_upvr.new()
				any_new_result1_3.icon = clone
				arg1.iconMaid[any_new_result1_3] = any_new_result1_3
			end
		end
	end
end
local TweenService_upvr = game:GetService("TweenService")
function module.Hint(arg1, arg2) -- Line 499
	--[[ Upvalues[3]:
		[1]: Arrow_upvr (readonly)
		[2]: TweenService_upvr (readonly)
		[3]: Viewport_2_upvr (readonly)
	]]
	arg1.hint += 1
	local hint = arg1.hint
	local _1 = arg2[1]
	Arrow_upvr.Visible = true
	while arg1.hint == hint do
		Arrow_upvr.Position = UDim2.new(1 * _1[1], 0, 1 * _1[2], 0)
		TweenService_upvr:Create(Arrow_upvr, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
			Size = UDim2.new(0, Viewport_2_upvr.AbsoluteSize.X / 15, 0, Viewport_2_upvr.AbsoluteSize.X / 15);
		}):Play()
		for _, v_2 in ipairs(arg2) do
			if arg1.hint ~= hint then return end
			local AbsolutePosition = Arrow_upvr.AbsolutePosition
			local vector2 = Vector2.new(Viewport_2_upvr.AbsolutePosition.X + Viewport_2_upvr.AbsoluteSize.X * v_2[1], Viewport_2_upvr.AbsolutePosition.Y + Viewport_2_upvr.AbsoluteSize.Y * v_2[2])
			local var107 = math.sqrt(math.pow(vector2.X - AbsolutePosition.X, 2) + math.pow(vector2.Y - AbsolutePosition.Y, 2)) / 150
			TweenService_upvr:Create(Arrow_upvr, TweenInfo.new(var107, Enum.EasingStyle.Linear), {
				Position = UDim2.new(1 * v_2[1], 0, 1 * v_2[2], 0);
			}):Play()
			task.wait(var107)
		end
	end
end
function module.HideHint(arg1) -- Line 529
	--[[ Upvalues[1]:
		[1]: Arrow_upvr (readonly)
	]]
	Arrow_upvr.Visible = false
end
function module.SetDiameter(arg1, arg2) -- Line 534
	arg1.diameter = arg2
end
function module.SetShape(arg1, arg2) -- Line 539
	arg1.shape = arg2
end
return module