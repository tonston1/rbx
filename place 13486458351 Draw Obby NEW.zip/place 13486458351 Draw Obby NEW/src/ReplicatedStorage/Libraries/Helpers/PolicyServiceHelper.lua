-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:41
-- Luau version 6, Types version 3
-- Time taken: 0.000588 seconds

local module = {}
local PolicyService_upvr = game:GetService("PolicyService")
function module.Get(arg1, arg2) -- Line 6
	--[[ Upvalues[1]:
		[1]: PolicyService_upvr (readonly)
	]]
	assert(arg2, "plr argument is nil. Player object expected")
	local var3
	repeat
		local pcall_result1, pcall_result2 = pcall(function() -- Line 12
			--[[ Upvalues[2]:
				[1]: PolicyService_upvr (copied, readonly)
				[2]: arg2 (readonly)
			]]
			return PolicyService_upvr:GetPolicyInfoForPlayerAsync(arg2)
		end)
		var3 = pcall_result2
		task.wait()
	until pcall_result1
	return var3
end
return module