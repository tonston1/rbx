-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:50
-- Luau version 6, Types version 3
-- Time taken: 0.006940 seconds

local TweenService_upvr = game:GetService("TweenService")
local Maid_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid)
local module = {}
function resizeModel(arg1, arg2) -- Line 16
	local Position_5 = arg1.PrimaryPart.Position
	for _, v in arg1:GetDescendants(), nil do
		if v:IsA("BasePart") then
			if v ~= arg1.PrimaryPart then
				local CFrame_2 = v.CFrame
				v.CFrame = CFrame.new((CFrame_2.Position - Position_5) * arg2 + Position_5) * (CFrame_2 - CFrame_2.Position)
			end
			v.Size *= arg2
		end
	end
end
local RunService_upvr = game:GetService("RunService")
function module.Size(arg1, arg2, arg3, arg4, arg5, arg6) -- Line 33
	--[[ Upvalues[2]:
		[1]: RunService_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	if arg4 then
		if arg3 == 0 then
			resizeModel(arg2, arg4)
			return
		end
		local var10_upvw = 0
		local var11_upvr = arg4 - 1
		local var12_upvw = 0
		local var13_upvw
		var13_upvw = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 43
			--[[ Upvalues[9]:
				[1]: var10_upvw (read and write)
				[2]: arg3 (readonly)
				[3]: TweenService_upvr (copied, readonly)
				[4]: arg5 (readonly)
				[5]: arg6 (readonly)
				[6]: arg2 (readonly)
				[7]: var11_upvr (readonly)
				[8]: var12_upvw (read and write)
				[9]: var13_upvw (read and write)
			]]
			if var10_upvw < 1 then
				var10_upvw = math.min(var10_upvw + arg1_2 / arg3, 1)
				local var14 = arg5
				if not var14 then
					var14 = Enum.EasingStyle.Linear
				end
				local var15 = arg6
				if not var15 then
					var15 = Enum.EasingDirection.Out
				end
				local any_GetValue_result1 = TweenService_upvr:GetValue(var10_upvw, var14, var15)
				resizeModel(arg2, (any_GetValue_result1 * var11_upvr + 1) / (var12_upvw * var11_upvr + 1))
				var12_upvw = any_GetValue_result1
			else
				var13_upvw:Disconnect()
			end
		end)
	end
end
local any_new_result1_2_upvr = Maid_upvr.new()
function module.CFrame(arg1, arg2, arg3, arg4) -- Line 59
	--[[ Upvalues[3]:
		[1]: Maid_upvr (readonly)
		[2]: any_new_result1_2_upvr (readonly)
		[3]: TweenService_upvr (readonly)
	]]
	local any_new_result1 = Maid_upvr.new()
	any_new_result1_2_upvr[arg2] = any_new_result1
	local CFrameValue_upvr = Instance.new("CFrameValue")
	CFrameValue_upvr.Value = arg2:GetPrimaryPartCFrame()
	CFrameValue_upvr:GetPropertyChangedSignal("Value"):Connect(function() -- Line 66
		--[[ Upvalues[3]:
			[1]: arg2 (readonly)
			[2]: any_new_result1_2_upvr (copied, readonly)
			[3]: CFrameValue_upvr (readonly)
		]]
		if not arg2.PrimaryPart then
			any_new_result1_2_upvr[arg2] = nil
		else
			arg2:PivotTo(CFrameValue_upvr.Value)
		end
	end)
	local tbl_2 = {}
	tbl_2.Value = arg3
	local any_Create_result1 = TweenService_upvr:Create(CFrameValue_upvr, arg4, tbl_2)
	any_Create_result1:Play()
	any_Create_result1.Completed:Connect(function() -- Line 77
		--[[ Upvalues[2]:
			[1]: any_new_result1_2_upvr (copied, readonly)
			[2]: arg2 (readonly)
		]]
		any_new_result1_2_upvr[arg2] = nil
	end)
	any_new_result1.cframe = CFrameValue_upvr
	any_new_result1.tween = any_Create_result1
	return any_Create_result1
end
function module.Transparency(arg1, arg2, arg3, arg4) -- Line 88
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	if arg2:IsA("BasePart") then
		local tbl = {}
		tbl.Transparency = arg4
		TweenService_upvr:Create(arg2, TweenInfo.new(arg3, Enum.EasingStyle.Linear), tbl):Play()
	end
	for _, v_2 in arg2:GetDescendants(), nil do
		if v_2:IsA("BasePart") then
			local tbl_3 = {}
			tbl_3.Transparency = arg4
			TweenService_upvr:Create(v_2, TweenInfo.new(arg3, Enum.EasingStyle.Linear), tbl_3):Play()
		end
	end
end
function module.CanCollide(arg1, arg2, arg3, arg4) -- Line 105
	for _, v_3 in arg2:GetDescendants(), nil do
		if v_3:IsA("BasePart") and v_3.CanCollide ~= arg4 then
			v_3.CanCollide = arg4
		end
	end
end
function module.Properties(arg1, arg2, arg3) -- Line 114
	for _, v_4 in arg2:GetDescendants(), nil do
		if v_4:IsA("BasePart") then
			for i_5, v_5 in arg3 do
				v_4[i_5] = v_5
			end
		end
	end
end
function module.Tween(arg1, arg2, arg3, arg4) -- Line 125
	for i_6, v_6 in arg4 do
		if arg1[i_6] then
			arg1[i_6](arg1, arg2, arg3, v_6)
		end
	end
end
function module.Weld(arg1, arg2, arg3) -- Line 134
	if arg2:IsA("Model") then
		for _, v_7 in arg2:GetDescendants(), nil do
			if v_7:IsA("BasePart") then
				local WeldConstraint_2 = Instance.new("WeldConstraint")
				WeldConstraint_2.Part0 = v_7
				WeldConstraint_2.Part1 = arg3
				WeldConstraint_2.Parent = v_7
			end
		end
	elseif arg2:IsA("BasePart") then
		local WeldConstraint = Instance.new("WeldConstraint")
		WeldConstraint.Part0 = arg2
		WeldConstraint.Part1 = arg3
		WeldConstraint.Parent = arg2
	end
end
function module.InBounds(arg1, arg2, arg3) -- Line 152
	local var68
	if arg2:IsA("Model") then
		var68 = arg2:GetBoundingBox().Position
	elseif arg2:IsA("BasePart") then
		var68 = arg2.Position
	end
	local var69 = var68
	local Position_3 = arg3.Position
	local Size_3 = arg3.Size
	local var72 = Position_3 - Size_3 / 2
	local var73 = Position_3 + Size_3 / 2
	local var74 = false
	if var72.X <= var69.X then
		var74 = false
		if var69.X <= var73.X then
			var74 = false
			if var72.Y <= var69.Y then
				var74 = false
				if var69.Y <= var73.Y then
					var74 = false
					if var72.Z <= var69.Z then
						if var69.Z > var73.Z then
							var74 = false
						else
							var74 = true
						end
					end
				end
			end
		end
	end
	return var74
end
function module.GetMass(arg1) -- Line 173
	local var79
	for _, v_8 in arg1:GetDescendants(), nil do
		if v_8:IsA("BasePart") then
			var79 += v_8:GetMass()
		end
	end
	return var79
end
return module