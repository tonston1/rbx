-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:53
-- Luau version 6, Types version 3
-- Time taken: 0.001153 seconds

local module_upvr = {}
module_upvr.__index = module_upvr
function module_upvr.new(arg1) -- Line 8
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	local setmetatable_result1_upvr = setmetatable({}, module_upvr)
	setmetatable_result1_upvr.intValue = Instance.new("NumberValue")
	setmetatable_result1_upvr.bindable = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Updated = setmetatable_result1_upvr.bindable.Event
	setmetatable_result1_upvr.updateConnection = setmetatable_result1_upvr.intValue:GetPropertyChangedSignal("Value"):Connect(function() -- Line 15
		--[[ Upvalues[1]:
			[1]: setmetatable_result1_upvr (readonly)
		]]
		setmetatable_result1_upvr.bindable:Fire(setmetatable_result1_upvr.intValue.Value)
	end)
	setmetatable_result1_upvr.intValue.Value = arg1 or 0
	return setmetatable_result1_upvr
end
local TweenService_upvr = game:GetService("TweenService")
function module_upvr.Start(arg1, arg2, arg3, arg4) -- Line 25
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	arg1:Stop()
	local var5 = arg4
	if not var5 then
		var5 = TweenInfo.new(arg3 or 1, Enum.EasingStyle.Linear)
	end
	local tbl = {}
	tbl.Value = arg2
	arg1.tween = TweenService_upvr:Create(arg1.intValue, var5, tbl)
	arg1.tween:Play()
end
function module_upvr.Stop(arg1) -- Line 37
	if arg1.tween then
		arg1.tween:Cancel()
		arg1.tween = nil
	end
end
function module_upvr.Destroy(arg1) -- Line 45
	arg1:Stop()
	arg1.updateConnection:Disconnect()
	arg1.intValue:Destroy()
	arg1.bindable:Destroy()
end
return module_upvr