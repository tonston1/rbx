-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:51
-- Luau version 6, Types version 3
-- Time taken: 0.005563 seconds

local module_upvr = {
	decimalPlaces = 2;
	suffixTable = {'k', 'M', 'B', 'T', "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Vi"};
	FloatingPoint = function(arg1, arg2, arg3) -- Line 26, Named "FloatingPoint"
		return string.format("%."..arg3..'f', arg2):gsub("%.?0+$", "")
	end;
	Round = function(arg1, arg2, arg3, arg4) -- Line 34, Named "Round"
		local var3 = arg2 * 10 ^ arg3
		if arg4 then
			return math.floor(var3) / 10 ^ arg3
		end
		return math.floor(tonumber(tostring(var3)) + 0.5) / 10 ^ arg3
	end;
	Separate = function(arg1, arg2, arg3) -- Line 46, Named "Separate"
		local var4
		repeat
			local string_gsub_result1, string_gsub_result2 = string.gsub(var4, "^(-?%d+)(%d%d%d)", "%1"..(arg3 or ',').."%2")
			var4 = string_gsub_result1
		until string_gsub_result2 == 0
		return var4
	end;
}
function module_upvr.Abbreviate(arg1, arg2, arg3, arg4) -- Line 63
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 28 start (CF ANALYSIS FAILED)
	if type(arg2) ~= "number" then
		error("numberToString invalid parameter #1, expected number, got \"nil\"", 2)
	end
	local var7
	if var7 < 1000 and -1000 < var7 then
		var7 = module_upvr:Round(var7, arg3)
		return tostring(var7)
	end
	if var7 >= 0 then
	else
	end
	var7 = math.abs(math.floor(var7))
	local len = #module_upvr.suffixTable
	-- KONSTANTERROR: [0] 1. Error Block 28 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [90] 73. Error Block 16 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [90] 73. Error Block 16 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [54] 44. Error Block 11 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [90.263438]
	-- KONSTANTERROR: [54] 44. Error Block 11 end (CF ANALYSIS FAILED)
end
local tbl_upvr = {{
	value = 1000;
	symbol = 'M';
}, {
	value = 900;
	symbol = "CM";
}, {
	value = 500;
	symbol = 'D';
}, {
	value = 400;
	symbol = "CD";
}, {
	value = 100;
	symbol = 'C';
}, {
	value = 90;
	symbol = "XC";
}, {
	value = 50;
	symbol = 'L';
}, {
	value = 40;
	symbol = "XL";
}, {
	value = 10;
	symbol = 'X';
}, {
	value = 9;
	symbol = "IX";
}, {
	value = 5;
	symbol = 'V';
}, {
	value = 4;
	symbol = "IV";
}, {
	value = 1;
	symbol = 'I';
}}
function module_upvr.ToRoman(arg1, arg2) -- Line 162
	--[[ Upvalues[1]:
		[1]: tbl_upvr (readonly)
	]]
	local var27
	while 0 < arg2 do
		for _, v in tbl_upvr do
			while v.value <= arg2 do
				var27 = var27..v.symbol
			end
		end
	end
	return var27
end
function module_upvr.OrdinalSuffix(arg1, arg2) -- Line 181
	-- KONSTANTERROR: [0] 1. Error Block 13 start (CF ANALYSIS FAILED)
	local tonumber_result1 = tonumber(string.sub(arg2, string.len(arg2)))
	local var30
	if tonumber_result1 == 1 then
		var30 = "st"
		-- KONSTANTWARNING: GOTO [28] #22
	end
	-- KONSTANTERROR: [0] 1. Error Block 13 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [19] 15. Error Block 14 start (CF ANALYSIS FAILED)
	if tonumber_result1 == 2 then
		var30 = "nd"
	elseif tonumber_result1 == 3 then
		var30 = "rd"
	else
		var30 = "th"
	end
	do
		return arg2..var30
	end
	-- KONSTANTERROR: [19] 15. Error Block 14 end (CF ANALYSIS FAILED)
end
function module_upvr.FormatTimerHMS(arg1, arg2) -- Line 189
	return "%02i:%02i:%02i":format(arg2 / 60 / 60 % 24, arg2 / 60 % 60, arg2 % 60)
end
function module_upvr.FormatTimerDHSM(arg1, arg2) -- Line 196
	return "%02i:%02i:%02i:%02i":format(arg2 / 60 / 60 / 24, arg2 / 60 / 60 % 24, arg2 / 60 % 60, arg2 % 60)
end
function module_upvr.FormatTimerMS(arg1, arg2) -- Line 203
	return "%02i:%02i":format(arg2 / 60 % 60, arg2 % 60)
end
function module_upvr.FormatTimerMSM(arg1, arg2) -- Line 210
	return "%02i:%02i.%02i":format(arg2 / 60 % 60, arg2 % 60, math.floor(tonumber(string.sub(tostring(arg2 % 1), 2, 4)) * 100))
end
function module_upvr.FormatTimerDH(arg1, arg2) -- Line 220
	return "%02id %02iH":format(arg2 / 60 / 60 / 24, arg2 / 60 / 60 % 24)
end
local Tween_2_upvr = require(script.Tween)
function module_upvr.Tween(arg1, arg2) -- Line 226
	--[[ Upvalues[1]:
		[1]: Tween_2_upvr (readonly)
	]]
	return Tween_2_upvr.new(arg2)
end
local NumberTween_2_upvr = require(script.NumberTween)
function module_upvr.NumberTween(arg1, arg2) -- Line 231
	--[[ Upvalues[1]:
		[1]: NumberTween_2_upvr (readonly)
	]]
	return NumberTween_2_upvr.new(arg2)
end
function module_upvr.ZeroVector3(arg1, arg2) -- Line 236
	return arg2 - Vector3.new(0, arg2.Y, 0)
end
function module_upvr.SetVector3(arg1, arg2, arg3) -- Line 241
	return Vector3.new(arg2.X, arg3, arg2.Z)
end
function module_upvr.ClampVector3(arg1, arg2, arg3, arg4, arg5) -- Line 245
	if arg3 == 'X' then
		return Vector3.new(math.clamp(arg2.X, arg4, arg5), arg2.Y, arg2.Z)
	end
	if arg3 == 'Y' then
		return Vector3.new(arg2.X, math.clamp(arg2.Y, arg4, arg5), arg2.Z)
	end
	if arg3 == 'Z' then
		return Vector3.new(arg2.X, arg2.Y, math.clamp(arg2.Z, arg4, arg5))
	end
	error("Not a valid value")
end
function module_upvr.ColourSaturation(arg1, arg2, arg3) -- Line 258
	local any_ToHSV_result1, any_ToHSV_result2, any_ToHSV_result3 = arg2:ToHSV()
	return Color3.fromHSV(any_ToHSV_result1, any_ToHSV_result2 * arg3, any_ToHSV_result3)
end
function module_upvr.CFrameOrientation(arg1, arg2) -- Line 268
	local any_ToOrientation_result1, any_ToOrientation_result2, any_ToOrientation_result3 = arg2:ToOrientation()
	return Vector3.new(math.deg(any_ToOrientation_result1), math.deg(any_ToOrientation_result2), math.deg(any_ToOrientation_result3))
end
function module_upvr.OrientationMagnitude(arg1, arg2, arg3) -- Line 274
	return math.acos(CFrame.Angles(math.rad(Vector3.new(90, 0, 0).X), math.rad(Vector3.new(90, 0, 0).Y), math.rad(Vector3.new(90, 0, 0).Z)).LookVector:Dot(CFrame.Angles(math.rad(Vector3.new(0, 90, 0).X), math.rad(Vector3.new(0, 90, 0).Y), math.rad(Vector3.new(0, 90, 0).Z)).LookVector))
end
function module_upvr.KilogramToPounds(arg1, arg2) -- Line 288
	return arg2 * 2.205
end
function module_upvr.CentimetersToFeet(arg1, arg2) -- Line 292
	local math_modf_result1, math_modf_result2 = math.modf(arg2 / 30.48)
	return math_modf_result1, arg1:Round(math_modf_result2 * 12, 0, true)
end
function module_upvr.KilometerToMiles(arg1, arg2) -- Line 299
	return arg2 / 1.609
end
function module_upvr.GetLookUpDownToNumber(arg1, arg2) -- Line 303
	return math.deg(math.asin(math.clamp(arg2.LookVector.Y, -1, 1))) / 80
end
return module_upvr