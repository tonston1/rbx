-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:47
-- Luau version 6, Types version 3
-- Time taken: 0.002996 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService_upvr = game:GetService("RunService")
local any_new_result1_upvr_2 = require(ReplicatedStorage.Libraries.Classes.Maid).new()
local module = {}
local Animations_upvr = require(ReplicatedStorage.Libraries.Classes.Animations)
function module.Emote(arg1, arg2, arg3, arg4, arg5, arg6) -- Line 15
	--[[ Upvalues[2]:
		[1]: Animations_upvr (readonly)
		[2]: any_new_result1_upvr_2 (readonly)
	]]
	local Camera_upvr = Instance.new("Camera")
	Camera_upvr.Parent = arg3
	local WorldModel_upvr = Instance.new("WorldModel")
	WorldModel_upvr.Parent = arg3
	local clone_upvr_4 = arg2:Clone()
	Camera_upvr.CFrame = clone_upvr_4:FindFirstChild("HumanoidRootPart").CFrame * CFrame.Angles(0, math.rad(arg4), 0) * CFrame.new(0, 0, arg5)
	arg3.CurrentCamera = Camera_upvr
	clone_upvr_4.Parent = workspace
	local tbl = {}
	tbl.idle = arg6
	local any_new_result1_upvr = Animations_upvr.new(tbl, clone_upvr_4:FindFirstChild("Animator", true))
	any_new_result1_upvr:Play({{
		animation = "idle";
		fadeIn = 0;
		looped = true;
	}})
	clone_upvr_4.Parent = WorldModel_upvr
	any_new_result1_upvr_2[arg3] = function() -- Line 57
		--[[ Upvalues[4]:
			[1]: any_new_result1_upvr (readonly)
			[2]: clone_upvr_4 (readonly)
			[3]: WorldModel_upvr (readonly)
			[4]: Camera_upvr (readonly)
		]]
		any_new_result1_upvr:Destroy()
		clone_upvr_4:Destroy()
		WorldModel_upvr:Destroy()
		Camera_upvr:Destroy()
	end
end
function module.Model(arg1, arg2, arg3, arg4) -- Line 66
	--[[ Upvalues[1]:
		[1]: any_new_result1_upvr_2 (readonly)
	]]
	local clone_upvr = arg3:Clone()
	clone_upvr.Parent = arg2
	if not clone_upvr.PrimaryPart then
	else
		local Camera_upvr_2 = Instance.new("Camera")
		Camera_upvr_2.Parent = arg2
		Camera_upvr_2.CFrame = clone_upvr.PrimaryPart.CFrame * arg4
		arg2.CurrentCamera = Camera_upvr_2
		any_new_result1_upvr_2[arg2] = function() -- Line 78
			--[[ Upvalues[2]:
				[1]: clone_upvr (readonly)
				[2]: Camera_upvr_2 (readonly)
			]]
			clone_upvr:Destroy()
			Camera_upvr_2:Destroy()
		end
	end
end
function module.SetCamera(arg1, arg2, arg3) -- Line 85
	local CurrentCamera = arg2.CurrentCamera
	local class_Model = arg2:FindFirstChildWhichIsA("Model")
	if not CurrentCamera then
	else
		if not class_Model then return end
		if not class_Model.PrimaryPart then return end
		CurrentCamera.CFrame = class_Model.PrimaryPart.CFrame * arg3
	end
end
function module.SpinModel(arg1, arg2, arg3, arg4, arg5) -- Line 97
	--[[ Upvalues[2]:
		[1]: RunService_upvr (readonly)
		[2]: any_new_result1_upvr_2 (readonly)
	]]
	local clone_upvr_2 = arg3:Clone()
	clone_upvr_2.Parent = arg2
	if not clone_upvr_2.PrimaryPart then
	else
		local Camera_upvr_4 = Instance.new("Camera")
		Camera_upvr_4.CFrame = clone_upvr_2.PrimaryPart.CFrame * CFrame.new(0, 0, arg4)
		Camera_upvr_4.Parent = arg2
		arg2.CurrentCamera = Camera_upvr_4
		local any_Connect_result1_upvr_2 = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 109
			--[[ Upvalues[2]:
				[1]: arg5 (readonly)
				[2]: clone_upvr_2 (readonly)
			]]
			clone_upvr_2:PivotTo(clone_upvr_2.PrimaryPart.CFrame * CFrame.Angles(0, math.rad(arg5 * arg1_2), 0))
		end)
		any_new_result1_upvr_2[arg2] = function() -- Line 115
			--[[ Upvalues[3]:
				[1]: any_Connect_result1_upvr_2 (readonly)
				[2]: clone_upvr_2 (readonly)
				[3]: Camera_upvr_4 (readonly)
			]]
			any_Connect_result1_upvr_2:Disconnect()
			clone_upvr_2:Destroy()
			Camera_upvr_4:Destroy()
		end
	end
end
function module.SpinCamera(arg1, arg2, arg3, arg4, arg5) -- Line 123
	--[[ Upvalues[2]:
		[1]: RunService_upvr (readonly)
		[2]: any_new_result1_upvr_2 (readonly)
	]]
	local clone_upvr_3 = arg3:Clone()
	clone_upvr_3.Parent = arg2
	if not clone_upvr_3.PrimaryPart then
	else
		local Camera_upvr_3 = Instance.new("Camera")
		Camera_upvr_3.Parent = arg2
		arg2.CurrentCamera = Camera_upvr_3
		local var27_upvw = 0
		local any_Connect_result1_upvr = RunService_upvr.Heartbeat:Connect(function(arg1_3) -- Line 136
			--[[ Upvalues[5]:
				[1]: var27_upvw (read and write)
				[2]: arg5 (readonly)
				[3]: Camera_upvr_3 (readonly)
				[4]: clone_upvr_3 (readonly)
				[5]: arg4 (readonly)
			]]
			var27_upvw += arg5 * arg1_3
			Camera_upvr_3.CFrame = clone_upvr_3.PrimaryPart.CFrame * CFrame.Angles(0, math.rad(var27_upvw), 0) * CFrame.new(0, 0, arg4)
		end)
		any_new_result1_upvr_2[arg2] = function() -- Line 142
			--[[ Upvalues[3]:
				[1]: any_Connect_result1_upvr (readonly)
				[2]: clone_upvr_3 (readonly)
				[3]: Camera_upvr_3 (readonly)
			]]
			any_Connect_result1_upvr:Disconnect()
			clone_upvr_3:Destroy()
			Camera_upvr_3:Destroy()
		end
	end
end
function module.Clear(arg1, arg2) -- Line 150
	--[[ Upvalues[1]:
		[1]: any_new_result1_upvr_2 (readonly)
	]]
	any_new_result1_upvr_2[arg2] = nil
end
return module