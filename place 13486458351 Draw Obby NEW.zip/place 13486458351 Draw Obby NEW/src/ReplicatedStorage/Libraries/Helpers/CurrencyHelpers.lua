-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:39
-- Luau version 6, Types version 3
-- Time taken: 0.000851 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local module = {}
local TableHelper_upvr = require(ReplicatedStorage.Libraries.Helpers.TableHelper)
local SharedConstants_upvr = require(ReplicatedStorage.Libraries.Modules.Constants.SharedConstants)
function module.DifferenceToProduct(arg1, arg2) -- Line 7
	--[[ Upvalues[2]:
		[1]: TableHelper_upvr (readonly)
		[2]: SharedConstants_upvr (readonly)
	]]
	local any_DeepCopy_result1 = TableHelper_upvr:DeepCopy(SharedConstants_upvr.CURRENCY_RATES)
	local var14
	for i, _ in any_DeepCopy_result1, var14 do
		any_DeepCopy_result1[i] += arg2
	end
	var14 = nil
	for i_2, v_2 in any_DeepCopy_result1 do
		if v_2 < math.huge and 0 < v_2 then
			var14 = i_2
		end
	end
	return var14
end
return module