-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:58
-- Luau version 6, Types version 3
-- Time taken: 0.001137 seconds

local module_upvr = {}
local Maid_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid)
local RunService_upvr = game:GetService("RunService")
function module_upvr.new(arg1) -- Line 10
	--[[ Upvalues[3]:
		[1]: Maid_upvr (readonly)
		[2]: RunService_upvr (readonly)
		[3]: module_upvr (readonly)
	]]
	local module_upvr_2 = {
		maid = Maid_upvr.new();
	}
	module_upvr_2.maid.effectConnection = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 15
		--[[ Upvalues[1]:
			[1]: arg1 (readonly)
		]]
		if not UserInterface:IsVisible(arg1) then
		else
			if arg1.Content.Inlay.UIGradient.Offset ~= Vector2.new(0, 0) then
				arg1.Content.Inlay.UIGradient.Rotation = -90
				return
			end
			local UIGradient = arg1.Content.Inlay.UIGradient
			UIGradient.Rotation += arg1_2 * 270
		end
	end)
	module_upvr_2.maid.parentConnection = arg1.Destroying:Connect(function() -- Line 26
		--[[ Upvalues[2]:
			[1]: module_upvr (copied, readonly)
			[2]: module_upvr_2 (readonly)
		]]
		module_upvr.Destroy(module_upvr_2)
	end)
	return module_upvr_2
end
function module_upvr.Destroy(arg1) -- Line 33
	arg1.maid:Destroy()
end
return module_upvr