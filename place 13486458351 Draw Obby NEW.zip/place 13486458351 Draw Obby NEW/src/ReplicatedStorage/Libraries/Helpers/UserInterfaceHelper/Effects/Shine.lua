-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:00
-- Luau version 6, Types version 3
-- Time taken: 0.000848 seconds

local module_upvr = {}
local Maid_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid)
local TweenService_upvr = game:GetService("TweenService")
function module_upvr.new(arg1) -- Line 10
	--[[ Upvalues[3]:
		[1]: Maid_upvr (readonly)
		[2]: TweenService_upvr (readonly)
		[3]: module_upvr (readonly)
	]]
	local module_upvr_2 = {
		maid = Maid_upvr.new();
	}
	local clone = script.Shine:Clone()
	clone.Parent = arg1
	clone.UIGradient.Offset = Vector2.new(-2, 0)
	clone.ZIndex = arg1.ZIndex + 1
	clone.BackgroundTransparency = 0
	module_upvr_2.maid.shine = clone
	TweenService_upvr:Create(clone.UIGradient, TweenInfo.new(1.2), {
		Offset = Vector2.new(2.5, 0);
	}):Play()
	task.spawn(function() -- Line 25
		--[[ Upvalues[2]:
			[1]: module_upvr (copied, readonly)
			[2]: module_upvr_2 (readonly)
		]]
		task.wait(1.2)
		module_upvr.Destroy(module_upvr_2)
	end)
	return module_upvr_2
end
function module_upvr.Destroy(arg1) -- Line 33
	arg1.maid:Destroy()
end
return module_upvr