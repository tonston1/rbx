-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:56
-- Luau version 6, Types version 3
-- Time taken: 0.001423 seconds

local module_upvr_2 = {}
local Maid_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid)
local RunService_upvr = game:GetService("RunService")
local TweenService_upvr = game:GetService("TweenService")
function module_upvr_2.new(arg1) -- Line 10
	--[[ Upvalues[4]:
		[1]: Maid_upvr (readonly)
		[2]: RunService_upvr (readonly)
		[3]: TweenService_upvr (readonly)
		[4]: module_upvr_2 (readonly)
	]]
	local module_upvr = {
		maid = Maid_upvr.new();
	}
	local var8_upvw = 0
	module_upvr.maid.effectConnection = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 18
		--[[ Upvalues[3]:
			[1]: arg1 (readonly)
			[2]: var8_upvw (read and write)
			[3]: TweenService_upvr (copied, readonly)
		]]
		if not UserInterface:IsVisible(arg1) then
		else
			var8_upvw += arg1_2
			if 0.6 <= var8_upvw then
				var8_upvw = 0
				local any_NextNumber_result1 = Random.new():NextNumber(2.5, 4)
				local clone = script["Sparkle"..Random.new():NextInteger(1, 2)]:Clone()
				clone.ImageTransparency = 0.2
				clone.ZIndex = arg1.Icon.ZIndex + Random.new():NextInteger(1, 2) * 2
				clone.Position = UDim2.new(Random.new():NextNumber(0.1, 0.9), 0, Random.new():NextNumber(0.5, 0.8), 0)
				clone.Size = UDim2.new(Random.new():NextNumber(0.2, 0.4), 0, 1, 0)
				clone.Parent = arg1
				TweenService_upvr:Create(clone, TweenInfo.new(any_NextNumber_result1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					Position = UDim2.new(clone.Position.X.Scale, 0, Random.new():NextNumber(0.05, 0.1), 0);
					ImageTransparency = 1;
				}):Play()
				task.wait(any_NextNumber_result1)
				clone:Destroy()
			end
		end
	end)
	module_upvr.maid.parentConnection = arg1.Destroying:Connect(function() -- Line 45
		--[[ Upvalues[2]:
			[1]: module_upvr_2 (copied, readonly)
			[2]: module_upvr (readonly)
		]]
		module_upvr_2.Destroy(module_upvr)
	end)
	return module_upvr
end
function module_upvr_2.Destroy(arg1) -- Line 52
	arg1.maid:Destroy()
end
return module_upvr_2