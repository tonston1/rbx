-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:57
-- Luau version 6, Types version 3
-- Time taken: 0.001030 seconds

local module_upvr_2 = {}
local Maid_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid)
local RunService_upvr = game:GetService("RunService")
local TweenService_upvr = game:GetService("TweenService")
function module_upvr_2.new(arg1) -- Line 9
	--[[ Upvalues[4]:
		[1]: Maid_upvr (readonly)
		[2]: RunService_upvr (readonly)
		[3]: TweenService_upvr (readonly)
		[4]: module_upvr_2 (readonly)
	]]
	local module_upvr = {
		maid = Maid_upvr.new();
	}
	local clone_upvr = script.Starburst:Clone()
	clone_upvr.Size = UDim2.fromScale(0, 0)
	clone_upvr.ZIndex = arg1.ZIndex + 1
	clone_upvr.Parent = arg1
	module_upvr.maid.starburst = clone_upvr
	module_upvr.maid.rotationConnection = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 19
		--[[ Upvalues[1]:
			[1]: clone_upvr (readonly)
		]]
		local var9 = clone_upvr
		var9.Rotation += arg1_2 * 100
	end)
	TweenService_upvr:Create(clone_upvr, TweenInfo.new(1), {
		Size = UDim2.fromScale(5, 5);
		ImageTransparency = 1;
	}):Play()
	task.spawn(function() -- Line 27
		--[[ Upvalues[2]:
			[1]: module_upvr_2 (copied, readonly)
			[2]: module_upvr (readonly)
		]]
		task.wait(0.5)
		task.wait(0.5)
		module_upvr_2.Destroy(module_upvr)
	end)
	return module_upvr
end
function module_upvr_2.Destroy(arg1) -- Line 40
	arg1.maid:Destroy()
end
return module_upvr_2