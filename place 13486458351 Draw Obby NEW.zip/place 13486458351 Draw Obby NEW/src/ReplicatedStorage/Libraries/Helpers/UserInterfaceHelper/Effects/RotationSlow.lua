-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:59
-- Luau version 6, Types version 3
-- Time taken: 0.001101 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local module_upvr_2 = {}
local Maid_upvr = require(ReplicatedStorage.Libraries.Classes.Maid)
local RunService_upvr = game:GetService("RunService")
local UserInterfaceHelper_upvr = require(ReplicatedStorage.Libraries.Helpers.UserInterfaceHelper)
function module_upvr_2.new(arg1) -- Line 11
	--[[ Upvalues[4]:
		[1]: Maid_upvr (readonly)
		[2]: RunService_upvr (readonly)
		[3]: UserInterfaceHelper_upvr (readonly)
		[4]: module_upvr_2 (readonly)
	]]
	local module_upvr = {
		maid = Maid_upvr.new();
	}
	local Content_upvr = arg1:FindFirstChild("Content")
	if not Content_upvr then
		warn("Didn't find content in the gui")
		return
	end
	module_upvr.maid.effectConnection = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 20
		--[[ Upvalues[3]:
			[1]: UserInterfaceHelper_upvr (copied, readonly)
			[2]: arg1 (readonly)
			[3]: Content_upvr (readonly)
		]]
		if not UserInterfaceHelper_upvr:IsVisible(arg1) then
		else
			if Content_upvr.Inlay.UIGradient.Offset ~= Vector2.new(0, 0) then
				Content_upvr.Inlay.UIGradient.Rotation = -90
				return
			end
			local UIGradient = Content_upvr.Inlay.UIGradient
			UIGradient.Rotation += arg1_2 * 27
		end
	end)
	module_upvr.maid.parentConnection = arg1.Destroying:Connect(function() -- Line 31
		--[[ Upvalues[2]:
			[1]: module_upvr_2 (copied, readonly)
			[2]: module_upvr (readonly)
		]]
		module_upvr_2.Destroy(module_upvr)
	end)
	return module_upvr
end
function module_upvr_2.Destroy(arg1) -- Line 38
	arg1.maid:Destroy()
end
return module_upvr_2