-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:55
-- Luau version 6, Types version 3
-- Time taken: 0.001474 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local module_upvr = {}
local Maid_upvr = require(ReplicatedStorage.Libraries.Classes.Maid)
local RunService_upvr = game:GetService("RunService")
local UserInterfaceHelper_upvr = require(ReplicatedStorage.Libraries.Helpers.UserInterfaceHelper)
function module_upvr.new(arg1) -- Line 11
	--[[ Upvalues[4]:
		[1]: Maid_upvr (readonly)
		[2]: RunService_upvr (readonly)
		[3]: UserInterfaceHelper_upvr (readonly)
		[4]: module_upvr (readonly)
	]]
	local module_upvr_2 = {
		maid = Maid_upvr.new();
	}
	local clone_upvr = script.Starburst:Clone()
	clone_upvr.ZIndex = arg1.ZIndex + 1
	clone_upvr.Parent = arg1
	module_upvr_2.maid.starburst = clone_upvr
	module_upvr_2.maid.effectConnection = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 20
		--[[ Upvalues[3]:
			[1]: UserInterfaceHelper_upvr (copied, readonly)
			[2]: arg1 (readonly)
			[3]: clone_upvr (readonly)
		]]
		if not UserInterfaceHelper_upvr:IsVisible(arg1) then
		else
			local var9 = clone_upvr
			var9.Rotation += arg1_2 * 27
		end
	end)
	module_upvr_2.maid.parentConnection = arg1.Destroying:Connect(function() -- Line 27
		--[[ Upvalues[2]:
			[1]: module_upvr (copied, readonly)
			[2]: module_upvr_2 (readonly)
		]]
		module_upvr.Destroy(module_upvr_2)
	end)
	return module_upvr_2
end
function module_upvr.SetZIndex(arg1, arg2) -- Line 34
	arg1.maid.starburst.ZIndex = arg2
end
function module_upvr.SetColor(arg1, arg2) -- Line 38
	arg1.maid.starburst.ImageColor3 = arg2
end
function module_upvr.SetTransparency(arg1, arg2) -- Line 42
	arg1.maid.starburst.ImageTransparency = arg2
end
local TweenService_upvr = game:GetService("TweenService")
function module_upvr.TweenTransparency(arg1, arg2, arg3) -- Line 46
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	local tbl = {}
	tbl.ImageTransparency = arg2
	TweenService_upvr:Create(arg1.maid.starburst, arg3, tbl):Play()
end
function module_upvr.Destroy(arg1) -- Line 52
	arg1.maid:Destroy()
end
return module_upvr