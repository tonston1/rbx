-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:54
-- Luau version 6, Types version 3
-- Time taken: 0.004600 seconds

local any_new_result1_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid).new()
local module = {}
local Effects_upvr = script.Effects
function module.Effect(arg1, arg2) -- Line 20
	--[[ Upvalues[1]:
		[1]: Effects_upvr (readonly)
	]]
	local SOME = Effects_upvr:FindFirstChild(arg2)
	if not SOME then return end
	return require(SOME)
end
function module.IsVisible(arg1, arg2) -- Line 28
	local var5 = arg2
	if var5 then
		var5 = arg2:FindFirstAncestorWhichIsA("ScreenGui")
	end
	if not var5 then
		return false
	end
	if not var5.Enabled then
		return false
	end
	while arg2 ~= var5 and arg2 ~= nil do
		if arg2:IsA("GuiObject") and arg2.Visible == false then
			return false
		end
	end
	return true
end
function module.FitFrame(arg1, arg2, arg3, arg4) -- Line 46
	--[[ Upvalues[1]:
		[1]: any_new_result1_upvr (readonly)
	]]
	local class_UIListLayout_upvr = arg2:FindFirstChildOfClass("UIListLayout")
	if not class_UIListLayout_upvr then
		class_UIListLayout_upvr = arg2:FindFirstChildOfClass("UIGridLayout")
	end
	if not class_UIListLayout_upvr then
		warn("No layout found in ", arg2:GetFullName())
	else
		local var7_upvr = arg3 or 'Y'
		local function setSize() -- Line 52
			--[[ Upvalues[4]:
				[1]: var7_upvr (readonly)
				[2]: class_UIListLayout_upvr (readonly)
				[3]: arg4 (readonly)
				[4]: arg2 (readonly)
			]]
			local var8
			local function INLINED() -- Internal function, doesn't exist in bytecode
				var8 = class_UIListLayout_upvr.AbsoluteContentSize.Y
				return var8
			end
			if var7_upvr ~= 'Y' or not INLINED() then
				var8 = class_UIListLayout_upvr.AbsoluteContentSize.X
			end
			if var8 ~= 0 then
			end
			local function INLINED_2() -- Internal function, doesn't exist in bytecode
				var8 = UDim2.new(0, 0, 0, class_UIListLayout_upvr.AbsoluteContentSize.Y)
				return var8
			end
			if var7_upvr ~= 'Y' or not INLINED_2() then
				var8 = UDim2.new(0, class_UIListLayout_upvr.AbsoluteContentSize.X, 0, 0)
			end
			var8 += arg4
			arg2.Size = var8
		end
		setSize()
		any_new_result1_upvr[arg2] = class_UIListLayout_upvr:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(setSize)
	end
end
function module.FitScrollingFrame(arg1, arg2, arg3, arg4) -- Line 68
	--[[ Upvalues[1]:
		[1]: any_new_result1_upvr (readonly)
	]]
	local class_UIListLayout_upvr_2 = arg2:FindFirstChildOfClass("UIListLayout")
	if not class_UIListLayout_upvr_2 then
		class_UIListLayout_upvr_2 = arg2:FindFirstChildOfClass("UIGridLayout")
	end
	if not class_UIListLayout_upvr_2 then
		warn("No layout found in ", arg2:GetFullName())
	else
		local var10_upvr = arg3 or 'Y'
		local function setSize() -- Line 74
			--[[ Upvalues[4]:
				[1]: var10_upvr (readonly)
				[2]: class_UIListLayout_upvr_2 (readonly)
				[3]: arg4 (readonly)
				[4]: arg2 (readonly)
			]]
			local var11
			local function INLINED_3() -- Internal function, doesn't exist in bytecode
				var11 = class_UIListLayout_upvr_2.AbsoluteContentSize.Y
				return var11
			end
			if var10_upvr ~= 'Y' or not INLINED_3() then
				var11 = class_UIListLayout_upvr_2.AbsoluteContentSize.X
			end
			if var11 == 0 then
			else
				local function INLINED_4() -- Internal function, doesn't exist in bytecode
					var11 = UDim2.new(0, 0, 0, class_UIListLayout_upvr_2.AbsoluteContentSize.Y)
					return var11
				end
				if var10_upvr ~= 'Y' or not INLINED_4() then
					var11 = UDim2.new(0, class_UIListLayout_upvr_2.AbsoluteContentSize.X, 0, 0)
				end
				var11 += arg4
				arg2.CanvasSize = var11
			end
		end
		setSize()
		any_new_result1_upvr[arg2] = class_UIListLayout_upvr_2:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(setSize)
	end
end
function module.StopAutomaticFit(arg1, arg2) -- Line 86
	--[[ Upvalues[1]:
		[1]: any_new_result1_upvr (readonly)
	]]
	any_new_result1_upvr[arg2] = nil
end
function module.ScrollTo(arg1, arg2, arg3, arg4, arg5) -- Line 90
	if arg4 == 'Y' then
		arg3.CanvasPosition = Vector2.new(0, arg2.AbsolutePosition.Y - arg3.AbsolutePosition.Y + arg3.CanvasPosition.Y)
	elseif arg4 == 'X' then
		if arg5 == "Middle" then
			arg3.CanvasPosition = Vector2.new((arg3.CanvasPosition.X) + (arg2.AbsolutePosition.X - arg3.AbsolutePosition.X) - arg3.AbsoluteSize.X / 2 + arg2.AbsoluteSize.X / 2, 0)
			return
		end
		if arg5 ~= "End" then
		end
	end
end
local script_upvr = script
function module.ViewportEmote(arg1, arg2, arg3) -- Line 112
	--[[ Upvalues[2]:
		[1]: script_upvr (readonly)
		[2]: any_new_result1_upvr (readonly)
	]]
	local Camera_upvr = Instance.new("Camera")
	Camera_upvr.Parent = arg2
	local WorldModel_upvr = Instance.new("WorldModel")
	WorldModel_upvr.Parent = arg2
	local clone_upvr = script_upvr.Rig:Clone()
	local AnimationController_upvr = Instance.new("AnimationController")
	AnimationController_upvr.Parent = clone_upvr
	local Animator = Instance.new("Animator")
	Animator.Parent = AnimationController_upvr
	Camera_upvr.CFrame = CFrame.new(clone_upvr.HumanoidRootPart.Position + Vector3.new(0, 1, 0) + clone_upvr.HumanoidRootPart.CFrame.LookVector * 5, clone_upvr.HumanoidRootPart.Position)
	arg2.CurrentCamera = Camera_upvr
	clone_upvr.Parent = workspace
	local any_LoadAnimation_result1_upvr = Animator:LoadAnimation(arg3)
	any_LoadAnimation_result1_upvr.Looped = true
	any_LoadAnimation_result1_upvr:Play()
	clone_upvr.Parent = WorldModel_upvr
	any_new_result1_upvr[arg2] = function() -- Line 136
		--[[ Upvalues[5]:
			[1]: any_LoadAnimation_result1_upvr (readonly)
			[2]: clone_upvr (readonly)
			[3]: WorldModel_upvr (readonly)
			[4]: Camera_upvr (readonly)
			[5]: AnimationController_upvr (readonly)
		]]
		any_LoadAnimation_result1_upvr:Destroy()
		clone_upvr:Destroy()
		WorldModel_upvr:Destroy()
		Camera_upvr:Destroy()
		AnimationController_upvr:Destroy()
	end
end
function module.ViewportModel(arg1, arg2, arg3) -- Line 146
	--[[ Upvalues[1]:
		[1]: any_new_result1_upvr (readonly)
	]]
	local clone = arg3:Clone()
	clone.Parent = arg2
	local Camera_upvr_2 = Instance.new("Camera")
	Camera_upvr_2.Parent = arg2
	Camera_upvr_2.CFrame = clone.PrimaryPart.CFrame * clone:FindFirstChild("Camera").Value
	arg2.CurrentCamera = Camera_upvr_2
	any_new_result1_upvr[arg2] = function() -- Line 158
		--[[ Upvalues[1]:
			[1]: Camera_upvr_2 (readonly)
		]]
		Camera_upvr_2:Destroy()
	end
end
local StarterGui_upvr = game:GetService("StarterGui")
function module.CoreGuiEnable(arg1, arg2) -- Line 164
	--[[ Upvalues[1]:
		[1]: StarterGui_upvr (readonly)
	]]
	task.spawn(function() -- Line 165
		--[[ Upvalues[2]:
			[1]: arg2 (readonly)
			[2]: StarterGui_upvr (copied, readonly)
		]]
		for _ = 1, 10 do
			local pcall_result1, _ = pcall(function() -- Line 167
				--[[ Upvalues[2]:
					[1]: arg2 (copied, readonly)
					[2]: StarterGui_upvr (copied, readonly)
				]]
				for i_2, v in pairs(arg2) do
					StarterGui_upvr:SetCoreGuiEnabled(i_2, v)
				end
			end)
			if pcall_result1 then break end
			task.wait(1)
		end
	end)
end
return module