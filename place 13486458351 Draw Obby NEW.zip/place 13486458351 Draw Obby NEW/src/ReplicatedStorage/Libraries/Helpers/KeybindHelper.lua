-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:40
-- Luau version 6, Types version 3
-- Time taken: 0.002373 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local module = {
	ConvertValueToDesktop = function(arg1, arg2, arg3) -- Line 18, Named "ConvertValueToDesktop"
		local var3 = arg2.Data.configuration.desktopKeybinds[arg3]
		local var4 = var3
		if var4 then
			var4 = Enum.KeyCode:FromValue(var3)
		end
		return var4
	end;
	ConvertValueToConsole = function(arg1, arg2, arg3) -- Line 24, Named "ConvertValueToConsole"
		local var5 = arg2.Data.configuration.consoleKeybinds[arg3]
		local var6 = var5
		if var6 then
			var6 = Enum.KeyCode:FromValue(var5)
		end
		return var6
	end;
}
local Profiles_upvr = require(ReplicatedStorage.Libraries.Modules.Profiles)
local Device_upvr = require(ReplicatedStorage.Libraries.Modules.Device)
function module.IsToggleable(arg1, arg2) -- Line 30
	--[[ Upvalues[2]:
		[1]: Profiles_upvr (readonly)
		[2]: Device_upvr (readonly)
	]]
	local any_GetPlayerReplica_result1 = Profiles_upvr:GetPlayerReplica(arg2)
	local var10
	if Device_upvr:Get() == "Desktop" then
		if any_GetPlayerReplica_result1.Data.configuration.desktopKeybinds.holdDown ~= "Toggle" then
			var10 = false
		else
			var10 = true
		end
		return var10
	end
	if Device_upvr:Get() == "Console" then
		if any_GetPlayerReplica_result1.Data.configuration.consoleKeybinds.holdDown ~= "Toggle" then
			var10 = false
		else
			var10 = true
		end
		return var10
	end
	if Device_upvr:Get() == "Mobile" then
		var10 = true
	end
	return var10
end
local Players_upvr = game:GetService("Players")
function module.FindCorrespondingKeybindFrame(arg1, arg2) -- Line 46
	--[[ Upvalues[1]:
		[1]: Players_upvr (readonly)
	]]
	local Controls = Players_upvr.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("GameUI").Controls
	for _, v in {Controls.Keybinds, Controls.Specials} do
		for _, v_2 in v:GetChildren(), nil do
			if v_2:FindFirstChild("Keybind") then
				for _, v_3 in v_2:GetChildren(), nil do
					if v_3.Name == "Keybind" then
						local datastoreKey = v_3:GetAttribute("datastoreKey")
						if datastoreKey and datastoreKey == arg2 then
							table.insert({}, v_3)
						end
					end
				end
			end
		end
	end
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	return {}
end
return module