-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:44
-- Luau version 6, Types version 3
-- Time taken: 0.000345 seconds

return {
	CreatePartAtVector3 = function(arg1) -- Line 4, Named "CreatePartAtVector3"
		local Part = Instance.new("Part")
		Part.Size = Vector3.new(4, 1, 4)
		Part.Anchored = true
		Part.Position = arg1
		Part.Color = Color3.new(1, 0, 0)
		Part.Parent = workspace
		return Part
	end;
}