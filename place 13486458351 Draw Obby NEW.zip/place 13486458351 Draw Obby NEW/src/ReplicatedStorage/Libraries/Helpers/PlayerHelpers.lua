-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:36
-- Luau version 6, Types version 3
-- Time taken: 0.002215 seconds

local Players_upvr = game:GetService("Players")
return {
	GetName = function(arg1) -- Line 13, Named "GetName"
		if not arg1 then
			return ""
		end
		if arg1.DisplayName ~= arg1.Name or not arg1.Name then
		end
		return arg1.DisplayName.." @"..arg1.Name..""
	end;
	GetProfileIcon = function(arg1) -- Line 19, Named "GetProfileIcon"
		--[[ Upvalues[1]:
			[1]: Players_upvr (readonly)
		]]
		if not arg1 then
			return ""
		end
		local tostring_result1_upvr = tostring(arg1.UserId)
		local HeadShot_upvr = Enum.ThumbnailType.HeadShot
		local Size420x420_upvr = Enum.ThumbnailSize.Size420x420
		local pcall_result1, pcall_result2 = pcall(function() -- Line 27
			--[[ Upvalues[4]:
				[1]: Players_upvr (copied, readonly)
				[2]: tostring_result1_upvr (readonly)
				[3]: HeadShot_upvr (readonly)
				[4]: Size420x420_upvr (readonly)
			]]
			local any_GetUserThumbnailAsync_result1, _ = Players_upvr:GetUserThumbnailAsync(tostring_result1_upvr, HeadShot_upvr, Size420x420_upvr)
			return any_GetUserThumbnailAsync_result1
		end)
		return pcall_result2
	end;
	GetPlayerCharacter = function() -- Line 36, Named "GetPlayerCharacter"
		--[[ Upvalues[1]:
			[1]: Players_upvr (readonly)
		]]
		local Character_4 = Players_upvr.LocalPlayer.Character
		if not Character_4 then
			Character_4 = Players_upvr.LocalPlayer.CharacterAdded:Wait()
		end
		return Character_4
	end;
	GetPlayerHumanoid = function() -- Line 41, Named "GetPlayerHumanoid"
		--[[ Upvalues[1]:
			[1]: Players_upvr (readonly)
		]]
		local Character_3 = Players_upvr.LocalPlayer.Character
		if not Character_3 then
			Character_3 = Players_upvr.LocalPlayer.CharacterAdded:Wait()
		end
		return Character_3:FindFirstChild("Humanoid")
	end;
	GetPlayerHRP = function() -- Line 48, Named "GetPlayerHRP"
		--[[ Upvalues[1]:
			[1]: Players_upvr (readonly)
		]]
		local Character = Players_upvr.LocalPlayer.Character
		if not Character then
			Character = Players_upvr.LocalPlayer.CharacterAdded:Wait()
		end
		return Character.PrimaryPart
	end;
	GetPlayerByUsername = function(arg1, arg2) -- Line 54, Named "GetPlayerByUsername"
		--[[ Upvalues[1]:
			[1]: Players_upvr (readonly)
		]]
		for _, v in Players_upvr:GetPlayers(), nil do
			if string.lower(v.Name) == string.lower(arg2) then
				return v
			end
		end
		return nil
	end;
	GetPlayerFromPart = function(arg1, arg2) -- Line 64, Named "GetPlayerFromPart"
		--[[ Upvalues[1]:
			[1]: Players_upvr (readonly)
		]]
		for _, v_2 in Players_upvr:GetPlayers(), nil do
			local Character_2 = v_2.Character
			if Character_2 and arg2:IsDescendantOf(Character_2) then
				return v_2
			end
		end
		return nil
	end;
}