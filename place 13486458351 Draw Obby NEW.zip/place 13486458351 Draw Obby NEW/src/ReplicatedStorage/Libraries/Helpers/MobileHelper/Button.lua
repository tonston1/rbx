-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:49
-- Luau version 6, Types version 3
-- Time taken: 0.004895 seconds

local PlayerGui_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local module_upvr = {}
module_upvr.__index = module_upvr
local Button_upvr = script.Button
local module_upvr_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Maid"))
local CurrentCamera_upvr = workspace.CurrentCamera
function module_upvr.new(arg1, arg2, arg3, arg4, arg5, arg6) -- Line 15
	--[[ Upvalues[5]:
		[1]: module_upvr (readonly)
		[2]: Button_upvr (readonly)
		[3]: PlayerGui_upvr (readonly)
		[4]: module_upvr_2 (readonly)
		[5]: CurrentCamera_upvr (readonly)
	]]
	local setmetatable_result1_upvr = setmetatable({}, module_upvr)
	setmetatable_result1_upvr.enabled = false
	setmetatable_result1_upvr.pressed = false
	setmetatable_result1_upvr.image = arg1
	setmetatable_result1_upvr.imageDown = arg2
	setmetatable_result1_upvr.imageCountdown = arg5
	setmetatable_result1_upvr.scale = arg3
	setmetatable_result1_upvr.button = Button_upvr:Clone()
	setmetatable_result1_upvr.button.Image = arg1
	local JumpButton_3_upvr = PlayerGui_upvr:WaitForChild("TouchGui"):WaitForChild("TouchControlFrame"):WaitForChild("JumpButton")
	setmetatable_result1_upvr.button.Parent = PlayerGui_upvr:WaitForChild("TouchGui")
	setmetatable_result1_upvr.text = ""
	setmetatable_result1_upvr:SetText(arg6)
	setmetatable_result1_upvr.maid = module_upvr_2.new()
	local function update() -- Line 39
		--[[ Upvalues[4]:
			[1]: setmetatable_result1_upvr (readonly)
			[2]: JumpButton_3_upvr (readonly)
			[3]: arg4 (readonly)
			[4]: arg3 (readonly)
		]]
		setmetatable_result1_upvr.button.Position = JumpButton_3_upvr.Position - UDim2.new(0, JumpButton_3_upvr.Size.Y.Offset * arg4.X, 0, JumpButton_3_upvr.Size.Y.Offset * arg4.Y)
		setmetatable_result1_upvr.button.Size = UDim2.new(JumpButton_3_upvr.Size.X.Scale * arg3, JumpButton_3_upvr.Size.X.Offset * arg3, JumpButton_3_upvr.Size.Y.Scale * arg3, JumpButton_3_upvr.Size.Y.Offset * arg3)
	end
	update()
	setmetatable_result1_upvr.maid.viewportSizeChange = CurrentCamera_upvr:GetPropertyChangedSignal("ViewportSize"):Connect(update)
	setmetatable_result1_upvr.maid.jumpButtonPositionChange = JumpButton_3_upvr:GetPropertyChangedSignal("AbsolutePosition"):Connect(update)
	setmetatable_result1_upvr.maid.jumpButtonSizeChange = JumpButton_3_upvr:GetPropertyChangedSignal("AbsoluteSize"):Connect(update)
	if setmetatable_result1_upvr.imageCountdown then
		setmetatable_result1_upvr.button.Countdown.Icon.Image = setmetatable_result1_upvr.imageCountdown
	end
	setmetatable_result1_upvr.activatedEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Activated = setmetatable_result1_upvr.activatedEvent.Event
	setmetatable_result1_upvr.deactivatedEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Deactivated = setmetatable_result1_upvr.deactivatedEvent.Event
	setmetatable_result1_upvr.enabledEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Enabled = setmetatable_result1_upvr.enabledEvent.Event
	setmetatable_result1_upvr.disabledEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Disabled = setmetatable_result1_upvr.disabledEvent.Event
	setmetatable_result1_upvr.changedEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Changed = setmetatable_result1_upvr.changedEvent.Event
	setmetatable_result1_upvr.destroyedEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Destroyed = setmetatable_result1_upvr.destroyedEvent.Event
	setmetatable_result1_upvr.lastActivated = tick()
	setmetatable_result1_upvr.holdEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Held = setmetatable_result1_upvr.holdEvent.Event
	setmetatable_result1_upvr:Enable()
	return setmetatable_result1_upvr
end
function module_upvr.SetText(arg1, arg2) -- Line 73
	arg1.text = arg2 or ""
	arg1.button.Name = arg1.text
	arg1.button.TextLabel.Text = arg1.text
end
function module_upvr.Countdown(arg1, arg2, arg3) -- Line 79
	if 0 < arg2 then
		arg1.button.Countdown.Size = UDim2.new(1, 0, arg3, 0)
		arg1.button.Countdown.Icon.Size = UDim2.new(1, 0, 1 / arg3, 0)
		arg1.button.Timer.Text = tostring(arg2)
	else
		arg1.button.Countdown.Size = UDim2.new(1, 0, 0, 0)
		arg1.button.Countdown.Icon.Size = UDim2.new(1, 0, 0, 0)
		arg1.button.Timer.Text = ""
	end
end
function module_upvr.Enable(arg1) -- Line 92
	if arg1.enabled then
	else
		arg1.maid.inputStart = arg1.button.MouseButton1Down:Connect(function() -- Line 95
			--[[ Upvalues[1]:
				[1]: arg1 (readonly)
			]]
			arg1:ForceActivate()
		end)
		arg1.maid.inputEnd = arg1.button.InputEnded:Connect(function(arg1_2) -- Line 99
			--[[ Upvalues[1]:
				[1]: arg1 (readonly)
			]]
			if arg1_2.UserInputType == Enum.UserInputType.Touch then
				arg1:ForceDeactivate()
			end
		end)
		arg1.enabled = true
		arg1.enabledEvent:Fire()
	end
end
function module_upvr.Disable(arg1) -- Line 110
	if not arg1.enabled then
	else
		arg1.maid.inputStart = nil
		arg1.maid.inputEnd = nil
		arg1:ForceDeactivate()
		arg1.enabled = false
		arg1.disabledEvent:Fire()
	end
end
local RunService_upvr = game:GetService("RunService")
function module_upvr.ForceActivate(arg1) -- Line 122
	--[[ Upvalues[1]:
		[1]: RunService_upvr (readonly)
	]]
	if arg1.activated then
	else
		arg1.activated = true
		arg1.lastActivated = tick()
		arg1.activatedEvent:Fire()
		arg1.holdConnect = RunService_upvr.Heartbeat:Connect(function() -- Line 128
			--[[ Upvalues[1]:
				[1]: arg1 (readonly)
			]]
			arg1.holdEvent:Fire(tick() - arg1.lastActivated)
		end)
	end
end
function module_upvr.ForceDeactivate(arg1) -- Line 134
	if not arg1.activated then
	else
		arg1.activated = false
		arg1.deactivatedEvent:Fire(tick() - arg1.lastActivated)
		if arg1.holdConnect then
			arg1.holdConnect:Disconnect()
			arg1.holdConnect = nil
		end
	end
end
function module_upvr.Press(arg1) -- Line 146
	arg1.pressed = true
	arg1.button.Image = arg1.imageDown
end
function module_upvr.Release(arg1) -- Line 154
	arg1.pressed = false
	arg1.button.Image = arg1.image
end
function module_upvr.Change(arg1, arg2, arg3, arg4, arg5) -- Line 162
	--[[ Upvalues[1]:
		[1]: PlayerGui_upvr (readonly)
	]]
	local JumpButton_2 = PlayerGui_upvr:WaitForChild("TouchGui"):WaitForChild("TouchControlFrame"):WaitForChild("JumpButton")
	if arg2 then
		arg1.image = arg2
		if not arg1.pressed then
			arg1:Release()
		end
	end
	if arg3 then
		arg1.imageDown = arg3
		if arg1.pressed then
			arg1:Press()
		end
	end
	if arg4 then
		arg1.button.Size = UDim2.new(JumpButton_2.Size.X.Scale * arg4, JumpButton_2.Size.X.Offset * arg4, JumpButton_2.Size.Y.Scale * arg4, JumpButton_2.Size.Y.Offset * arg4)
		arg1.scale = arg4
	end
	if arg5 then
		arg1.button.Position = JumpButton_2.Position - UDim2.new(0, JumpButton_2.Size.Y.Offset * arg5.X, 0, JumpButton_2.Size.Y.Offset * arg5.Y)
	end
	arg1.changedEvent:Fire()
end
function module_upvr.SetVisible(arg1, arg2) -- Line 192
	arg1.button.Visible = arg2
end
function module_upvr.Destroy(arg1) -- Line 197
	arg1.destroyedEvent:Fire()
	arg1.button:Destroy()
	arg1.activatedEvent:Destroy()
	arg1.deactivatedEvent:Destroy()
	arg1.maid:Destroy()
end
function module_upvr.GetButton(arg1) -- Line 205
	return arg1.button
end
function module_upvr.GetOffset(arg1) -- Line 209
	--[[ Upvalues[1]:
		[1]: PlayerGui_upvr (readonly)
	]]
	local JumpButton_4 = PlayerGui_upvr:WaitForChild("TouchGui"):WaitForChild("TouchControlFrame"):WaitForChild("JumpButton")
	local AbsolutePosition_2 = JumpButton_4.AbsolutePosition
	local AbsolutePosition = arg1.button.AbsolutePosition
	local Y = JumpButton_4.AbsoluteSize.Y
	return Vector2.new((AbsolutePosition_2.X - AbsolutePosition.X) / Y, (AbsolutePosition_2.Y - AbsolutePosition.Y) / Y)
end
return module_upvr