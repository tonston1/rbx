-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:48
-- Luau version 6, Types version 3
-- Time taken: 0.001290 seconds

local BindableEvent_upvr_2 = Instance.new("BindableEvent")
local module_upvr = {}
local module_upvr_2 = {
	ButtonCreated = BindableEvent_upvr_2.Event;
	CreateButton = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) -- Line 12, Named "CreateButton"
		--[[ Upvalues[2]:
			[1]: module_upvr (readonly)
			[2]: BindableEvent_upvr_2 (readonly)
		]]
		local any_new_result1 = require(script.Button).new(arg3, arg4, arg5, arg6, arg7, arg8)
		module_upvr[arg2] = any_new_result1
		any_new_result1.Destroyed:Connect(function() -- Line 18
			--[[ Upvalues[2]:
				[1]: module_upvr (copied, readonly)
				[2]: arg2 (readonly)
			]]
			if module_upvr[arg2] then
				module_upvr[arg2] = nil
			end
		end)
		BindableEvent_upvr_2:Fire(arg2)
		return any_new_result1
	end;
	GetButton = function(arg1, arg2) -- Line 29, Named "GetButton"
		--[[ Upvalues[1]:
			[1]: module_upvr (readonly)
		]]
		return module_upvr[arg2]
	end;
}
function module_upvr_2.GetButtonsById(arg1, arg2) -- Line 33
	--[[ Upvalues[1]:
		[1]: module_upvr_2 (readonly)
	]]
	for i, _ in arg2 do
		local any_GetButton_result1 = module_upvr_2:GetButton(i)
		if any_GetButton_result1 then
			({})[i] = any_GetButton_result1
		end
	end
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	return {}
end
function module_upvr_2.GetButtons(arg1) -- Line 53
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	return module_upvr
end
function module_upvr_2.WaitForButton(arg1, arg2) -- Line 57
	--[[ Upvalues[2]:
		[1]: module_upvr_2 (readonly)
		[2]: module_upvr (readonly)
	]]
	if not module_upvr_2:GetButton(arg2) then
		local BindableEvent_upvr = Instance.new("BindableEvent")
		module_upvr_2.ButtonCreated:Connect(function(arg1_2) -- Line 61
			--[[ Upvalues[2]:
				[1]: arg2 (readonly)
				[2]: BindableEvent_upvr (readonly)
			]]
			if arg2 == arg1_2 then
				BindableEvent_upvr:Fire()
			end
		end)
	else
		return module_upvr[arg2]
	end
	BindableEvent_upvr.Event:Wait()
	return module_upvr[arg2]
end
return module_upvr_2