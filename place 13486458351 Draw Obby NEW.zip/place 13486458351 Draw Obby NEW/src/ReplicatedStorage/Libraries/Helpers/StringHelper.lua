-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:45
-- Luau version 6, Types version 3
-- Time taken: 0.000364 seconds

return {
	Capitalize = function(arg1) -- Line 4, Named "Capitalize"
		return arg1:gsub("^%a", string.upper)
	end;
	RemovePlural = function(arg1) -- Line 8, Named "RemovePlural"
		return string.sub(arg1, 1, arg1:len() - 1)
	end;
}