-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:43
-- Luau version 6, Types version 3
-- Time taken: 0.001405 seconds

local Profiles_upvr = require(game:GetService("ReplicatedStorage").Libraries.Modules.Profiles)
return {
	AddValues = function(arg1, arg2, arg3, arg4) -- Line 13, Named "AddValues"
		--[[ Upvalues[1]:
			[1]: Profiles_upvr (readonly)
		]]
		-- KONSTANTERROR: [0] 1. Error Block 19 start (CF ANALYSIS FAILED)
		local any_GetPlayerReplica_result1 = Profiles_upvr:GetPlayerReplica(arg2)
		local var4 = any_GetPlayerReplica_result1
		if var4 then
			var4 = any_GetPlayerReplica_result1.Data[arg4]
		end
		if not any_GetPlayerReplica_result1 then return end
		if not var4 then return end
		-- KONSTANTERROR: [0] 1. Error Block 19 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [39] 30. Error Block 14 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [39] 30. Error Block 14 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [19] 18. Error Block 23 start (CF ANALYSIS FAILED)
		if arg3 then
			-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [39.13]
			-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [39.12]
			if nil <= nil and nil <= nil then
				-- KONSTANTWARNING: GOTO [39] #30
			end
		else
		end
		-- KONSTANTERROR: [19] 18. Error Block 23 end (CF ANALYSIS FAILED)
	end;
	HighestValue = function(arg1, arg2, arg3, arg4) -- Line 35, Named "HighestValue"
		--[[ Upvalues[1]:
			[1]: Profiles_upvr (readonly)
		]]
		-- KONSTANTERROR: [0] 1. Error Block 22 start (CF ANALYSIS FAILED)
		local any_GetPlayerReplica_result1_2 = Profiles_upvr:GetPlayerReplica(arg2)
		local var6 = any_GetPlayerReplica_result1_2
		if var6 then
			var6 = any_GetPlayerReplica_result1_2.Data[arg4]
		end
		if not any_GetPlayerReplica_result1_2 then return end
		if not var6 then return end
		local var7
		-- KONSTANTERROR: [0] 1. Error Block 22 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [48] 35. Error Block 16 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [48] 35. Error Block 16 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [20] 19. Error Block 26 start (CF ANALYSIS FAILED)
		if arg3 then
			-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [48.14]
			-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [48.13]
			if nil <= nil and nil <= nil and var7 < nil then
				-- KONSTANTWARNING: GOTO [48] #35
			end
		elseif var7 < nil then
		end
		-- KONSTANTERROR: [20] 19. Error Block 26 end (CF ANALYSIS FAILED)
	end;
}