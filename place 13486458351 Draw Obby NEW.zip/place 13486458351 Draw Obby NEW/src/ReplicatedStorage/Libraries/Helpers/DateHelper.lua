-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:43
-- Luau version 6, Types version 3
-- Time taken: 0.000965 seconds

return {
	IsWeekendUTCAligned = function(arg1) -- Line 3, Named "IsWeekendUTCAligned"
		local os_date_result1 = os.date("!*t", os.time())
		local wday_2 = os_date_result1.wday
		if wday_2 == 6 and 18 <= os_date_result1.hour then
			return true
		end
		if wday_2 == 7 then
			return true
		end
		if wday_2 == 1 then
			-- KONSTANTERROR: Expression was reused, decompilation is incorrect
			if os_date_result1.hour < 24 then
				return true
			end
		end
		return false
	end;
	GetWeekKey = function(arg1, arg2) -- Line 20, Named "GetWeekKey"
		local os_date_result1_2 = os.date("!*t", os.time() + (arg2 or 0))
		os_date_result1_2.day -= os_date_result1_2.wday - 1
		os_date_result1_2.hour = 0
		os_date_result1_2.min = 0
		os_date_result1_2.sec = 0
		return os.time(os_date_result1_2)
	end;
}