-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:46
-- Luau version 6, Types version 3
-- Time taken: 0.003643 seconds

local RunService_upvr = game:GetService("RunService")
local Players_upvr = game:GetService("Players")
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
local CurrentCamera_upvr = workspace.CurrentCamera
local any_new_result1_upvr = require(ReplicatedStorage_upvr.Libraries.Classes.Maid).new()
local var6_upvw
local var7_upvw = false
local module_upvr = {}
local function _(arg1) -- Line 19, Named "getPlayerData"
	if not arg1 then
		warn("no plr passed")
		return nil
	end
	if not arg1:IsA("Player") then
		warn("player isn't even a player")
		return nil
	end
	local var9 = arg1
	if var9 then
		var9 = arg1.UserId
	end
	local var10 = arg1
	if var10 then
		var10 = arg1.Character
	end
	local var11 = var10
	if var11 then
		var11 = var10:WaitForChild("HumanoidRootPart")
	end
	local var12 = var10
	if var12 then
		var12 = var10:FindFirstChildWhichIsA("Humanoid")
	end
	return var9, var10, var12, var11
end
local Device_upvr = require(ReplicatedStorage_upvr.Libraries.Modules.Device)
function module_upvr.SetSubject(arg1, arg2, arg3) -- Line 32
	--[[ Upvalues[7]:
		[1]: var7_upvw (read and write)
		[2]: ReplicatedStorage_upvr (readonly)
		[3]: any_new_result1_upvr (readonly)
		[4]: CurrentCamera_upvr (readonly)
		[5]: Device_upvr (readonly)
		[6]: Players_upvr (readonly)
		[7]: RunService_upvr (readonly)
	]]
	if var7_upvw then
	else
		require(ReplicatedStorage_upvr.Libraries.Modules.Mouselock):PauseOffset(true)
		arg1:StopTween()
		any_new_result1_upvr.cameraResetConnection = nil
		CurrentCamera_upvr.CameraType = Enum.CameraType.Scriptable
		CurrentCamera_upvr.CFrame = arg2.CFrame
		if arg3 and Device_upvr:Get() == "Desktop" then
			local mouse_upvr = Players_upvr.LocalPlayer:GetMouse()
			any_new_result1_upvr.tiltConnection = RunService_upvr.RenderStepped:Connect(function() -- Line 47
				--[[ Upvalues[3]:
					[1]: CurrentCamera_upvr (copied, readonly)
					[2]: arg2 (readonly)
					[3]: mouse_upvr (readonly)
				]]
				CurrentCamera_upvr.CFrame = arg2.CFrame * CFrame.Angles(math.rad((mouse_upvr.Y - mouse_upvr.ViewSizeY / 2) / mouse_upvr.ViewSizeY * -10), math.rad((mouse_upvr.X - mouse_upvr.ViewSizeX / 2) / mouse_upvr.ViewSizeX * -10), 0)
			end)
		end
	end
end
function module_upvr.FieldOfView(arg1, arg2) -- Line 57
	--[[ Upvalues[2]:
		[1]: var7_upvw (read and write)
		[2]: CurrentCamera_upvr (readonly)
	]]
	if var7_upvw then
	else
		CurrentCamera_upvr.FieldOfView = arg2
	end
end
function module_upvr.WatchPlayer(arg1, arg2, arg3) -- Line 63
	--[[ Upvalues[5]:
		[1]: var7_upvw (read and write)
		[2]: CurrentCamera_upvr (readonly)
		[3]: module_upvr (readonly)
		[4]: any_new_result1_upvr (readonly)
		[5]: RunService_upvr (readonly)
	]]
	if var7_upvw then
	else
		if arg2 then
			local var17 = arg2.Character
			if var17 then
				var17 = arg2.Character:FindFirstChild("HumanoidRootPart")
			end
			if not var17 then
			else
				CurrentCamera_upvr.CameraType = Enum.CameraType.Scriptable
				module_upvr:FieldOfView(20)
				any_new_result1_upvr.watchPlayerConnection = RunService_upvr.RenderStepped:Connect(function() -- Line 74
					--[[ Upvalues[4]:
						[1]: arg2 (readonly)
						[2]: module_upvr (copied, readonly)
						[3]: arg3 (readonly)
						[4]: CurrentCamera_upvr (copied, readonly)
					]]
					if not arg2 then
						module_upvr:WatchPlayer()
					end
					if arg3 then
						CurrentCamera_upvr.CFrame = arg3()
					end
				end)
			end
		end
		any_new_result1_upvr.watchPlayerConnection = nil
		module_upvr:Reset()
		module_upvr:FieldOfView(70)
	end
end
function module_upvr.StopTween(arg1) -- Line 90
	--[[ Upvalues[2]:
		[1]: var7_upvw (read and write)
		[2]: var6_upvw (read and write)
	]]
	if var7_upvw then
	elseif var6_upvw then
		var6_upvw:Cancel()
		var6_upvw:Destroy()
	end
end
local TweenService_upvr = game:GetService("TweenService")
function module_upvr.Tween(arg1, arg2, arg3) -- Line 100
	--[[ Upvalues[4]:
		[1]: var7_upvw (read and write)
		[2]: var6_upvw (read and write)
		[3]: TweenService_upvr (readonly)
		[4]: CurrentCamera_upvr (readonly)
	]]
	if var7_upvw then
	else
		arg1:StopTween()
		var6_upvw = TweenService_upvr:Create(CurrentCamera_upvr, arg3, {
			CFrame = arg2.CFrame;
		})
		var6_upvw:Play()
	end
end
function module_upvr.Reset(arg1, arg2) -- Line 111
	--[[ Upvalues[6]:
		[1]: var7_upvw (read and write)
		[2]: ReplicatedStorage_upvr (readonly)
		[3]: Players_upvr (readonly)
		[4]: any_new_result1_upvr (readonly)
		[5]: CurrentCamera_upvr (readonly)
		[6]: module_upvr (readonly)
	]]
	if var7_upvw then
	else
		require(ReplicatedStorage_upvr.Libraries.Modules.Mouselock):PauseOffset(false)
		local LocalPlayer = Players_upvr.LocalPlayer
		local var23 = LocalPlayer.Character
		if var23 then
			var23 = LocalPlayer.Character:WaitForChild("Humanoid")
		end
		any_new_result1_upvr.tiltConnection = nil
		arg1:StopTween()
		CurrentCamera_upvr.CameraSubject = var23
		if arg2 then
			CurrentCamera_upvr.CFrame = arg2
		end
		any_new_result1_upvr.resetCameraOnJoin = LocalPlayer.CharacterAdded:Connect(function() -- Line 126
			--[[ Upvalues[2]:
				[1]: module_upvr (copied, readonly)
				[2]: arg2 (readonly)
			]]
			module_upvr:Reset(arg2)
		end)
	end
end
local Track_upvr = Enum.CameraType.Track
function module_upvr.SetToType(arg1, arg2) -- Line 131
	--[[ Upvalues[4]:
		[1]: var7_upvw (read and write)
		[2]: CurrentCamera_upvr (readonly)
		[3]: Track_upvr (readonly)
		[4]: any_new_result1_upvr (readonly)
	]]
	if var7_upvw then
	else
		if arg2 then
			CurrentCamera_upvr.CameraType = Track_upvr
			any_new_result1_upvr.cameraResetConnection = CurrentCamera_upvr:GetPropertyChangedSignal("CameraType"):Connect(function() -- Line 135, Named "setToType"
				--[[ Upvalues[2]:
					[1]: CurrentCamera_upvr (copied, readonly)
					[2]: Track_upvr (copied, readonly)
				]]
				CurrentCamera_upvr.CameraType = Track_upvr
			end)
			return
		end
		any_new_result1_upvr.cameraResetConnection = nil
	end
end
function module_upvr.Lock(arg1, arg2) -- Line 146
	--[[ Upvalues[1]:
		[1]: var7_upvw (read and write)
	]]
	var7_upvw = arg2
end
return module_upvr