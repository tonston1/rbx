-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:38
-- Luau version 6, Types version 3
-- Time taken: 0.001225 seconds

local TweenService_upvr = game:GetService("TweenService")
local TransitionUI_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("TransitionUI")
local CoverTop_upvr = TransitionUI_upvr.CoverTop
local CoverBottom_upvr = TransitionUI_upvr.CoverBottom
local var5_upvw = false
return {
	Enable = function(arg1) -- Line 18, Named "Enable"
		--[[ Upvalues[5]:
			[1]: var5_upvw (read and write)
			[2]: TransitionUI_upvr (readonly)
			[3]: CoverTop_upvr (readonly)
			[4]: TweenService_upvr (readonly)
			[5]: CoverBottom_upvr (readonly)
		]]
		var5_upvw = true
		TransitionUI_upvr.Enabled = true
		CoverTop_upvr.Size = UDim2.new(1, 0, 0, 0)
		TweenService_upvr:Create(CoverTop_upvr, TweenInfo.new(0.5), {
			Size = UDim2.new(1, 0, 0.5, 0);
		}):Play()
		CoverBottom_upvr.Size = UDim2.new(1, 0, 0, 0)
		TweenService_upvr:Create(CoverBottom_upvr, TweenInfo.new(0.5), {
			Size = UDim2.new(1, 0, 0.5, 0);
		}):Play()
	end;
	Disable = function(arg1) -- Line 32, Named "Disable"
		--[[ Upvalues[5]:
			[1]: var5_upvw (read and write)
			[2]: TweenService_upvr (readonly)
			[3]: CoverTop_upvr (readonly)
			[4]: CoverBottom_upvr (readonly)
			[5]: TransitionUI_upvr (readonly)
		]]
		var5_upvw = false
		TweenService_upvr:Create(CoverTop_upvr, TweenInfo.new(0.5), {
			Size = UDim2.new(1, 0, 0, 0);
		}):Play()
		TweenService_upvr:Create(CoverBottom_upvr, TweenInfo.new(0.5), {
			Size = UDim2.new(1, 0, 0, 0);
		}):Play()
		task.spawn(function() -- Line 42
			--[[ Upvalues[2]:
				[1]: var5_upvw (copied, read and write)
				[2]: TransitionUI_upvr (copied, readonly)
			]]
			task.wait(0.5)
			if not var5_upvw then
				TransitionUI_upvr.Enabled = false
			end
		end)
	end;
}