-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:02
-- Luau version 6, Types version 3
-- Time taken: 0.006450 seconds

local module_7_upvr = {
	DeepCopy = function(arg1, arg2) -- Line 28, Named "DeepCopy"
		local module_4 = {}
		for i, v in arg2 do
			if type(v) == "table" then
				v = arg1:DeepCopy(v)
			end
			module_4[i] = v
		end
		return module_4
	end;
	DeepCopyWithStringKeys = function(arg1, arg2) -- Line 41, Named "DeepCopyWithStringKeys"
		local module_3 = {}
		for i_2, v_2 in pairs(arg2) do
			if type(v_2) == "table" then
				v_2 = arg1:DeepCopyWithStringKeys(v_2)
			end
			if type(i_2) == "number" then
				i_2 = tostring(i_2)
			end
			module_3[i_2] = v_2
		end
		return module_3
	end;
	Inverse = function(arg1, arg2) -- Line 55, Named "Inverse"
		local any_DeepCopy_result1 = arg1:DeepCopy(arg2)
		for i_3 = 1, math.floor(#any_DeepCopy_result1 / 2) do
			local var14 = #any_DeepCopy_result1 - i_3 + 1
			any_DeepCopy_result1[i_3] = any_DeepCopy_result1[var14]
			any_DeepCopy_result1[var14] = any_DeepCopy_result1[i_3]
		end
		return any_DeepCopy_result1
	end;
	SortAlphabetical = function(arg1, arg2) -- Line 67, Named "SortAlphabetical"
		local any_DeepCopy_result1_2 = arg1:DeepCopy(arg2)
		table.sort(any_DeepCopy_result1_2, function(arg1_2, arg2_2) -- Line 70
			if arg1_2 >= arg2_2 then
			else
			end
			return true
		end)
		return any_DeepCopy_result1_2
	end;
	KeysToArray = function(arg1, arg2) -- Line 78, Named "KeysToArray"
		local module_6 = {}
		for i_4, _ in arg2 do
			table.insert(module_6, i_4)
		end
		return module_6
	end;
	ValuesToArray = function(arg1, arg2) -- Line 88, Named "ValuesToArray"
		local module_2 = {}
		for _, v_4 in arg2 do
			table.insert(module_2, v_4)
		end
		return module_2
	end;
	Concat = function(arg1, ...) -- Line 98, Named "Concat"
		local module_5 = {}
		for _, v_5 in {...} do
			for _, v_6 in pairs(v_5) do
				table.insert(module_5, v_6)
			end
		end
		return module_5
	end;
	ConcatDictionaries = function(arg1, ...) -- Line 108, Named "ConcatDictionaries"
		local module = {}
		for _, v_7 in {...} do
			for i_9, v_8 in v_7 do
				module[i_9] = v_8
			end
		end
		return module
	end;
	Sum = function(arg1, arg2) -- Line 121, Named "Sum"
		local var54 = 0
		for _, v_9 in pairs(arg2) do
			var54 += v_9
		end
		return var54
	end;
	Count = function(arg1, arg2) -- Line 132, Named "Count"
		local var62 = 0
		for _, _ in arg2 do
			var62 += 1
		end
		return var62
	end;
}
function module_7_upvr.Equals(arg1, arg2, arg3) -- Line 142
	--[[ Upvalues[1]:
		[1]: module_7_upvr (readonly)
	]]
	local tbl_upvr = {}
	local function recurse_upvr(arg1_3, arg2_3) -- Line 144, Named "recurse"
		--[[ Upvalues[3]:
			[1]: tbl_upvr (readonly)
			[2]: module_7_upvr (copied, readonly)
			[3]: recurse_upvr (readonly)
		]]
		-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
		-- KONSTANTERROR: [0] 1. Error Block 57 start (CF ANALYSIS FAILED)
		if type(arg1_3) ~= type(arg2_3) then
			return false
		end
		local type_result1 = type(arg1_3)
		if type_result1 ~= "table" then
			if arg1_3 ~= arg2_3 then
				type_result1 = false
			else
				type_result1 = true
			end
			return type_result1
		end
		if tbl_upvr[arg1_3] then
			if tbl_upvr[arg1_3] ~= arg2_3 then
			else
			end
			return true
		end
		tbl_upvr[arg1_3] = arg2_3
		for i_12, _ in pairs(arg2_3) do
			if type(i_12) == "table" then
				table.insert({}, i_12)
			end
			;({})[i_12] = true
		end
		local pairs_result1, pairs_result2_3, pairs_result3_3 = pairs(arg1_3)
		-- KONSTANTERROR: [0] 1. Error Block 57 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [123] 102. Error Block 32 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [123] 102. Error Block 32 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [70] 55. Error Block 20 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		-- KONSTANTERROR: [70] 55. Error Block 20 end (CF ANALYSIS FAILED)
	end
	return recurse_upvr(arg2, arg3)
end
function module_7_upvr.FindAndRemove(arg1, arg2, arg3) -- Line 189
	local table_find_result1 = table.find(arg2, arg3)
	if table_find_result1 then
		table.remove(arg2, table_find_result1)
	end
	return table_find_result1
end
function module_7_upvr.ConvertStringKeysToNumbers(arg1, arg2) -- Line 197
	for i_13, v_12 in arg2 do
		if tonumber(i_13) then
			arg2[i_13] = nil
			arg2[tonumber(i_13)] = v_12
		else
			arg2[i_13] = v_12
		end
	end
end
function module_7_upvr.GetBetween(arg1, arg2, arg3) -- Line 209
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	local var98
	for _, v_13 in arg2 do
		if v_13 < math.huge and arg3 <= v_13 then
		end
	end
	for _, v_14 in arg2 do
		if var98 < v_14 and v_14 <= arg3 then
			var98 = v_14
		end
	end
	return var98, v_13
end
function module_7_upvr.GetBetweenHighValue(arg1, arg2, arg3) -- Line 229
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	local var115
	for _, v_15 in arg2 do
		if v_15 < math.huge and arg3 < v_15 then
		end
	end
	for _, v_16 in arg2 do
		if var115 < v_16 and v_16 <= arg3 then
			var115 = v_16
		end
	end
	return var115, v_15
end
function module_7_upvr.GetBetweenNotEqual(arg1, arg2, arg3) -- Line 249
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	local var132
	for _, v_17 in arg2 do
		if v_17 < math.huge and arg3 < v_17 then
		end
	end
	for _, v_18 in arg2 do
		if var132 < v_18 and v_18 < arg3 then
			var132 = v_18
		end
	end
	return var132, v_17
end
function module_7_upvr.Reverse(arg1, arg2) -- Line 268
	for i_20 = 1, math.floor(#arg2 / 2) do
		local var134 = #arg2 - i_20 + 1
		arg2[i_20] = arg2[var134]
		arg2[var134] = arg2[i_20]
	end
end
return module_7_upvr