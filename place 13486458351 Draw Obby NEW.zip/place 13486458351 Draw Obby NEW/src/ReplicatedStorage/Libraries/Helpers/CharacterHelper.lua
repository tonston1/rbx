-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:02
-- Luau version 6, Types version 3
-- Time taken: 0.007655 seconds

local Players_upvr = game:GetService("Players")
local any_new_result1_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid).new()
local module = {
	TeleportTo = function(arg1, arg2, arg3) -- Line 23, Named "TeleportTo"
		local HumanoidRootPart = arg2:FindFirstChild("HumanoidRootPart")
		local Humanoid = arg2:FindFirstChild("Humanoid")
		if not HumanoidRootPart or not Humanoid then
			warn("No HRP/Humanoid", arg2)
		else
			arg2:PivotTo(arg3.CFrame * CFrame.new(0, Humanoid.HipHeight + HumanoidRootPart.Size.Y / 2, 0))
		end
	end;
	ResizeR6 = function(arg1, arg2, arg3, arg4) -- Line 35, Named "ResizeR6"
		--[[ Upvalues[2]:
			[1]: Players_upvr (readonly)
			[2]: any_new_result1_upvr (readonly)
		]]
		-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
		local var30 = arg2
		if var30 then
			var30 = arg2:FindFirstChild("HumanoidRootPart")
		end
		local var31_upvr = arg2
		if var31_upvr then
			var31_upvr = arg2:FindFirstChild("Head")
		end
		local var32 = arg2
		if var32 then
			var32 = arg2:FindFirstChild("Torso")
		end
		local any_GetPlayerFromCharacter_result1_2 = Players_upvr:GetPlayerFromCharacter(arg2)
		local var34_upvr = any_GetPlayerFromCharacter_result1_2
		if var34_upvr then
			var34_upvr = tostring(any_GetPlayerFromCharacter_result1_2.UserId)
		end
		local var35 = arg2
		if var35 then
			var35 = arg2:FindFirstChild("Humanoid")
		end
		if not arg2 then
		else
			if not var30 then return end
			if not var35 then return end
			if arg4 then
				local var36_upvw = (1) / (var30.Size.Y / 2) * arg3
			end
			local function _resizeAccessories_upvr() -- Line 52, Named "_resizeAccessories"
				--[[ Upvalues[5]:
					[1]: arg2 (readonly)
					[2]: var31_upvr (readonly)
					[3]: var36_upvw (read and write)
					[4]: any_new_result1_upvr (copied, readonly)
					[5]: var34_upvr (readonly)
				]]
				if arg2:FindFirstChild("Head") then
					local class_SpecialMesh_2 = var31_upvr:FindFirstChildWhichIsA("SpecialMesh")
					if class_SpecialMesh_2 and class_SpecialMesh_2.MeshId ~= "" then
						class_SpecialMesh_2.Scale *= var36_upvw
					end
				end
				for _, v_2 in arg2:GetChildren(), nil do
					if not v_2:IsA("Accessory") then
						print("no accessory")
					else
						local Handle = v_2:FindFirstChild("Handle")
						local AccessoryWeld = Handle:FindFirstChild("AccessoryWeld")
						local class_SpecialMesh = Handle:FindFirstChildOfClass("SpecialMesh")
						AccessoryWeld.C0 = CFrame.new(AccessoryWeld.C0.Position * var36_upvw) * (AccessoryWeld.C0 - AccessoryWeld.C0.Position)
						AccessoryWeld.C1 = CFrame.new(AccessoryWeld.C1.Position * var36_upvw) * (AccessoryWeld.C1 - AccessoryWeld.C1.Position)
						if class_SpecialMesh then
							class_SpecialMesh.Scale *= var36_upvw
						end
						any_new_result1_upvr[var34_upvr.."appearanceLoaded"] = nil
					end
				end
			end
			any_new_result1_upvr[var34_upvr.."appearanceLoaded"] = any_GetPlayerFromCharacter_result1_2.CharacterAppearanceLoaded:Connect(function() -- Line 79
				--[[ Upvalues[1]:
					[1]: _resizeAccessories_upvr (readonly)
				]]
				_resizeAccessories_upvr()
			end)
			local tbl = {}
			table.insert(tbl, var30:FindFirstChild("RootJoint"))
			for _, v_3 in var32:GetChildren(), nil do
				if v_3:IsA("Motor6D") ~= false then
					table.insert(tbl, v_3)
				end
			end
			for _, v_4 in tbl do
				v_4.C0 = CFrame.new(v_4.C0.Position * var36_upvw) * (v_4.C0 - v_4.C0.Position)
				v_4.C1 = CFrame.new(v_4.C1.Position * var36_upvw) * (v_4.C1 - v_4.C1.Position)
			end
			for _, v_5 in arg2:GetChildren(), nil do
				if v_5:IsA("BasePart") then
					v_5.Size *= var36_upvw
				end
			end
			_resizeAccessories_upvr()
			local class_Tool = arg2:FindFirstChildWhichIsA("Tool")
			if class_Tool then
				v_5 = class_Tool:GetScale() * var36_upvw
				class_Tool:ScaleTo(v_5)
			end
			any_new_result1_upvr[var34_upvr.."toolAdded"] = arg2.ChildAdded:Connect(function(arg1_2) -- Line 111
				--[[ Upvalues[1]:
					[1]: var36_upvw (read and write)
				]]
				if arg1_2:IsA("Tool") then
					arg1_2:ScaleTo(arg1_2:GetScale() * var36_upvw)
				end
			end)
			any_new_result1_upvr[var34_upvr.."toolRemoved"] = arg2.ChildRemoved:Connect(function(arg1_3) -- Line 118
				--[[ Upvalues[1]:
					[1]: var36_upvw (read and write)
				]]
				if arg1_3:IsA("Tool") then
					arg1_3:ScaleTo(arg1_3:GetScale() / var36_upvw)
				end
			end)
		end
	end;
	ScaleUpR15 = function(arg1, arg2) -- Line 126, Named "ScaleUpR15"
		if not arg1 then
		else
			if not arg1:IsA("Model") then return end
			local Humanoid_2 = arg1:FindFirstChild("Humanoid")
			if not Humanoid_2 then return end
			if not Humanoid_2:IsA("Humanoid") then return end
			arg1:ScaleTo(arg2)
			Humanoid_2.WalkSpeed = Humanoid_2.WalkSpeed
			Humanoid_2.JumpHeight = Humanoid_2.JumpHeight
		end
	end;
	GetMoveDirectionRelativeToLookVector = function(arg1, arg2) -- Line 151, Named "GetMoveDirectionRelativeToLookVector"
		if not arg2 then
			return 0
		end
		local class_Humanoid = arg2:FindFirstChildOfClass("Humanoid")
		local HumanoidRootPart_2 = arg2:FindFirstChild("HumanoidRootPart")
		if not class_Humanoid or not HumanoidRootPart_2 or not HumanoidRootPart_2:IsA("BasePart") then
			return 0
		end
		local MoveDirection = class_Humanoid.MoveDirection
		if MoveDirection.Magnitude < 0.001 then
			return 0
		end
		return math.clamp(MoveDirection:Dot(HumanoidRootPart_2.CFrame.RightVector), -1, 1)
	end;
}
local tbl_upvr_2 = {
	WalkSpeed = function(arg1) -- Line 174
		return arg1.WalkSpeed
	end;
	JumpHeight = function(arg1) -- Line 177
		return arg1.JumpHeight
	end;
}
local tbl_upvr = {
	WalkSpeed = function(arg1, arg2) -- Line 183
		arg1.WalkSpeed = arg2
	end;
	JumpHeight = function(arg1, arg2) -- Line 186
		arg1.JumpHeight = arg2
	end;
}
function module.SetPropertyForDuration(arg1, arg2, arg3, arg4) -- Line 191
	--[[ Upvalues[3]:
		[1]: tbl_upvr_2 (readonly)
		[2]: tbl_upvr (readonly)
		[3]: any_new_result1_upvr (readonly)
	]]
	local var66_upvr = arg1
	if var66_upvr then
		var66_upvr = arg1:FindFirstChild("Humanoid")
	end
	if not var66_upvr then
	else
		if not var66_upvr:IsA("Humanoid") then return end
		if not tbl_upvr_2[arg2] then
			warn(`There isn't a getter for property {arg2}`)
			return
		end
		if not tbl_upvr[arg2] then
			warn(`There isn't a setter for property {arg2}`)
			return
		end
		tbl_upvr[arg2](var66_upvr, arg3)
		local var67_upvw = false
		any_new_result1_upvr.changedConnection = var66_upvr:GetPropertyChangedSignal(arg2):Connect(function() -- Line 203
			--[[ Upvalues[1]:
				[1]: var67_upvw (read and write)
			]]
			var67_upvw = true
		end)
		local any_any_result1_upvr = tbl_upvr_2[arg2](var66_upvr)
		task.spawn(function() -- Line 207
			--[[ Upvalues[7]:
				[1]: arg4 (readonly)
				[2]: arg1 (readonly)
				[3]: var66_upvr (readonly)
				[4]: var67_upvw (read and write)
				[5]: tbl_upvr (copied, readonly)
				[6]: arg2 (readonly)
				[7]: any_any_result1_upvr (readonly)
			]]
			task.wait(arg4)
			if not arg1 then
			else
				if not var66_upvr then return end
				if var67_upvw then return end
				tbl_upvr[arg2](var66_upvr, any_any_result1_upvr)
			end
		end)
	end
end
function module.GetHeight(arg1) -- Line 217
	local _, any_GetBoundingBox_result2 = arg1:GetBoundingBox()
	return any_GetBoundingBox_result2.Y
end
function module.ApplyArmour(arg1, arg2) -- Line 223
	--[[ Upvalues[1]:
		[1]: Players_upvr (readonly)
	]]
	local clone = arg2:Clone()
	local any_GetPlayerFromCharacter_result1_3 = Players_upvr:GetPlayerFromCharacter(arg1)
	if not any_GetPlayerFromCharacter_result1_3 then return end
	for _, v in clone:GetChildren(), nil do
		if v:IsA("Model") then
			local SOME_3 = arg1:FindFirstChild(v.Name)
			local SOME_2 = v:FindFirstChild(v.Name)
			if SOME_3 and SOME_2 and SOME_2:IsA("BasePart") and SOME_3:IsA("BasePart") then
				v.PrimaryPart = SOME_2
				v:PivotTo(SOME_3.CFrame)
				local WeldConstraint = Instance.new("WeldConstraint")
				WeldConstraint.Part0 = SOME_2
				WeldConstraint.Part1 = SOME_3
				WeldConstraint.Parent = v
			end
		end
	end
	clone:SetAttribute("OwnerId", any_GetPlayerFromCharacter_result1_3.UserId)
	clone.Parent = workspace
	return clone
end
return module