-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:37
-- Luau version 6, Types version 3
-- Time taken: 0.004396 seconds

local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
local Profiles_upvr = require(ReplicatedStorage_upvr.Libraries.Modules.Profiles)
local Rarities_upvr = require(ReplicatedStorage_upvr.Libraries.Modules.Rarities)
local module_upvr = {}
function module_upvr.OwnsItem(arg1, arg2, arg3) -- Line 19
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	return module_upvr.SingleItemList(arg1, arg2)[arg3]
end
function module_upvr.GetItemData(arg1, arg2) -- Line 25
	--[[ Upvalues[1]:
		[1]: ReplicatedStorage_upvr (readonly)
	]]
	return require(ReplicatedStorage_upvr.Assets.Skins[arg1][arg2])
end
function module_upvr.GetItemColour(arg1, arg2) -- Line 31
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: Rarities_upvr (readonly)
	]]
	local any_GetItemData_result1_2 = module_upvr.GetItemData(arg1, arg2)
	return Rarities_upvr[any_GetItemData_result1_2.rarity({}, any_GetItemData_result1_2)].colour.Keypoints[1].Value
end
function module_upvr.GetItemSound(arg1, arg2) -- Line 38
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: Rarities_upvr (readonly)
	]]
	local any_GetItemData_result1 = module_upvr.GetItemData(arg1, arg2)
	return Rarities_upvr[any_GetItemData_result1.rarity({}, any_GetItemData_result1)].sound
end
function module_upvr.SingleItemList(arg1, arg2) -- Line 45
	--[[ Upvalues[1]:
		[1]: Profiles_upvr (readonly)
	]]
	local var9 = Profiles_upvr:GetPlayerReplica(tostring(arg1.UserId)).Data.inventory[arg2]
	if not var9 then
		return {}
	end
	local module = {}
	for i, v in var9 do
		if v.item then
			local item = v.item
			if not module[item] then
				module[item] = {
					item = v.item;
					ids = {};
				}
			end
			table.insert(module[item].ids, i)
		end
	end
	return module
end
local HttpService_upvr = game:GetService("HttpService")
function module_upvr.Reward(arg1, arg2, arg3) -- Line 71
	--[[ Upvalues[2]:
		[1]: Profiles_upvr (readonly)
		[2]: HttpService_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 36 start (CF ANALYSIS FAILED)
	local tostring_result1 = tostring(arg2.UserId)
	local any_GetPlayerReplica_result1 = Profiles_upvr:GetPlayerReplica(tostring_result1)
	if not any_GetPlayerReplica_result1 then
		any_GetPlayerReplica_result1 = Profiles_upvr:WaitForPlayerReplica(tostring_result1)
	end
	if not any_GetPlayerReplica_result1 then
		return false
	end
	if arg3.writeLib == "Bombs" then
		any_GetPlayerReplica_result1:Write("Inventory", "bombs", HttpService_upvr:GenerateGUID(), {
			item = arg3.bombName;
		})
		-- KONSTANTWARNING: GOTO [124] #88
	end
	-- KONSTANTERROR: [0] 1. Error Block 36 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [45] 35. Error Block 32 start (CF ANALYSIS FAILED)
	if arg3.writeLib == "DeathEffects" then
		any_GetPlayerReplica_result1:Write("Inventory", "deathEffects", HttpService_upvr:GenerateGUID(), {
			item = arg3.deathEffectName;
		})
	else
		if arg3.writeLib == "Currency1" then
			any_GetPlayerReplica_result1:Write("Currency1", arg3.value)
			return true
		end
		if arg3.writeLib == "SpinWheel" then
			any_GetPlayerReplica_result1:Write("Spins", arg3.value)
			return true
		end
		if arg3.writeLib == "InviteRewardProgress" then
			any_GetPlayerReplica_result1:Write(arg3.writeLib, arg3.value)
			return true
		end
		if arg3.writeLib == "CrateOwned" then
			if #any_GetPlayerReplica_result1.Data.crateOwned < 4 then
				any_GetPlayerReplica_result1:Write("CrateOwned", arg3.crateTier)
				return true
			end
			return false
		end
	end
	-- KONSTANTERROR: [45] 35. Error Block 32 end (CF ANALYSIS FAILED)
end
function module_upvr.GetRewardNotification(arg1, arg2) -- Line 109
	--[[ Upvalues[1]:
		[1]: Profiles_upvr (readonly)
	]]
	if arg2.writeLib == "Currency1" then
		return "TextNotification", {
			message = "Claimed ".."<font color=\"rgb(255,230,0)\">"..tostring(arg2.value).."</font> money!";
		}
	end
	if arg2.writeLib == "Bombs" then
		return "TextNotification", {
			message = "Unlocked ".."<font color=\"rgb(255,230,0)\">"..tostring(arg2.bombName).."</font> bomb!";
		}
	end
	if arg2.writeLib == "DeathEffects" then
		return "TextNotification", {
			message = "Unlocked ".."<font color=\"rgb(255,230,0)\">"..tostring(arg2.deathEffectName).."</font> death effect!";
		}
	end
	if arg2.writeLib == "SpinWheel" then
		return "TextNotification", {
			message = "You claimed ".."<font color=\"rgb(252, 214, 0)\">"..tostring(arg2.value).."</font> spin wheel tickets!";
		}
	end
	if arg2.writeLib == "Skips" then
		return "TextNotification", {
			message = "You claimed ".."<font color=\"rgb(0, 128, 0)\">"..tostring(arg2.value).."</font> level skip tickets!";
		}
	end
	if arg2.writeLib == "InviteRewardProgress" then
		return "TextNotification", {
			message = "You received ".."<font color=\"rgb(0, 255, 0)\">"..tostring(arg2.value).."</font> friend invite points!";
		}
	end
	if arg2.writeLib == "CrateOwned" then
		return "CrateNotification", arg2
	end
	warn("No reward notification for: "..arg2.writeLib)
	return "TextNotification", {
		message = "<font color=\"rgb(0, 255, 0)\">".."No reward notification for: "..arg2.writeLib.." Report to developer</font>";
	}
end
function module_upvr.SplitAthleteString(arg1, arg2) -- Line 146
	local any_match_result1, any_match_result2 = arg2:match("^(%a+)(%u%l+.*)")
	return any_match_result1, any_match_result2
end
local Players_upvr = game:GetService("Players")
local SharedConstants_upvr = require(ReplicatedStorage_upvr.Libraries.Modules.Constants.SharedConstants)
function module_upvr.GetNotifications(arg1, arg2) -- Line 151
	--[[ Upvalues[3]:
		[1]: Players_upvr (readonly)
		[2]: Profiles_upvr (readonly)
		[3]: SharedConstants_upvr (readonly)
	]]
	local var34
	if not var34 then
		var34 = Profiles_upvr:WaitForPlayerReplica(tostring(Players_upvr.LocalPlayer.UserId))
	end
	if arg2 == "Level" then
		return var34.Data.level - var34.Data.levelRewardClaims
	end
	if arg2 == "Daily" then
		if SharedConstants_upvr.DAILY_TIME <= os.time() - var34.Data.dailyReward.lastReward then
			return 1
		end
		do
			return 0
		end
		local var35
	end
	if arg2 == "Friend" then
		var35 = 0
		for _, v_2 in SharedConstants_upvr.FRIEND_REWARDS do
			local requirement = v_2.requirement
			if requirement <= var34.Data.inviteRewardProgress and not var34.Data.inviteRewardClaims[tostring(requirement)] then
				var35 += 1
			end
		end
		return var35
	end
	if arg2 == "Codes" then
		var35 = 0
		return var35
	end
	return 0
end
return module_upvr