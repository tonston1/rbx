-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:48
-- Luau version 6, Types version 3
-- Time taken: 0.000243 seconds

return {
	Value = function(arg1, arg2, arg3, arg4) -- Line 5, Named "Value"
		return arg2:Lerp(arg3, arg4)
	end;
}