-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:13
-- Luau version 6, Types version 3
-- Time taken: 0.000624 seconds

local module = {
	list = {
		currency1 = 0;
		rebirth = 0;
		stage = 1;
		deaths = 0;
		hints = 3;
		skips = 1;
		codes = {};
		badges = {};
		inGroup = false;
		groupRewards = {};
		trails = {"White"};
		trailEquipped = "White";
		dailyReward = {
			lastReward = 0;
			streak = 0;
		};
		playTime = 0;
		purchases = {};
		friends = 0;
		timesPlayed = 0;
	};
}
local TablePlus_upvr = require(game:GetService("ReplicatedStorage").Libraries.Modules.TablePlus)
function module.Get(arg1) -- Line 36
	--[[ Upvalues[1]:
		[1]: TablePlus_upvr (readonly)
	]]
	return TablePlus_upvr:DeepCopy(arg1.list)
end
return module