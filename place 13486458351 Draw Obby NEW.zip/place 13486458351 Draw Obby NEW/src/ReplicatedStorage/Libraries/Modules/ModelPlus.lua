-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:11
-- Luau version 6, Types version 3
-- Time taken: 0.003926 seconds

local TweenService_upvr = game:GetService("TweenService")
local module = {
	cframeTweenList = {};
	cframeVal = {};
}
function resizeModel(arg1, arg2) -- Line 11
	local Position = arg1.PrimaryPart.Position
	for _, v in pairs(arg1:GetDescendants()) do
		if v:IsA("BasePart") then
			if v ~= arg1.PrimaryPart then
				local CFrame_2 = v.CFrame
				v.CFrame = CFrame.new((CFrame_2.Position - Position) * arg2 + Position) * (CFrame_2 - CFrame_2.Position)
			end
			v.Size *= arg2
		end
	end
end
local RunService_upvr = game:GetService("RunService")
function module.Size(arg1, arg2, arg3, arg4, arg5, arg6) -- Line 28
	--[[ Upvalues[2]:
		[1]: RunService_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	if arg4 then
		if arg3 == 0 then
			resizeModel(arg2, arg4)
			return
		end
		local var12_upvw = 0
		local var13_upvr = arg4 - 1
		local var14_upvw = 0
		local var15_upvw
		var15_upvw = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 38
			--[[ Upvalues[9]:
				[1]: var12_upvw (read and write)
				[2]: arg3 (readonly)
				[3]: TweenService_upvr (copied, readonly)
				[4]: arg5 (readonly)
				[5]: arg6 (readonly)
				[6]: arg2 (readonly)
				[7]: var13_upvr (readonly)
				[8]: var14_upvw (read and write)
				[9]: var15_upvw (read and write)
			]]
			if var12_upvw < 1 then
				var12_upvw = math.min(var12_upvw + arg1_2 / arg3, 1)
				local var16 = arg5
				if not var16 then
					var16 = Enum.EasingStyle.Linear
				end
				local var17 = arg6
				if not var17 then
					var17 = Enum.EasingDirection.Out
				end
				local any_GetValue_result1 = TweenService_upvr:GetValue(var12_upvw, var16, var17)
				resizeModel(arg2, (any_GetValue_result1 * var13_upvr + 1) / (var14_upvw * var13_upvr + 1))
				var14_upvw = any_GetValue_result1
			else
				var15_upvw:Disconnect()
			end
		end)
	end
end
function module.CFrame(arg1, arg2, arg3, arg4) -- Line 54
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	if arg1.cframeTweenList[arg2] then
		arg1.cframeTweenList[arg2]:Pause()
		arg1.cframeTweenList[arg2]:Destroy()
		arg1.cframeTweenList[arg2] = nil
	end
	if arg1.cframeVal[arg2] then
		arg1.cframeVal[arg2]:Destroy()
		arg1.cframeVal[arg2] = nil
	end
	arg1.cframeVal[arg2] = Instance.new("CFrameValue")
	arg1.cframeVal[arg2].Value = arg2:GetPrimaryPartCFrame()
	arg1.cframeVal[arg2]:GetPropertyChangedSignal("Value"):Connect(function() -- Line 69
		--[[ Upvalues[2]:
			[1]: arg2 (readonly)
			[2]: arg1 (readonly)
		]]
		-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [38] 31. Error Block 5 start (CF ANALYSIS FAILED)
		arg1.cframeVal[arg2]:Destroy()
		arg1.cframeVal[arg2] = nil
		do
			return
		end
		-- KONSTANTERROR: [38] 31. Error Block 5 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [53] 43. Error Block 6 start (CF ANALYSIS FAILED)
		arg2:SetPrimaryPartCFrame(arg1.cframeVal[arg2].Value)
		-- KONSTANTERROR: [53] 43. Error Block 6 end (CF ANALYSIS FAILED)
	end)
	local tbl_2 = {}
	tbl_2.Value = arg3
	local any_Create_result1 = TweenService_upvr:Create(arg1.cframeVal[arg2], arg4, tbl_2)
	any_Create_result1:Play()
	arg1.cframeTweenList[arg2] = any_Create_result1
	any_Create_result1.Completed:Connect(function() -- Line 91
		--[[ Upvalues[2]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
		]]
		if arg1.cframeTweenList[arg2] then
			arg1.cframeTweenList[arg2]:Pause()
			arg1.cframeTweenList[arg2]:Destroy()
			arg1.cframeTweenList[arg2] = nil
		end
		if arg1.cframeVal[arg2] then
			arg1.cframeVal[arg2]:Destroy()
			arg1.cframeVal[arg2] = nil
		end
	end)
	return any_Create_result1
end
function module.Transparency(arg1, arg2, arg3, arg4) -- Line 108
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	for _, v_2_upvr in pairs(arg2:GetChildren()) do
		if v_2_upvr:IsA("BasePart") then
			local NumberValue_upvr = Instance.new("NumberValue")
			NumberValue_upvr.Value = v_2_upvr.Transparency
			NumberValue_upvr:GetPropertyChangedSignal("Value"):Connect(function() -- Line 114
				--[[ Upvalues[2]:
					[1]: v_2_upvr (readonly)
					[2]: NumberValue_upvr (readonly)
				]]
				v_2_upvr.Transparency = NumberValue_upvr.Value
			end)
			local tbl = {}
			tbl.Value = arg4
			TweenService_upvr:Create(NumberValue_upvr, TweenInfo.new(arg3), tbl):Play()
		end
		NumberValue_upvr = #v_2_upvr:GetChildren()
		if NumberValue_upvr then
			NumberValue_upvr = arg1:Transparency
			NumberValue_upvr(v_2_upvr, arg3, arg4)
		end
	end
end
function module.CanCollide(arg1, arg2, arg3, arg4) -- Line 127
	for _, v_3 in pairs(arg2:GetDescendants()) do
		if v_3:IsA("BasePart") and v_3.CanCollide ~= arg4 then
			v_3.CanCollide = arg4
		end
	end
end
function module.Properties(arg1, arg2, arg3) -- Line 136
	for _, v_4 in ipairs(arg2:GetDescendants()) do
		if v_4:IsA("BasePart") then
			for i_5, v_5 in pairs(arg3) do
				v_4[i_5] = v_5
			end
		end
	end
end
function module.Tween(arg1, arg2, arg3, arg4) -- Line 147
	for i_6, v_6 in pairs(arg4) do
		if arg1[i_6] then
			arg1[i_6](arg1, arg2, arg3, v_6)
		end
	end
end
return module