-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:09
-- Luau version 6, Types version 3
-- Time taken: 0.003833 seconds

local ServerScriptService_upvr = game:GetService("ServerScriptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local BindableEvent_upvr = Instance.new("BindableEvent")
local module = {
	player = {
		profiles = {};
		replicas = {};
	};
	replicas = {};
}
if any_IsServer_result1_upvr then
	module.token = require(ServerScriptService_upvr.Libraries.Classes.ReplicaService).NewClassToken("PlayerProfile")
	module.store = require(ServerScriptService_upvr.Libraries.Classes.ProfileService).GetProfileStore("Release", require(ReplicatedStorage.Libraries.Modules.Defaults):Get())
end
function module.GetReplica(arg1, arg2) -- Line 40
	while not arg1.replicas[arg2] do
		task.wait()
	end
	return arg1.replicas[arg2]
end
function module.SetReplica(arg1, arg2, arg3) -- Line 46
	arg1.replicas[arg2] = arg3
end
function module.GetPlayerReplica(arg1, arg2) -- Line 50
	--[[ Upvalues[1]:
		[1]: any_IsServer_result1_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [2] 3. Error Block 2 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [2] 3. Error Block 2 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [4] 4. Error Block 3 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [4] 4. Error Block 3 end (CF ANALYSIS FAILED)
end
function module.WaitForPlayerReplica(arg1, arg2) -- Line 69
	--[[ Upvalues[1]:
		[1]: BindableEvent_upvr (readonly)
	]]
	local BindableEvent_upvr_2 = Instance.new("BindableEvent")
	BindableEvent_upvr.Event:Connect(function(arg1_2) -- Line 72
		--[[ Upvalues[2]:
			[1]: arg2 (readonly)
			[2]: BindableEvent_upvr_2 (readonly)
		]]
		if arg2 == arg1_2 then
			BindableEvent_upvr_2:Fire()
		end
	end)
	BindableEvent_upvr_2.Event:Wait()
	BindableEvent_upvr_2:Destroy()
	return arg1.player.replicas[tostring(arg2.UserId)]
end
function module.GetPlayerProfile(arg1, arg2) -- Line 84
	--[[ Upvalues[1]:
		[1]: any_IsServer_result1_upvr (readonly)
	]]
	local var10
	if not any_IsServer_result1_upvr then
		var10 = "Tried to call GetPlayerProfile on the client"
		warn(var10)
	else
		var10 = arg2
		if var10 then
			var10 = arg2.UserId
		end
		var10 = arg1.player.profiles[tostring(var10)]
		if var10 and var10:IsActive() then
			return var10
		end
	end
end
function module.SetPlayerData(arg1, arg2, ...) -- Line 95
	--[[ Upvalues[2]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: BindableEvent_upvr (readonly)
	]]
	local var17 = arg2
	if var17 then
		var17 = arg2.UserId
	end
	local tostring_result1 = tostring(var17)
	if any_IsServer_result1_upvr then
		local args_list = {...}
		local _1_2 = args_list[1]
		if _1_2 == nil then
			local any_GetPlayerReplica_result1 = arg1:GetPlayerReplica(arg2)
			if any_GetPlayerReplica_result1 and any_GetPlayerReplica_result1:IsActive() then
				any_GetPlayerReplica_result1:Destroy()
			end
		end
		arg1.player.profiles[tostring_result1] = _1_2
		arg1.player.replicas[tostring_result1] = args_list[2]
		BindableEvent_upvr:Fire(arg2)
	else
		arg1.player.replicas[tostring_result1] = ({...})[1]
		BindableEvent_upvr:Fire(arg2)
	end
end
local Players_upvr = game:GetService("Players")
local WriteLib_upvr = ReplicatedStorage.Libraries.Modules.WriteLib
function module.AddPlayer(arg1, arg2) -- Line 125
	--[[ Upvalues[4]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: ServerScriptService_upvr (readonly)
		[3]: Players_upvr (readonly)
		[4]: WriteLib_upvr (readonly)
	]]
	if not any_IsServer_result1_upvr then
		warn("Tried to call AddPlayer on the client")
	else
		local any_LoadProfileAsync_result1 = arg1.store:LoadProfileAsync("Player_"..arg2.UserId)
		if any_LoadProfileAsync_result1 then
			any_LoadProfileAsync_result1:AddUserId(arg2.UserId)
			any_LoadProfileAsync_result1:Reconcile()
			any_LoadProfileAsync_result1:ListenToRelease(function() -- Line 135
				--[[ Upvalues[2]:
					[1]: arg1 (readonly)
					[2]: arg2 (readonly)
				]]
				arg1:SetPlayerData(arg2, nil, nil)
				arg2:Kick("Error loading your data. Please rejoin")
			end)
			if arg2:IsDescendantOf(Players_upvr) then
				local tbl_2 = {
					ClassToken = arg1.token;
				}
				local tbl_4 = {}
				tbl_4.Player = arg2
				tbl_2.Tags = tbl_4
				tbl_2.Data = any_LoadProfileAsync_result1.Data
				tbl_2.Replication = "All"
				tbl_2.WriteLib = WriteLib_upvr
				arg1:SetPlayerData(arg2, any_LoadProfileAsync_result1, require(ServerScriptService_upvr.Libraries.Classes.ReplicaService).NewReplica(tbl_2))
			else
				any_LoadProfileAsync_result1:Release()
			end
		end
		arg2:Kick("Error loading your data. Please rejoin")
	end
end
function module.Release(arg1, arg2) -- Line 164
	--[[ Upvalues[1]:
		[1]: any_IsServer_result1_upvr (readonly)
	]]
	if not any_IsServer_result1_upvr then
		warn("Tried to call Release on the client")
	else
		local any_GetPlayerProfile_result1 = arg1:GetPlayerProfile(arg2)
		if any_GetPlayerProfile_result1 then
			any_GetPlayerProfile_result1:Release()
		end
	end
end
return module