-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:04
-- Luau version 6, Types version 3
-- Time taken: 0.003360 seconds

local BadgeService_upvr = game:GetService("BadgeService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Profiles_upvr = require(ReplicatedStorage.Libraries.Modules.Profiles)
local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local module_upvr = {
	badgeList = {
		["2146738512"] = {
			description = "Thanks for playing!";
			rewards = {};
		};
		["2147015126"] = {
			description = "First win!";
			rewards = {};
			key = "rebirth";
			amount = 1;
		};
		["2147015130"] = {
			description = "5 win!";
			rewards = {};
			key = "rebirth";
			amount = 5;
		};
		["2147015134"] = {
			description = "10 win!";
			rewards = {};
			key = "rebirth";
			amount = 10;
		};
	};
}
function module_upvr.Owns(arg1, arg2, arg3) -- Line 40
	--[[ Upvalues[3]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: Profiles_upvr (readonly)
		[3]: BadgeService_upvr (readonly)
	]]
	if not any_IsServer_result1_upvr then return end
	local any_GetPlayerReplica_result1_upvr = Profiles_upvr:GetPlayerReplica(arg2)
	if not any_GetPlayerReplica_result1_upvr then
		any_GetPlayerReplica_result1_upvr = Profiles_upvr:WaitForPlayerReplica(arg2)
	end
	local pcall_result1, pcall_result2 = pcall(function() -- Line 44
		--[[ Upvalues[4]:
			[1]: any_GetPlayerReplica_result1_upvr (readonly)
			[2]: arg3 (readonly)
			[3]: BadgeService_upvr (copied, readonly)
			[4]: arg2 (readonly)
		]]
		if any_GetPlayerReplica_result1_upvr.Data.badges[tostring(arg3)] ~= nil then
			return true
		end
		return BadgeService_upvr:UserHasBadgeAsync(arg2.UserId, arg3)
	end)
	if pcall_result1 then
		return pcall_result2
	end
	return true
end
function module_upvr.Award(arg1, arg2, arg3) -- Line 63
	--[[ Upvalues[3]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: Profiles_upvr (readonly)
		[3]: BadgeService_upvr (readonly)
	]]
	if not any_IsServer_result1_upvr then
	else
		local any_GetPlayerReplica_result1_upvr_2 = Profiles_upvr:GetPlayerReplica(arg2)
		if not any_GetPlayerReplica_result1_upvr_2 then
			any_GetPlayerReplica_result1_upvr_2 = Profiles_upvr:WaitForPlayerReplica(arg2)
		end
		if any_GetPlayerReplica_result1_upvr_2.Data.badges[tostring(arg3)] == false then return end
		if any_GetPlayerReplica_result1_upvr_2.Data.badges[tostring(arg3)] == true then return end
		task.spawn(function() -- Line 70
			--[[ Upvalues[5]:
				[1]: arg1 (readonly)
				[2]: arg2 (readonly)
				[3]: arg3 (readonly)
				[4]: any_GetPlayerReplica_result1_upvr_2 (readonly)
				[5]: BadgeService_upvr (copied, readonly)
			]]
			if not arg1:Owns(arg2, tostring(arg3)) then
				any_GetPlayerReplica_result1_upvr_2:Write("Badges", tostring(arg3), false)
				BadgeService_upvr:AwardBadge(arg2.UserId, tostring(arg3))
			end
		end)
	end
end
local TablePlus_upvr = require(ReplicatedStorage.Libraries.Modules.TablePlus)
function module_upvr.Reward(arg1, arg2, arg3) -- Line 79
	--[[ Upvalues[3]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: TablePlus_upvr (readonly)
		[3]: module_upvr (readonly)
	]]
	local var18_upvr
	if not var18_upvr then
	else
		local function INLINED() -- Internal function, doesn't exist in bytecode
			var18_upvr = TablePlus_upvr:Sum(arg2.Data[arg3])
			return var18_upvr
		end
		if typeof(arg2.Data[arg3]) ~= "table" or not INLINED() then
			var18_upvr = arg2.Data[arg3]
		end
		print("Total "..arg3..": "..var18_upvr)
		local Player_upvr = arg2.Tags.Player
		task.spawn(function() -- Line 86
			--[[ Upvalues[5]:
				[1]: arg1 (readonly)
				[2]: arg3 (readonly)
				[3]: var18_upvr (readonly)
				[4]: module_upvr (copied, readonly)
				[5]: Player_upvr (readonly)
			]]
			for i_3, v_3 in pairs(arg1:GetList(arg3)) do
				if v_3.amount <= var18_upvr then
					module_upvr:Award(Player_upvr, tostring(i_3))
				end
			end
		end)
	end
end
function module_upvr.GiveReward(arg1, arg2, arg3) -- Line 98
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	for _, v in ipairs(module_upvr:GetList()[tostring(arg3)].rewards) do
		local _1 = v[1]
		if _1 == "Items" then
			arg2:Write("Items", v[2], v[3], v[4])
		elseif _1 == "Power" then
			arg2:Write("Power", v[2])
		end
	end
end
function module_upvr.GetList(arg1, arg2) -- Line 115
	if arg2 then
		for i_2, v_2 in pairs(arg1.badgeList) do
			if v_2.key and v_2.key == arg2 then
				({})[tostring(i_2)] = v_2
			end
		end
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		return {}
	end
	return arg1.badgeList
end
return module_upvr