-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:06
-- Luau version 6, Types version 3
-- Time taken: 0.001268 seconds

-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
-- KONSTANTERROR: [0] 1. Error Block 19 start (CF ANALYSIS FAILED)
local any_IsTenFootInterface_result1 = game:GetService("GuiService"):IsTenFootInterface()
local var7
if var7 then
	var7 = not game:GetService("UserInputService").MouseEnabled
	if var7 then
		var7 = not any_IsTenFootInterface_result1
	end
end
if not any_IsTenFootInterface_result1 then
end
local module = {}
if any_IsTenFootInterface_result1 then
	-- KONSTANTWARNING: GOTO [35] #29
end
-- KONSTANTERROR: [0] 1. Error Block 19 end (CF ANALYSIS FAILED)
-- KONSTANTERROR: [31] 25. Error Block 20 start (CF ANALYSIS FAILED)
if var7 then
else
end
module.device = not var7 and "Desktop"
do
	return module.device
end
-- KONSTANTERROR: [31] 25. Error Block 20 end (CF ANALYSIS FAILED)