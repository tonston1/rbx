-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:08
-- Luau version 6, Types version 3
-- Time taken: 0.003178 seconds

local Players_upvr = game:GetService("Players")
local MarketplaceService = game:GetService("MarketplaceService")
local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local any_GetReplica_result1_upvr = require(game:GetService("ReplicatedStorage").Libraries.Modules.Profiles):GetReplica("Game")
local module_upvr = {
	active = {};
}
local TweenService_upvr = game:GetService("TweenService")
local Lighting_upvr = game:GetService("Lighting")
local const_number_upvw = 0
function module_upvr.Set(arg1, arg2, arg3, arg4, arg5, arg6) -- Line 24
	--[[ Upvalues[5]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: any_GetReplica_result1_upvr (readonly)
		[3]: TweenService_upvr (readonly)
		[4]: Lighting_upvr (readonly)
		[5]: const_number_upvw (read and write)
	]]
	local tostring_result1_upvr = tostring(arg2.UserId)
	if any_IsServer_result1_upvr then
		if arg1.active[tostring_result1_upvr] and arg3 then
		else
			if not arg1.active[tostring_result1_upvr] and not arg3 then return end
			if arg4 then
				any_GetReplica_result1_upvr:FireClient(arg2, "Sales", arg3, arg5, arg6)
			end
			if arg3 then
				local tbl_2 = {}
				tbl_2.Id = arg3
				tbl_2.Item = arg5
				tbl_2.Category = arg6
				arg1.active[tostring_result1_upvr] = tbl_2
				return
			end
			arg1.active[tostring_result1_upvr] = nil
		end
	end
	if arg1.active[tostring_result1_upvr] and arg3 then
	else
		if not arg1.active[tostring_result1_upvr] and not arg3 then return end
		if arg4 then
			any_GetReplica_result1_upvr:FireServer("Sales", arg3, arg5, arg6)
		end
		if arg3 then
			local tbl = {}
			tbl.Id = arg3
			tbl.Item = arg5
			tbl.Category = arg6
			arg1.active[tostring_result1_upvr] = tbl
		else
			arg1.active[tostring_result1_upvr] = nil
		end
		task.spawn(function() -- Line 62
			--[[ Upvalues[6]:
				[1]: arg1 (readonly)
				[2]: tostring_result1_upvr (readonly)
				[3]: TweenService_upvr (copied, readonly)
				[4]: arg2 (readonly)
				[5]: Lighting_upvr (copied, readonly)
				[6]: const_number_upvw (copied, read and write)
			]]
			-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [7] 6. Error Block 15 start (CF ANALYSIS FAILED)
			TweenService_upvr:Create(arg2.PlayerGui.SaleUI.Frame, TweenInfo.new(0.5), {
				BackgroundTransparency = 1;
			}):Play()
			TweenService_upvr:Create(Lighting_upvr.Blur, TweenInfo.new(0.5), {
				Size = 0;
			}):Play()
			for _, v in ipairs(arg2.PlayerGui.SaleUI.Frame:GetChildren()) do
				TweenService_upvr:Create(v, TweenInfo.new(0.5), {
					BackgroundTransparency = 1;
				}):Play()
			end
			task.wait(0.5)
			-- KONSTANTERROR: [7] 6. Error Block 15 end (CF ANALYSIS FAILED)
		end)
	end
end
function module_upvr.Get(arg1, arg2) -- Line 102
	return arg1.active[tostring(arg2.UserId)]
end
if not any_IsServer_result1_upvr then
	local LocalPlayer_upvr = Players_upvr.LocalPlayer
	any_GetReplica_result1_upvr:ConnectOnClientEvent(function(arg1, ...) -- Line 111
		--[[ Upvalues[2]:
			[1]: module_upvr (readonly)
			[2]: LocalPlayer_upvr (readonly)
		]]
		local args_list = {...}
		if arg1 == "Sales" then
			module_upvr:Set(LocalPlayer_upvr, args_list[1], false, args_list[2], args_list[3])
		end
	end)
else
	LocalPlayer_upvr = any_GetReplica_result1_upvr:ConnectOnServerEvent
	LocalPlayer_upvr(function(arg1, arg2, ...) -- Line 123
		--[[ Upvalues[1]:
			[1]: module_upvr (readonly)
		]]
		local args_list_2 = {...}
		if arg2 == "Sales" then
			module_upvr:Set(arg1, args_list_2[1], false, args_list_2[2], args_list_2[3])
		end
	end)
	LocalPlayer_upvr = Players_upvr.PlayerRemoving
	LocalPlayer_upvr = LocalPlayer_upvr:Connect
	LocalPlayer_upvr(function(arg1) -- Line 135
		--[[ Upvalues[1]:
			[1]: module_upvr (readonly)
		]]
		module_upvr:Set(arg1, nil, false)
	end)
end
LocalPlayer_upvr = MarketplaceService.PromptGamePassPurchaseFinished
LocalPlayer_upvr = LocalPlayer_upvr:Connect
LocalPlayer_upvr(function(arg1, arg2, arg3) -- Line 141
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	module_upvr:Set(arg1, nil, false)
end)
LocalPlayer_upvr = MarketplaceService.PromptPurchaseFinished
LocalPlayer_upvr = LocalPlayer_upvr:Connect
LocalPlayer_upvr(function(arg1, arg2, arg3) -- Line 145
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	module_upvr:Set(arg1, nil, false)
end)
LocalPlayer_upvr = MarketplaceService.PromptBundlePurchaseFinished
LocalPlayer_upvr = LocalPlayer_upvr:Connect
LocalPlayer_upvr(function(arg1, arg2, arg3) -- Line 149
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	module_upvr:Set(arg1, nil, false)
end)
LocalPlayer_upvr = MarketplaceService.PromptPremiumPurchaseFinished
LocalPlayer_upvr = LocalPlayer_upvr:Connect
LocalPlayer_upvr(function(arg1, arg2, arg3) -- Line 153
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	module_upvr:Set(arg1, nil, false)
end)
LocalPlayer_upvr = MarketplaceService.PromptProductPurchaseFinished
LocalPlayer_upvr = LocalPlayer_upvr:Connect
LocalPlayer_upvr(function(arg1, arg2, arg3) -- Line 157
	--[[ Upvalues[2]:
		[1]: Players_upvr (readonly)
		[2]: module_upvr (readonly)
	]]
	module_upvr:Set(Players_upvr:GetPlayerByUserId(arg1), nil, false)
end)
return module_upvr