-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:43
-- Luau version 6, Types version 3
-- Time taken: 0.006466 seconds

local Maid_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid)
local module_upvr = {
	maids = {};
	pressing = {};
	highlightMaids = Maid_upvr.new();
	buttonMaids = Maid_upvr.new();
	Release = function(arg1, arg2) -- Line 21, Named "Release"
		arg1.pressing[arg2] = nil
	end;
	Press = function(arg1, arg2) -- Line 26, Named "Press"
		arg1.pressing[arg2] = true
	end;
}
local RunService_upvr = game:GetService("RunService")
local TweenService_upvr = game:GetService("TweenService")
function module_upvr.Highlight(arg1, arg2) -- Line 31
	--[[ Upvalues[3]:
		[1]: Maid_upvr (readonly)
		[2]: RunService_upvr (readonly)
		[3]: TweenService_upvr (readonly)
	]]
	local any_new_result1_upvr = Maid_upvr.new()
	any_new_result1_upvr.highlight = arg2.Content:Clone()
	any_new_result1_upvr.highlight.UIGradient.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
	any_new_result1_upvr.highlight.UIGradient.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.3, 1), NumberSequenceKeypoint.new(0.5, 0.5), NumberSequenceKeypoint.new(0.7, 1), NumberSequenceKeypoint.new(1, 1)})
	any_new_result1_upvr.highlight.UIGradient.Rotation = -45
	any_new_result1_upvr.highlight.UIGradient.Offset = Vector2.new(-1, 0)
	any_new_result1_upvr.highlight.Parent = arg2.Content
	for _, v in any_new_result1_upvr.highlight:GetChildren(), nil do
		if not v:IsA("UIGradient") then
			v:Destroy()
		end
	end
	local var11_upvw = 0
	any_new_result1_upvr.highlightConnection = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 55
		--[[ Upvalues[5]:
			[1]: var11_upvw (read and write)
			[2]: any_new_result1_upvr (readonly)
			[3]: TweenService_upvr (copied, readonly)
			[4]: arg2 (readonly)
			[5]: RunService_upvr (copied, readonly)
		]]
		var11_upvw += arg1_2
		if 2.5 <= var11_upvw then
			var11_upvw = 0
			any_new_result1_upvr.highlight.UIGradient.Offset = Vector2.new(-1, 0)
			TweenService_upvr:Create(any_new_result1_upvr.highlight.UIGradient, TweenInfo.new(0.8), {
				Offset = Vector2.new(1, 0);
			}):Play()
			TweenService_upvr:Create(arg2.Content, TweenInfo.new(0.5), {
				Size = UDim2.new(1.1, 0, 1.1, 0);
			}):Play()
			local var15_upvw = 0
			any_new_result1_upvr.scaleBackConnection = RunService_upvr.Heartbeat:Connect(function(arg1_3) -- Line 72
				--[[ Upvalues[3]:
					[1]: var15_upvw (read and write)
					[2]: TweenService_upvr (copied, readonly)
					[3]: arg2 (copied, readonly)
				]]
				var15_upvw += arg1_3
				if 0.5 <= var15_upvw then
					var15_upvw = 0
					TweenService_upvr:Create(arg2.Content, TweenInfo.new(0.5), {
						Size = UDim2.new(1, 0, 1, 0);
					}):Play()
				end
			end)
		end
	end)
	arg1.highlightMaids[arg2] = any_new_result1_upvr
end
function module_upvr.StopHighlight(arg1, arg2) -- Line 89
	arg1.highlightMaids[arg2] = nil
end
function module_upvr.Shine(arg1) -- Line 94
end
function module_upvr.GetPressing(arg1, arg2) -- Line 99
	return arg1.pressing[arg2]
end
function module_upvr.Create(arg1, arg2, arg3) -- Line 104
	--[[ Upvalues[1]:
		[1]: Maid_upvr (readonly)
	]]
	local var17 = arg1.maids[arg2]
	if not var17 then
		var17 = Maid_upvr.new()
	end
	arg1.maids[arg2] = var17
	local var18 = arg2
	if var18 then
		var18 = arg2:FindFirstChild("Button")
	end
	if not var18 then
		warn("Button "..arg2:GetFullName().." not found")
	else
		var17.downConnection = var18.MouseButton1Down:Connect(function() -- Line 111
			--[[ Upvalues[2]:
				[1]: arg1 (readonly)
				[2]: arg2 (readonly)
			]]
			arg1:Press(arg2, true)
		end)
		var17.upConnection = var18.Activated:Connect(function() -- Line 115
			--[[ Upvalues[3]:
				[1]: arg1 (readonly)
				[2]: arg2 (readonly)
				[3]: arg3 (readonly)
			]]
			if arg1:GetPressing(arg2) then
				arg1:Release(arg2, true)
				arg1:Shine()
				arg3()
			end
		end)
		var17.enterConnection = var18.MouseEnter:Connect(function() -- Line 124
		end)
		var17.leaveConnection = var18.MouseLeave:Connect(function() -- Line 128
			--[[ Upvalues[2]:
				[1]: arg1 (readonly)
				[2]: arg2 (readonly)
			]]
			arg1:Release(arg2, true)
		end)
	end
end
function module_upvr.CreateInFrame(arg1, arg2, arg3) -- Line 133
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	if not arg2:FindFirstChild("Button") then
		local TextButton = Instance.new("TextButton", arg2)
		TextButton.BackgroundTransparency = 1
		TextButton.ZIndex = arg2.ZIndex + 1
		TextButton.Name = "Button"
		TextButton.Size = UDim2.new(1, 0, 1, 0)
		TextButton.Text = ""
	end
	module_upvr:Create(arg2, arg3)
end
local tbl_upvr = {
	orange = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(242, 147, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(241, 90, 36))});
	white = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(240, 240, 240)), ColorSequenceKeypoint.new(1, Color3.fromRGB(190, 190, 190))});
	green = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(251, 255, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(24, 242, 0))});
	yen = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 242, 67)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 204, 0))});
	gift = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(205, 0, 241)), ColorSequenceKeypoint.new(1, Color3.fromRGB(111, 0, 190))});
	blue = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 110, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 179, 255))});
	red = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(204, 0, 0))});
}
function module_upvr.Color(arg1, arg2, arg3) -- Line 177
	--[[ Upvalues[1]:
		[1]: tbl_upvr (readonly)
	]]
	local var32 = tbl_upvr[arg3]
	arg2.Content.Background.UIGradient.Color = var32
	if arg2.Content:FindFirstChild("Label") then
		arg2.Content.Label.TextColor3 = var32.Keypoints[1].Value
	end
end
function module_upvr.SetColours(arg1, arg2, arg3, arg4, arg5) -- Line 187
	for i_2, v_2 in arg2 do
		if arg3 == i_2 then
			arg1:Color(v_2, arg4 or "green")
		else
			arg1:Color(v_2, arg5 or "white")
		end
	end
end
function module_upvr.Destroy(arg1, arg2) -- Line 201
	if arg1.maids[arg2] then
		arg1.maids[arg2]:Destroy()
	end
	arg1.maids[arg2] = nil
end
return module_upvr