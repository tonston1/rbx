-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:26
-- Luau version 6, Types version 3
-- Time taken: 0.000509 seconds

local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
return function(arg1, arg2, arg3) -- Line 9
	--[[ Upvalues[1]:
		[1]: any_IsServer_result1_upvr (readonly)
	]]
	local dailyReward = arg1.Data.dailyReward
	dailyReward.lastReward = arg2
	dailyReward.streak += 1
	local var4
	if any_IsServer_result1_upvr then
		var4 = "Server"
	else
		var4 = "Client"
	end
	print(var4, arg1.Data.dailyReward)
end