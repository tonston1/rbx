-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:28
-- Luau version 6, Types version 3
-- Time taken: 0.000676 seconds

local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local Badges_upvr = require(game:GetService("ReplicatedStorage").Libraries.Modules.Badges)
return function(arg1, arg2) -- Line 11
	--[[ Upvalues[2]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: Badges_upvr (readonly)
	]]
	local Data = arg1.Data
	Data.rebirth += arg2
	if any_IsServer_result1_upvr then
		arg1.Tags.Player.leaderstats.Wins.Value = arg1.Data.rebirth
		task.spawn(function() -- Line 19
			--[[ Upvalues[2]:
				[1]: Badges_upvr (copied, readonly)
				[2]: arg1 (readonly)
			]]
			Badges_upvr:Reward(arg1, "rebirth")
		end)
	end
end