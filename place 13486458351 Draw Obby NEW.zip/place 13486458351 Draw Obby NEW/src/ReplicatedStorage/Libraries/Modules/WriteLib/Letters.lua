-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:35
-- Luau version 6, Types version 3
-- Time taken: 0.000874 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TimeSync_upvr = require(ReplicatedStorage.Libraries.Modules.TimeSync)
local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local TablePlus_upvr = require(ReplicatedStorage.Libraries.Modules.TablePlus)
return function(arg1, arg2) -- Line 10
	--[[ Upvalues[3]:
		[1]: TimeSync_upvr (readonly)
		[2]: any_IsServer_result1_upvr (readonly)
		[3]: TablePlus_upvr (readonly)
	]]
	local tostring_result1 = tostring(math.floor(TimeSync_upvr.time() / 86400))
	local var7
	if not arg1.Data.letters[tostring_result1] then
		var7 = arg1.Data
		var7 = 0
		var7.letters[tostring_result1] = var7
	end
	var7 = arg1.Data
	var7 = var7.letters[tostring_result1]
	var7 += arg2
	var7.letters[tostring_result1] = var7
	if any_IsServer_result1_upvr then
		var7 = arg1.Tags.Player.leaderstats
		var7 = TablePlus_upvr:Sum(arg1.Data.letters)
		var7.Letters.Value = var7
	end
	if any_IsServer_result1_upvr then
		var7 = "Server"
	else
		var7 = "Client"
	end
	print(var7, arg1.Data.letters)
end