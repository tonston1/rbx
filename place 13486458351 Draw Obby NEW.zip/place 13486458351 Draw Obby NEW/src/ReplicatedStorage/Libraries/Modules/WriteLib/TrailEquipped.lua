-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:34
-- Luau version 6, Types version 3
-- Time taken: 0.003911 seconds

local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
return function(arg1, arg2) -- Line 8
	--[[ Upvalues[2]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: ReplicatedStorage_upvr (readonly)
	]]
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	local Player_2 = arg1.Tags.Player
	local var11 = Player_2
	if var11 then
		var11 = Player_2.Character
	end
	if var11 then
		local HumanoidRootPart_2 = var11:FindFirstChild("HumanoidRootPart")
	end
	if table.find(arg1.Data.trails, arg2) then
		arg1.Data.trailEquipped = arg2
		if any_IsServer_result1_upvr then
			if HumanoidRootPart_2 then
				local class_Trail = HumanoidRootPart_2:FindFirstChildWhichIsA("Trail")
				if class_Trail then
					class_Trail:Destroy()
				end
			end
			local class_Trail_4 = ReplicatedStorage_upvr.Assets.Trails[arg2]:FindFirstChildWhichIsA("Trail")
			if class_Trail_4 then
				local clone_2 = class_Trail_4:Clone()
				clone_2.Parent = arg1.Tags.Player.Character.HumanoidRootPart
				clone_2.Attachment0 = arg1.Tags.Player.Character.HumanoidRootPart.Trail1
				clone_2.Attachment1 = arg1.Tags.Player.Character.HumanoidRootPart.Trail2
			end
		end
	end
end