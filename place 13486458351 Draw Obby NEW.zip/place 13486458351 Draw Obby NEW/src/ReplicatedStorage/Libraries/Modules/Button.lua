-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:05
-- Luau version 6, Types version 3
-- Time taken: 0.003933 seconds

local TweenService_upvr = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Maid_upvr = require(ReplicatedStorage.Libraries.Classes.Maid)
local PlayerGui = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local module = {
	pressing = {};
	highlightMaids = Maid_upvr.new();
	buttonMaids = Maid_upvr.new();
}
local SoundEffect_upvr = require(ReplicatedStorage.Libraries.Classes.SoundEffect)
function module.Hover(arg1, arg2, arg3) -- Line 24
	--[[ Upvalues[2]:
		[1]: SoundEffect_upvr (readonly)
		[2]: TweenService_upvr (readonly)
	]]
	if arg3 then
		SoundEffect_upvr.new("Hover"):Play()
		TweenService_upvr:Create(arg2.Content, TweenInfo.new(0.12), {
			Size = UDim2.new(1.1, 0, 1.1, 0);
		}):Play()
	end
end
function module.Release(arg1, arg2, arg3) -- Line 34
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	arg1.pressing[arg2] = nil
	if arg3 then
		TweenService_upvr:Create(arg2.Content, TweenInfo.new(0.2), {
			Size = UDim2.new(1, 0, 1, 0);
		}):Play()
	end
end
function module.Press(arg1, arg2, arg3) -- Line 45
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	arg1.pressing[arg2] = true
	if arg3 then
		TweenService_upvr:Create(arg2.Content, TweenInfo.new(0.1), {
			Size = UDim2.new(0.7, 0, 0.7, 0);
		}):Play()
	end
end
local RunService_upvr = game:GetService("RunService")
function module.Highlight(arg1, arg2) -- Line 56
	--[[ Upvalues[3]:
		[1]: Maid_upvr (readonly)
		[2]: RunService_upvr (readonly)
		[3]: TweenService_upvr (readonly)
	]]
	local any_new_result1_2_upvr = Maid_upvr.new()
	any_new_result1_2_upvr.highlight = arg2.Content:Clone()
	any_new_result1_2_upvr.highlight.UIGradient.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
	any_new_result1_2_upvr.highlight.UIGradient.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.3, 1), NumberSequenceKeypoint.new(0.5, 0.5), NumberSequenceKeypoint.new(0.7, 1), NumberSequenceKeypoint.new(1, 1)})
	any_new_result1_2_upvr.highlight.UIGradient.Rotation = -45
	any_new_result1_2_upvr.highlight.UIGradient.Offset = Vector2.new(-1, 0)
	any_new_result1_2_upvr.highlight.Parent = arg2.Content
	for _, v in ipairs(any_new_result1_2_upvr.highlight:GetChildren()) do
		if not v:IsA("UIGradient") then
			v:Destroy()
		end
	end
	local var19_upvw = 0
	any_new_result1_2_upvr.highlightConnection = RunService_upvr.Heartbeat:Connect(function(arg1_2) -- Line 80
		--[[ Upvalues[5]:
			[1]: var19_upvw (read and write)
			[2]: any_new_result1_2_upvr (readonly)
			[3]: TweenService_upvr (copied, readonly)
			[4]: arg2 (readonly)
			[5]: RunService_upvr (copied, readonly)
		]]
		var19_upvw += arg1_2
		if 2.5 <= var19_upvw then
			var19_upvw = 0
			any_new_result1_2_upvr.highlight.UIGradient.Offset = Vector2.new(-1, 0)
			TweenService_upvr:Create(any_new_result1_2_upvr.highlight.UIGradient, TweenInfo.new(0.8), {
				Offset = Vector2.new(1, 0);
			}):Play()
			TweenService_upvr:Create(arg2.Content, TweenInfo.new(0.5), {
				Size = UDim2.new(1.1, 0, 1.1, 0);
			}):Play()
			local var23_upvw = 0
			any_new_result1_2_upvr.scaleBackConnection = RunService_upvr.Heartbeat:Connect(function(arg1_3) -- Line 97
				--[[ Upvalues[3]:
					[1]: var23_upvw (read and write)
					[2]: TweenService_upvr (copied, readonly)
					[3]: arg2 (copied, readonly)
				]]
				var23_upvw += arg1_3
				if 0.5 <= var23_upvw then
					var23_upvw = 0
					TweenService_upvr:Create(arg2.Content, TweenInfo.new(0.5), {
						Size = UDim2.new(1, 0, 1, 0);
					}):Play()
				end
			end)
		end
	end)
	arg1.highlightMaids[arg2] = any_new_result1_2_upvr
end
function module.StopHighlight(arg1, arg2) -- Line 114
	arg1.highlightMaids[arg2] = nil
end
local Arrow_2_upvr = script.Effects.Arrow
local EffectUI_upvr = PlayerGui:WaitForChild("EffectUI")
function module.Arrow(arg1, arg2) -- Line 119
	--[[ Upvalues[4]:
		[1]: Maid_upvr (readonly)
		[2]: Arrow_2_upvr (readonly)
		[3]: EffectUI_upvr (readonly)
		[4]: TweenService_upvr (readonly)
	]]
	local any_new_result1 = Maid_upvr.new()
	any_new_result1.arrow = Arrow_2_upvr:Clone()
	any_new_result1.arrow.Position = UDim2.new(0, arg2.AbsolutePosition.X + arg2.AbsoluteSize.X / 2, 0, arg2.AbsolutePosition.Y - arg2.AbsoluteSize.Y / 2)
	any_new_result1.arrow.ImageColor3 = Color3.fromRGB(255, 255, 255)
	any_new_result1.arrow.Parent = EffectUI_upvr
	TweenService_upvr:Create(any_new_result1.arrow, TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, math.huge, true, 0), {
		Position = UDim2.new(0, arg2.AbsolutePosition.X + arg2.AbsoluteSize.X / 2, 0, arg2.AbsolutePosition.Y - arg2.AbsoluteSize.Y);
	}):Play()
	arg1.buttonMaids[arg2] = any_new_result1
end
function module.StopArrow(arg1, arg2) -- Line 134
	arg1.buttonMaids[arg2] = nil
end
local Shine_2_upvr = script.Effects.Shine
local MainUI_upvr = PlayerGui:WaitForChild("MainUI")
function module.Shine(arg1) -- Line 139
	--[[ Upvalues[3]:
		[1]: Shine_2_upvr (readonly)
		[2]: TweenService_upvr (readonly)
		[3]: MainUI_upvr (readonly)
	]]
	local any_GetMouseLocation_result1 = game:GetService("UserInputService"):GetMouseLocation()
	local clone_upvr = Shine_2_upvr:Clone()
	clone_upvr.Position = UDim2.fromOffset(any_GetMouseLocation_result1.X, any_GetMouseLocation_result1.Y)
	TweenService_upvr:Create(clone_upvr, TweenInfo.new(0.3), {
		Size = UDim2.new(0.3, 0, 0.3, 0);
		ImageTransparency = 1;
	}):Play()
	clone_upvr.Parent = MainUI_upvr
	task.spawn(function() -- Line 151
		--[[ Upvalues[1]:
			[1]: clone_upvr (readonly)
		]]
		task.wait(0.3)
		clone_upvr:Destroy()
	end)
end
function module.GetPressing(arg1, arg2) -- Line 158
	return arg1.pressing[arg2]
end
return module