-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:15
-- Luau version 6, Types version 3
-- Time taken: 0.001095 seconds

return {
	ranks = {"Newbie", "Amateur", "Rookie", "Skilled", "Expert", "Pro", "Veteran", "Super", "Champ", "Master", "Elite", "Legend", "Goated", "Gamer", "Godly", "Big Brain", "Unbeatable", "Brainiac", "Super God", "Albert Einstein", "Giga Brain", "Champion", "Smart", "Super", "Genius", "BIGGEST BRAIN"};
	colour = {Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 249, 83), Color3.fromRGB(130, 255, 85), Color3.fromRGB(255, 131, 49), Color3.fromRGB(255, 65, 65), Color3.fromRGB(38, 42, 255), Color3.fromRGB(131, 48, 255), Color3.fromRGB(255, 67, 255), Color3.fromRGB(121, 255, 244), Color3.fromRGB(117, 230, 31), Color3.fromRGB(255, 106, 0), Color3.fromRGB(255, 0, 0), Color3.fromRGB(86, 86, 86), Color3.fromRGB(50, 154, 59), Color3.fromRGB(255, 255, 255), Color3.fromRGB(208, 145, 239), Color3.fromRGB(255, 0, 0), Color3.fromRGB(119, 38, 141), Color3.fromRGB(255, 247, 3), Color3.fromRGB(0, 149, 194), Color3.fromRGB(109, 0, 217), Color3.fromRGB(229, 115, 0), Color3.fromRGB(147, 236, 238), Color3.fromRGB(162, 230, 106), Color3.fromRGB(74, 92, 255), Color3.fromRGB(170, 0, 255)};
}