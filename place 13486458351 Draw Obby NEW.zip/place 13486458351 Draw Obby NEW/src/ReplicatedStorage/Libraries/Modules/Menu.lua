-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:12
-- Luau version 6, Types version 3
-- Time taken: 0.001329 seconds

local module_upvr = require(game:GetService("ReplicatedStorage"):WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Device"))
local PlayerGui_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local BindableEvent_upvr = Instance.new("BindableEvent")
local BindableEvent_upvr_2 = Instance.new("BindableEvent")
return {
	menu = nil;
	submenu = nil;
	Opened = BindableEvent_upvr.Event;
	Closed = BindableEvent_upvr_2.Event;
	Open = function(arg1, arg2, arg3, ...) -- Line 31, Named "Open"
		--[[ Upvalues[3]:
			[1]: PlayerGui_upvr (readonly)
			[2]: module_upvr (readonly)
			[3]: BindableEvent_upvr (readonly)
		]]
		local SOME_2 = PlayerGui_upvr:FindFirstChild(arg2.."UI")
		if arg3 == arg1.submenu and arg2 == arg1.menu then
			arg1:Close()
		else
			if not SOME_2 then return end
			arg1:Close(true)
			arg1.menu = arg2
			arg1.submenu = arg3
			SOME_2.Enabled = true
			if module_upvr == "Mobile" then
				warn("Tween the gui out of the way")
			end
			BindableEvent_upvr:Fire(arg1.menu, arg3, ...)
		end
	end;
	Close = function(arg1) -- Line 52, Named "Close"
		--[[ Upvalues[3]:
			[1]: PlayerGui_upvr (readonly)
			[2]: BindableEvent_upvr_2 (readonly)
			[3]: module_upvr (readonly)
		]]
		if arg1.menu then
			local SOME = PlayerGui_upvr:FindFirstChild(arg1.menu.."UI")
			if SOME then
				SOME.Enabled = false
			end
			BindableEvent_upvr_2:Fire(arg1.menu)
			arg1.menu = nil
			if module_upvr == "Mobile" then
				warn("Tween the gui back")
			end
		end
	end;
}