-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:42
-- Luau version 6, Types version 3
-- Time taken: 0.000725 seconds

local module = {}
local StarterGui_upvr = game:GetService("StarterGui")
function module.Enable(arg1, arg2) -- Line 7
	--[[ Upvalues[1]:
		[1]: StarterGui_upvr (readonly)
	]]
	task.spawn(function() -- Line 8
		--[[ Upvalues[2]:
			[1]: arg2 (readonly)
			[2]: StarterGui_upvr (copied, readonly)
		]]
		for _ = 1, 10 do
			local pcall_result1, _ = pcall(function() -- Line 10
				--[[ Upvalues[2]:
					[1]: arg2 (copied, readonly)
					[2]: StarterGui_upvr (copied, readonly)
				]]
				for i_2, v in pairs(arg2) do
					StarterGui_upvr:SetCoreGuiEnabled(i_2, v)
				end
			end)
			if pcall_result1 then break end
			task.wait(1)
		end
	end)
end
return module