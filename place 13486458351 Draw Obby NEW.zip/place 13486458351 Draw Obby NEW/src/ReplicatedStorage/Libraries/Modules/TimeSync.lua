-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:10
-- Luau version 6, Types version 3
-- Time taken: 0.001260 seconds

local tbl_upvr = {
	Jan = 1;
	Feb = 2;
	Mar = 3;
	Apr = 4;
	May = 5;
	Jun = 6;
	Jul = 7;
	Aug = 8;
	Sep = 9;
	Oct = 10;
	Nov = 11;
	Dec = 12;
}
local var2_upvw = false
local var3_upvw
local var4_upvw
local var5_upvw
local function _RFC2616DateStringToUnixTimestamp_upvr(arg1) -- Line 26, Named "_RFC2616DateStringToUnixTimestamp"
	--[[ Upvalues[1]:
		[1]: tbl_upvr (readonly)
	]]
	local any_match_result1, any_match_result2, any_match_result3, any_match_result4, any_match_result5, any_match_result6 = arg1:match(".*, (.*) (.*) (.*) (.*):(.*):(.*) .*")
	return os.time({
		day = any_match_result1;
		month = tbl_upvr[any_match_result2];
		year = any_match_result3;
		hour = any_match_result4;
		min = any_match_result5;
		sec = any_match_result6;
	})
end
local HttpService_upvr = game:GetService("HttpService")
local function _init_upvr() -- Line 47, Named "_init"
	--[[ Upvalues[6]:
		[1]: var2_upvw (read and write)
		[2]: HttpService_upvr (readonly)
		[3]: var3_upvw (read and write)
		[4]: _RFC2616DateStringToUnixTimestamp_upvr (readonly)
		[5]: var4_upvw (read and write)
		[6]: var5_upvw (read and write)
	]]
	if var2_upvw then
	else
		local pcall_result1, pcall_result2 = pcall(function() -- Line 50
			--[[ Upvalues[5]:
				[1]: HttpService_upvr (copied, readonly)
				[2]: var3_upvw (copied, read and write)
				[3]: _RFC2616DateStringToUnixTimestamp_upvr (copied, readonly)
				[4]: var4_upvw (copied, read and write)
				[5]: var5_upvw (copied, read and write)
			]]
			var3_upvw = _RFC2616DateStringToUnixTimestamp_upvr(HttpService_upvr:RequestAsync({
				Url = "http://google.com";
			}).Headers.date)
			var4_upvw = tick()
			var5_upvw = (var4_upvw - tick()) / 2
		end)
		if not pcall_result1 then
			warn(pcall_result2)
			var3_upvw = os.time()
			var4_upvw = tick()
			var5_upvw = 0
		end
		var2_upvw = true
	end
end
return {
	inited = function() -- Line 42, Named "_inited"
		--[[ Upvalues[1]:
			[1]: var2_upvw (read and write)
		]]
		return var2_upvw
	end;
	init = _init_upvr;
	time = function() -- Line 70, Named "_time"
		--[[ Upvalues[5]:
			[1]: var2_upvw (read and write)
			[2]: _init_upvr (readonly)
			[3]: var3_upvw (read and write)
			[4]: var4_upvw (read and write)
			[5]: var5_upvw (read and write)
		]]
		if not var2_upvw then
			_init_upvr()
		end
		return var3_upvw + tick() - var4_upvw - var5_upvw
	end;
}