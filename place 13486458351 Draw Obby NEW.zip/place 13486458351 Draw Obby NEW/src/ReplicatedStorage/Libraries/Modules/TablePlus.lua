-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:07
-- Luau version 6, Types version 3
-- Time taken: 0.000899 seconds

return {
	DeepCopy = function(arg1, arg2) -- Line 4, Named "DeepCopy"
		local module = {}
		for i, v in pairs(arg2) do
			if type(v) == "table" then
				v = arg1:DeepCopy(v)
			end
			module[i] = v
		end
		return module
	end;
	Sum = function(arg1, arg2) -- Line 17, Named "Sum"
		local var12 = 0
		for _, v_2 in pairs(arg2) do
			var12 += v_2
		end
		return var12
	end;
	Count = function(arg1, arg2) -- Line 28, Named "Count"
		local var20 = 0
		for _, _ in pairs(arg2) do
			var20 += 1
		end
		return var20
	end;
}