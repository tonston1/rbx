-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:14
-- Luau version 6, Types version 3
-- Time taken: 0.003603 seconds

local module = {
	decimalPlaces = 2;
	suffixTable = {'k', 'M', 'B', 'T', "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Vi"};
	Round = function(arg1, arg2, arg3, arg4) -- Line 25, Named "Round"
		local var3 = arg2 * 10 ^ arg3
		if arg4 then
			return math.floor(var3) / 10 ^ arg3
		end
		return math.floor(tonumber(tostring(var3)) + 0.5) / 10 ^ arg3
	end;
	Separate = function(arg1, arg2, arg3) -- Line 37, Named "Separate"
		local var4
		repeat
			local string_gsub_result1, string_gsub_result2 = string.gsub(var4, "^(-?%d+)(%d%d%d)", "%1"..(arg3 or ',').."%2")
			var4 = string_gsub_result1
		until string_gsub_result2 == 0
		return var4
	end;
	Abbreviate = function(arg1, arg2, arg3, arg4) -- Line 54, Named "Abbreviate"
		-- KONSTANTERROR: [0] 1. Error Block 28 start (CF ANALYSIS FAILED)
		if type(arg2) ~= "number" then
			error("numberToString invalid parameter #1, expected number, got \"nil\"", 2)
		end
		local var7
		if var7 < 1000 and -1000 < var7 then
			var7 = arg1:Round(var7, arg3)
			return tostring(var7)
		end
		if var7 >= 0 then
		else
		end
		var7 = math.abs(math.floor(var7))
		local _ = #arg1.suffixTable
		-- KONSTANTERROR: [0] 1. Error Block 28 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [85] 68. Error Block 16 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [85] 68. Error Block 16 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [52] 42. Error Block 11 start (CF ANALYSIS FAILED)
		-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [85.10]
		-- KONSTANTWARNING: Failed to evaluate expression, replaced with nil [85.263438]
		-- KONSTANTERROR: [52] 42. Error Block 11 end (CF ANALYSIS FAILED)
	end;
}
local tbl_upvr = {{1000, 'M'}, {900, "CM"}, {500, 'D'}, {400, "CD"}, {100, 'C'}, {90, "XC"}, {50, 'L'}, {40, "XL"}, {10, 'X'}, {9, "IX"}, {5, 'V'}, {4, "IV"}, {1, 'I'}}
function module.ToRoman(arg1, arg2) -- Line 111
	--[[ Upvalues[1]:
		[1]: tbl_upvr (readonly)
	]]
	local var27
	while 0 < arg2 do
		for _, v in pairs(tbl_upvr) do
			while v[1] <= arg2 do
				var27 = var27..v[2]
			end
		end
	end
	return var27
end
function module.OrdinalSuffix(arg1, arg2) -- Line 129
	local string_sub_result1 = string.sub(arg2, string.len(arg2))
	local tonumber_result1 = tonumber(string_sub_result1)
	if tonumber_result1 == 1 then
		string_sub_result1 = "st"
	elseif tonumber_result1 == 2 then
		string_sub_result1 = "nd"
	elseif tonumber_result1 == 3 then
		string_sub_result1 = "rd"
	else
		string_sub_result1 = "th"
	end
	return arg2..string_sub_result1
end
function module.FormatTimerHMS(arg1, arg2) -- Line 137
	return "%02i:%02i:%02i":format(arg2 / 60 / 60 % 24, arg2 / 60 % 60, arg2 % 60)
end
function module.FormatTimerDHSM(arg1, arg2) -- Line 144
	return "%02i:%02i:%02i:%02i":format(arg2 / 60 / 60 / 24, arg2 / 60 / 60 % 24, arg2 / 60 % 60, arg2 % 60)
end
function module.FormatTimerMS(arg1, arg2) -- Line 151
	return "%02i:%02i":format(arg2 / 60 % 60, arg2 % 60)
end
function module.FormatTimerMSM(arg1, arg2) -- Line 158
	return "%02i:%02i.%02i":format(arg2 / 60 % 60, arg2 % 60, math.floor(tonumber(string.sub(arg2 % 1, 2, 4) * 100)))
end
local Tween_2_upvr = require(script.Tween)
function module.Tween(arg1, arg2) -- Line 165
	--[[ Upvalues[1]:
		[1]: Tween_2_upvr (readonly)
	]]
	return Tween_2_upvr.new(arg2)
end
local NumberTween_2_upvr = require(script.NumberTween)
function module.NumberTween(arg1, arg2) -- Line 170
	--[[ Upvalues[1]:
		[1]: NumberTween_2_upvr (readonly)
	]]
	return NumberTween_2_upvr.new(arg2)
end
return module