-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:09
-- Luau version 6, Types version 3
-- Time taken: 0.001176 seconds

return {
	Start = function(arg1, arg2, arg3, arg4) -- Line 4, Named "Start"
		local var2_upvr = arg3 or 'Y'
		local var3_upvr = arg4 or 0
		local class_UIListLayout_upvr = arg2:FindFirstChildOfClass("UIListLayout")
		if not class_UIListLayout_upvr then
			class_UIListLayout_upvr = arg2:FindFirstChildOfClass("UIGridLayout")
			local var5
		end
		if class_UIListLayout_upvr then
			local function INLINED_2() -- Internal function, doesn't exist in bytecode
				var5 = UDim2.new(0, 0, 0, class_UIListLayout_upvr.AbsoluteContentSize.Y + var3_upvr)
				return var5
			end
			if var2_upvr ~= 'Y' or not INLINED_2() then
				var5 = UDim2.new(0, class_UIListLayout_upvr.AbsoluteContentSize.X + var3_upvr, 0, 0)
			end
			arg2.CanvasSize = var5
			var5 = class_UIListLayout_upvr:GetPropertyChangedSignal("AbsoluteContentSize"):Connect
			var5(function() -- Line 10, Named "setSize"
				--[[ Upvalues[4]:
					[1]: var2_upvr (readonly)
					[2]: class_UIListLayout_upvr (readonly)
					[3]: var3_upvr (readonly)
					[4]: arg2 (readonly)
				]]
				local var6
				local function INLINED() -- Internal function, doesn't exist in bytecode
					var6 = UDim2.new(0, 0, 0, class_UIListLayout_upvr.AbsoluteContentSize.Y + var3_upvr)
					return var6
				end
				if var2_upvr ~= 'Y' or not INLINED() then
					var6 = UDim2.new(0, class_UIListLayout_upvr.AbsoluteContentSize.X + var3_upvr, 0, 0)
				end
				arg2.CanvasSize = var6
			end)
		end
	end;
}