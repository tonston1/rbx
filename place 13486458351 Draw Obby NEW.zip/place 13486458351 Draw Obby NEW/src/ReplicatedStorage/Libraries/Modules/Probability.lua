-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:03
-- Luau version 6, Types version 3
-- Time taken: 0.002496 seconds

return {
	Convert = function(arg1, arg2) -- Line 4, Named "Convert"
		for i, v in pairs(arg2) do
			if v ~= 0 then
				({})[0 + v] = i
			end
		end
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		return {}
	end;
	ConvertToPercent = function(arg1, arg2) -- Line 18, Named "ConvertToPercent"
		local var15 = 0
		for _, v_2 in pairs(arg2) do
			var15 += v_2
		end
		for i_3, v_3 in pairs(arg2) do
			if v_3 ~= 0 then
				({})[i_3] = v_3 / var15
			end
		end
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		return {}
	end;
	GetChosen = function(arg1, arg2) -- Line 35, Named "GetChosen"
		-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
		local any_Convert_result1 = arg1:Convert(arg2)
		local var42
		for i_4, _ in pairs(any_Convert_result1) do
			if var42 < i_4 then
				var42 = i_4
			end
		end
		local any_NextNumber_result1 = Random.new():NextNumber(0, var42)
		for i_5, _ in pairs(any_Convert_result1) do
			if any_NextNumber_result1 < i_5 and i_5 < var42 then
			end
		end
		return any_NextNumber_result1, i_5
	end;
	GetItem = function(arg1, arg2) -- Line 58, Named "GetItem"
		local _, any_GetChosen_result2 = arg1:GetChosen(arg2)
		return arg1:Convert(arg2)[any_GetChosen_result2]
	end;
}