-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:41
-- Luau version 6, Types version 3
-- Time taken: 0.000962 seconds

local PhysicsService = game:GetService("PhysicsService")
if game:GetService("RunService"):IsServer() then
	PhysicsService:RegisterCollisionGroup("Drawing")
	PhysicsService:RegisterCollisionGroup("Other")
	PhysicsService:RegisterCollisionGroup("Disabled")
	PhysicsService:CollisionGroupSetCollidable("Other", "Drawing", false)
	PhysicsService:CollisionGroupSetCollidable("Other", "Disabled", false)
	PhysicsService:CollisionGroupSetCollidable("Other", "Other", true)
	PhysicsService:CollisionGroupSetCollidable("Drawing", "Disabled", false)
	PhysicsService:CollisionGroupSetCollidable("Drawing", "Drawing", true)
	PhysicsService:CollisionGroupSetCollidable("Disabled", "Disabled", true)
end
return {
	currentCollision = {};
	AddToGroup = function(arg1, arg2, arg3) -- Line 35, Named "AddToGroup"
		if arg2:IsA("BasePart") then
			if arg2.CollisionGroup == "Disabled" then
			else
				arg2.CollisionGroup = arg3
			end
		end
		for _, v in ipairs(arg2:GetDescendants()) do
			if v:isA("BasePart") and v.CollisionGroup ~= "Disabled" then
				v.CollisionGroup = arg3
			end
		end
	end;
}