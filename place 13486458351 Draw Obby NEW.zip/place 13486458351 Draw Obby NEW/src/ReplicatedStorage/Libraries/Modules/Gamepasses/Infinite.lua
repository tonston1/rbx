-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:19
-- Luau version 6, Types version 3
-- Time taken: 0.000680 seconds

local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local Profiles_upvr = require(game:GetService("ReplicatedStorage").Libraries.Modules.Profiles)
local Players_upvr = game:GetService("Players")
return function(arg1) -- Line 11
	--[[ Upvalues[3]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: Profiles_upvr (readonly)
		[3]: Players_upvr (readonly)
	]]
	if any_IsServer_result1_upvr then
		print("Player bought "..script.Name)
	else
		local LocalPlayer = Players_upvr.LocalPlayer
		if arg1 == LocalPlayer then
			LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("DrawUI"):WaitForChild("Ink"):WaitForChild("Label").Text = "INFINITE INK"
			print("Player bought "..script.Name)
		end
	end
end