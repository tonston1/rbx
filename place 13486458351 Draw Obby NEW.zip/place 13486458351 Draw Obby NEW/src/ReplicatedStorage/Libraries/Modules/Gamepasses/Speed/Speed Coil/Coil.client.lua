-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:18
-- Luau version 6, Types version 3
-- Time taken: 0.001217 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Parent_2_upvr = script.Parent
local any_new_result1_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Maid")).new()
local var4_upvw
local module_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("SoundEffect"))
Parent_2_upvr.Equipped:Connect(function() -- Line 15
	--[[ Upvalues[4]:
		[1]: Parent_2_upvr (readonly)
		[2]: var4_upvw (read and write)
		[3]: any_new_result1_upvr (readonly)
		[4]: module_upvr (readonly)
	]]
	local Parent = Parent_2_upvr.Parent
	local var8_upvr = Parent
	if var8_upvr then
		var8_upvr = Parent:FindFirstChild("Humanoid")
	end
	if not Parent then
	else
		if not var8_upvr then return end
		var4_upvw = var8_upvr.WalkSpeed
		var8_upvr.WalkSpeed = 50
		any_new_result1_upvr.speedChangeListener = var8_upvr:GetPropertyChangedSignal("WalkSpeed"):Connect(function() -- Line 25
			--[[ Upvalues[2]:
				[1]: var4_upvw (copied, read and write)
				[2]: var8_upvr (readonly)
			]]
			var4_upvw = var8_upvr.WalkSpeed
		end)
		module_upvr.new("SpeedCoil", Parent_2_upvr.Handle.Position):Play()
	end
end)
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
Parent_2_upvr.Unequipped:Connect(function() -- Line 33
	--[[ Upvalues[3]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: any_new_result1_upvr (readonly)
		[3]: var4_upvw (read and write)
	]]
	local Character = LocalPlayer_upvr.Character
	local var13 = Character
	if var13 then
		var13 = Character:FindFirstChild("Humanoid")
	end
	if not Character then
	else
		if not var13 then return end
		any_new_result1_upvr.speedChangeListener = nil
		var13.WalkSpeed = var4_upvw
		var4_upvw = nil
		print("passed")
	end
end)