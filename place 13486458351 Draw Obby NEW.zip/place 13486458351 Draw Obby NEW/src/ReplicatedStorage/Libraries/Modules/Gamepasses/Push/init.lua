-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:20
-- Luau version 6, Types version 3
-- Time taken: 0.001022 seconds

local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local Maid_upvr = require(game:GetService("ReplicatedStorage").Libraries.Classes.Maid)
local Push_upvr = script.Push
local Players_upvr = game:GetService("Players")
return function(arg1) -- Line 12
	--[[ Upvalues[4]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: Maid_upvr (readonly)
		[3]: Push_upvr (readonly)
		[4]: Players_upvr (readonly)
	]]
	if any_IsServer_result1_upvr then
		local any_new_result1_upvr = Maid_upvr.new()
		Push_upvr:Clone().Parent = arg1.Backpack
		any_new_result1_upvr.respawnConnection = arg1.CharacterAdded:Connect(function() -- Line 16, Named "give"
			--[[ Upvalues[2]:
				[1]: Push_upvr (copied, readonly)
				[2]: arg1 (readonly)
			]]
			Push_upvr:Clone().Parent = arg1.Backpack
		end)
		any_new_result1_upvr.leaveConnection = Players_upvr.PlayerRemoving:Connect(function(arg1_2) -- Line 22
			--[[ Upvalues[2]:
				[1]: arg1 (readonly)
				[2]: any_new_result1_upvr (readonly)
			]]
			if arg1_2 == arg1 then
				any_new_result1_upvr:Destroy()
			end
		end)
		print("Player bought "..script.Name)
	else
		any_new_result1_upvr = Players_upvr.LocalPlayer
		if arg1 == any_new_result1_upvr then
			print("Player bought "..script.Name)
		end
	end
end