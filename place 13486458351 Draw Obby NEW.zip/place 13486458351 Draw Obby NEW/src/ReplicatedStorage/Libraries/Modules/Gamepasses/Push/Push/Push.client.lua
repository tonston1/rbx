-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:21
-- Luau version 6, Types version 3
-- Time taken: 0.003005 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players_upvr = game:GetService("Players")
local LocalPlayer_upvr = Players_upvr.LocalPlayer
local Parent_upvr = script.Parent
local var5_upvw
local function getCharacters_upvr() -- Line 22, Named "getCharacters"
	--[[ Upvalues[2]:
		[1]: Players_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
	]]
	for _, v in ipairs(Players_upvr:GetPlayers()) do
		if v ~= LocalPlayer_upvr then
			local Character = v.Character
			local var14 = Character
			if var14 then
				var14 = Character:FindFirstChild("HumanoidRootPart")
			end
			if var14 then
				table.insert({}, Character)
			end
		end
	end
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	return {}
end
local function getCharacterFromChildren_upvr(arg1) -- Line 41, Named "getCharacterFromChildren"
	--[[ Upvalues[2]:
		[1]: Players_upvr (readonly)
		[2]: LocalPlayer_upvr (readonly)
	]]
	for _, v_2 in ipairs(Players_upvr:GetPlayers()) do
		if v_2 ~= LocalPlayer_upvr and v_2.Character then
			table.insert({}, v_2.Character)
		end
	end
	for _, v_3 in ipairs(arg1) do
		-- KONSTANTERROR: Expression was reused, decompilation is incorrect
		for _, v_4 in ipairs({}) do
			if v_3:IsDescendantOf(v_4) then
				return v_4
			end
		end
	end
end
Parent_upvr.Equipped:Connect(function() -- Line 61
	--[[ Upvalues[2]:
		[1]: var5_upvw (read and write)
		[2]: LocalPlayer_upvr (readonly)
	]]
	local var31
	if var5_upvw then
	else
		var31 = LocalPlayer_upvr
		local Character_2 = var31.Character
		var31 = Character_2
		if var31 then
			var31 = Character_2:FindFirstChild("Humanoid")
		end
		if not Character_2 then return end
		if not var31 then return end
		print(var31.RigType)
		if var31.RigType == Enum.HumanoidRigType.R15 then
			print("R15")
			var5_upvw = var31:LoadAnimation(script.R15)
			return
		end
		if var31.RigType == Enum.HumanoidRigType.R6 then
			print("R6")
			var5_upvw = var31:LoadAnimation(script.R6)
		end
	end
end)
local var34_upvw = 0
local any_GetReplica_result1_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Profiles")):GetReplica("Game")
local Push_upvr = LocalPlayer_upvr:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("Buttons"):WaitForChild("Backpack"):WaitForChild("Push")
local any_new_result1_upvr = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Maid")).new()
local RunService_upvr = game:GetService("RunService")
Parent_upvr.Activated:Connect(function() -- Line 81
	--[[ Upvalues[9]:
		[1]: var34_upvw (read and write)
		[2]: Parent_upvr (readonly)
		[3]: getCharacters_upvr (readonly)
		[4]: getCharacterFromChildren_upvr (readonly)
		[5]: var5_upvw (read and write)
		[6]: any_GetReplica_result1_upvr (readonly)
		[7]: Push_upvr (readonly)
		[8]: any_new_result1_upvr (readonly)
		[9]: RunService_upvr (readonly)
	]]
	if 0 < var34_upvw then
	else
		local Parent = Parent_upvr.Parent
		local var40 = Parent
		if var40 then
			var40 = Parent:FindFirstChild("Humanoid")
		end
		local var41 = Parent
		if var41 then
			var41 = Parent:FindFirstChild("HumanoidRootPart")
		end
		if not Parent then return end
		if not var40 then return end
		if not var41 then return end
		if var40.Health <= 0 then return end
		local OverlapParams_new_result1 = OverlapParams.new()
		OverlapParams_new_result1.FilterType = Enum.RaycastFilterType.Include
		OverlapParams_new_result1.FilterDescendantsInstances = getCharacters_upvr()
		local getCharacterFromChildren_upvr_result1 = getCharacterFromChildren_upvr(workspace:GetPartBoundsInBox(Parent_upvr.Handle.CFrame, Parent_upvr.Handle.Size, OverlapParams_new_result1))
		var5_upvw:Play()
		warn("Play animation here based on r6/r15")
		if not getCharacterFromChildren_upvr_result1 then return end
		any_GetReplica_result1_upvr:FireServer("Push", getCharacterFromChildren_upvr_result1, var41.CFrame.LookVector)
		Push_upvr.Cooldown.Visible = true
		var34_upvw = 20
		any_new_result1_upvr.cooldownConnection = RunService_upvr.Heartbeat:Connect(function(arg1) -- Line 111
			--[[ Upvalues[3]:
				[1]: var34_upvw (copied, read and write)
				[2]: Push_upvr (copied, readonly)
				[3]: any_new_result1_upvr (copied, readonly)
			]]
			var34_upvw -= arg1
			Push_upvr.Cooldown.Number.Text = math.ceil(var34_upvw)
			if var34_upvw <= 0 then
				var34_upvw = 0
				Push_upvr.Cooldown.Visible = false
				any_new_result1_upvr.cooldownConnection = nil
			end
		end)
	end
end)