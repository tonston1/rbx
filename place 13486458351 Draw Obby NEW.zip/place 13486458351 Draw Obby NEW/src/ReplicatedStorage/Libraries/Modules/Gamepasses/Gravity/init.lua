-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:16
-- Luau version 6, Types version 3
-- Time taken: 0.000975 seconds

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
local Profiles_upvr = require(ReplicatedStorage.Libraries.Modules.Profiles)
local Maid_upvr = require(ReplicatedStorage.Libraries.Classes.Maid)
local Gravity_Coil_upvr = script["Gravity Coil"]
local Players_upvr = game:GetService("Players")
return function(arg1) -- Line 12
	--[[ Upvalues[5]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: Profiles_upvr (readonly)
		[3]: Maid_upvr (readonly)
		[4]: Gravity_Coil_upvr (readonly)
		[5]: Players_upvr (readonly)
	]]
	if any_IsServer_result1_upvr then
		local any_new_result1_upvr = Maid_upvr.new()
		Gravity_Coil_upvr:Clone().Parent = arg1.Backpack
		any_new_result1_upvr.respawnConnection = arg1.CharacterAdded:Connect(function() -- Line 18, Named "give"
			--[[ Upvalues[2]:
				[1]: Gravity_Coil_upvr (copied, readonly)
				[2]: arg1 (readonly)
			]]
			Gravity_Coil_upvr:Clone().Parent = arg1.Backpack
		end)
		any_new_result1_upvr.leaveConnection = Players_upvr.PlayerRemoving:Connect(function(arg1_2) -- Line 24
			--[[ Upvalues[2]:
				[1]: arg1 (readonly)
				[2]: any_new_result1_upvr (readonly)
			]]
			if arg1_2 == arg1 then
				any_new_result1_upvr:Destroy()
			end
		end)
		print("Player bought "..script.Name)
	else
		any_new_result1_upvr = Players_upvr
		any_new_result1_upvr = any_new_result1_upvr.LocalPlayer:WaitForChild("PlayerGui")
		if arg1 == any_new_result1_upvr.LocalPlayer then
			print("Player bought "..script.Name)
		end
	end
end