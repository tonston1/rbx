-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:16
-- Luau version 6, Types version 3
-- Time taken: 0.004400 seconds

local MarketplaceService_upvr = game:GetService("MarketplaceService")
local Players_upvr = game:GetService("Players")
local BindableEvent_upvr = Instance.new("BindableEvent")
local module_upvr = {
	gamepasses = {-- : First try: K:0: attempt to index nil with 't'
;
	cache = {};
	Bought = BindableEvent_upvr.Event;
}
local any_IsServer_result1_upvr = game:GetService("RunService"):IsServer()
function module_upvr.Owns(arg1, arg2, arg3) -- Line 25
	--[[ Upvalues[3]:
		[1]: any_IsServer_result1_upvr (readonly)
		[2]: Players_upvr (readonly)
		[3]: MarketplaceService_upvr (readonly)
	]]
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	local var26
	if not any_IsServer_result1_upvr then
		var26 = Players_upvr
		if arg2 ~= var26.LocalPlayer then return end
	end
	var26 = arg2.UserId
	local tostring_result1_upvr_2 = tostring(var26)
	var26 = nil
	for _ = 1, 5 do
		local pcall_result1_2, pcall_result2_2 = pcall(function() -- Line 37
			--[[ Upvalues[4]:
				[1]: arg1 (readonly)
				[2]: tostring_result1_upvr_2 (readonly)
				[3]: arg3 (readonly)
				[4]: MarketplaceService_upvr (copied, readonly)
			]]
			local var29
			local function INLINED_2() -- Internal function, doesn't exist in bytecode
				var29 = arg1.cache[tostring_result1_upvr_2][arg3]
				return var29
			end
			if not arg1.cache[tostring_result1_upvr_2] or not INLINED_2() then
				var29 = MarketplaceService_upvr:UserOwnsGamePassAsync(tostring_result1_upvr_2, arg3)
			end
			return var29
		end)
		var26 = pcall_result1_2
		local var32 = pcall_result2_2
		if var26 then break end
		task.wait(0.2)
	end
	if arg2 and var26 and var32 then
		if arg1.cache[tostring_result1_upvr_2] then
			arg1.cache[tostring_result1_upvr_2][arg3] = var32
		end
		return var32
	end
	if not var26 then
		warn(var32)
	end
end
function module_upvr.Apply(arg1, arg2, arg3) -- Line 60
	if script:FindFirstChild(arg1.gamepasses[arg3]) then
	end
end
function module_upvr.Init(arg1, arg2) -- Line 69
	arg1.cache[tostring(arg2.UserId)] = {}
	for i_2, _ in pairs(arg1.gamepasses) do
		if arg1:Owns(arg2, i_2) then
			arg1:Apply(arg2, i_2)
		end
	end
end
function module_upvr.Clear(arg1, arg2) -- Line 81
	arg1.cache[tostring(arg2.UserId)] = nil
end
MarketplaceService_upvr.PromptGamePassPurchaseFinished:Connect(function(arg1, arg2, arg3) -- Line 87
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: BindableEvent_upvr (readonly)
	]]
	if arg3 then
		module_upvr.cache[tostring(arg1.UserId)][arg2] = true
		module_upvr:Apply(arg1, arg2)
		BindableEvent_upvr:Fire(arg1, arg2)
	end
end)
Players_upvr.PlayerAdded:Connect(function(arg1) -- Line 98
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	module_upvr:Init(arg1)
end)
Players_upvr.PlayerRemoving:Connect(function(arg1) -- Line 101
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	module_upvr:Clear(arg1)
end)
for _, v_2 in ipairs(Players_upvr:GetPlayers()) do
	module_upvr:Init(v_2)
end
return module_upvr