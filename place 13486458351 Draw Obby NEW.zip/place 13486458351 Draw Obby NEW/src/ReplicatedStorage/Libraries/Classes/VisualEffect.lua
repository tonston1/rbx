-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:55
-- Luau version 6, Types version 3
-- Time taken: 0.002682 seconds

local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
local module_upvr_2 = {}
module_upvr_2.__index = module_upvr_2
local module_upvr = require(ReplicatedStorage_upvr:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Maid"))
function module_upvr_2.new(arg1, arg2) -- Line 11
	--[[ Upvalues[3]:
		[1]: module_upvr_2 (readonly)
		[2]: module_upvr (readonly)
		[3]: ReplicatedStorage_upvr (readonly)
	]]
	local setmetatable_result1 = setmetatable({}, module_upvr_2)
	setmetatable_result1.maid = module_upvr.new()
	setmetatable_result1.maid.effect = ReplicatedStorage_upvr.Assets.VisualEffects:FindFirstChild(arg1):Clone()
	setmetatable_result1.maid.effect.CanCollide = false
	setmetatable_result1.maid.effect.CanQuery = false
	setmetatable_result1.maid.effect.CanTouch = false
	if typeof(arg2) == "Instance" then
		setmetatable_result1.maid.effect.CFrame = arg2.CFrame
		setmetatable_result1.maid.effect.Parent = arg2
		local WeldConstraint = Instance.new("WeldConstraint")
		WeldConstraint.Part0 = setmetatable_result1.maid.effect
		WeldConstraint.Part1 = arg2
		WeldConstraint.Parent = setmetatable_result1.maid.effect
		return setmetatable_result1
	end
	if typeof(arg2) == "Vector3" then
		setmetatable_result1.maid.effect.Position = arg2
		setmetatable_result1.maid.effect.Parent = workspace
		return setmetatable_result1
	end
	if typeof(arg2) == "CFrame" then
		setmetatable_result1.maid.effect.CFrame = arg2
		setmetatable_result1.maid.effect.Parent = workspace
	end
	return setmetatable_result1
end
local TweenService_upvr = game:GetService("TweenService")
function module_upvr_2.Play(arg1, arg2) -- Line 43
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	task.spawn(function() -- Line 44
		--[[ Upvalues[3]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: TweenService_upvr (copied, readonly)
		]]
		-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
		-- KONSTANTERROR: [0] 1. Error Block 30 start (CF ANALYSIS FAILED)
		local Attachment = arg1.maid.effect:FindFirstChild("Attachment")
		if not Attachment then
			Attachment = arg1.maid.effect
		end
		for _, v in ipairs(Attachment:GetChildren()) do
			if v:IsA("ParticleEmitter") and 0 < v.Lifetime.Max then
				local Max = v.Lifetime.Max
			end
		end
		-- KONSTANTERROR: [0] 1. Error Block 30 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [42] 29. Error Block 46 start (CF ANALYSIS FAILED)
		for _, v_2 in ipairs(Attachment:GetChildren()) do
			if v_2:IsA("ParticleEmitter") then
				v_2.Enabled = true
			end
		end
		task.wait(arg2)
		for _, v_3 in ipairs(Attachment:GetChildren()) do
			if v_3:IsA("ParticleEmitter") then
				v_3.Enabled = false
			end
		end
		TweenService_upvr:Create(arg1.maid.effect, TweenInfo.new(Max), {
			Transparency = 1;
		}):Play()
		task.wait(Max)
		arg1:Destroy()
		-- KONSTANTERROR: [42] 29. Error Block 46 end (CF ANALYSIS FAILED)
	end)
end
function module_upvr_2.Destroy(arg1) -- Line 84
	arg1.maid:Destroy()
end
return module_upvr_2