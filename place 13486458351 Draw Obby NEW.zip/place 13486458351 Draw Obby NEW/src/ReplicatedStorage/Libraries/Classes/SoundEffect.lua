-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:54
-- Luau version 6, Types version 3
-- Time taken: 0.001784 seconds

local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
local module_upvr_2 = {}
module_upvr_2.__index = module_upvr_2
local module_upvr = require(ReplicatedStorage_upvr:WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Maid"))
local SoundService_upvr = game:GetService("SoundService")
function module_upvr_2.new(arg1, arg2) -- Line 12
	--[[ Upvalues[4]:
		[1]: module_upvr_2 (readonly)
		[2]: module_upvr (readonly)
		[3]: ReplicatedStorage_upvr (readonly)
		[4]: SoundService_upvr (readonly)
	]]
	local setmetatable_result1 = setmetatable({}, module_upvr_2)
	setmetatable_result1.maid = module_upvr.new()
	if typeof(arg2) == "Instance" then
		setmetatable_result1.maid.soundPart = ReplicatedStorage_upvr.Assets.SoundEffects.SoundPart:Clone()
		setmetatable_result1.maid.soundPart.CFrame = arg2.CFrame
		setmetatable_result1.maid.soundPart.Anchored = false
		setmetatable_result1.maid.soundPart.Parent = arg2
		local WeldConstraint = Instance.new("WeldConstraint")
		WeldConstraint.Part0 = setmetatable_result1.maid.soundPart
		WeldConstraint.Part1 = arg2
		WeldConstraint.Parent = setmetatable_result1.maid.soundPart
	elseif typeof(arg2) == "Vector3" then
		setmetatable_result1.maid.soundPart = ReplicatedStorage_upvr.Assets.SoundEffects.SoundPart:Clone()
		setmetatable_result1.maid.soundPart.Position = arg2
		setmetatable_result1.maid.soundPart.Parent = workspace
	end
	setmetatable_result1.maid.sound = ReplicatedStorage_upvr.Assets.SoundEffects:FindFirstChild(arg1):Clone()
	local soundPart = setmetatable_result1.maid.soundPart
	if not soundPart then
		soundPart = SoundService_upvr
	end
	setmetatable_result1.maid.sound.Parent = soundPart
	return setmetatable_result1
end
local TweenService_upvr = game:GetService("TweenService")
function module_upvr_2.Play(arg1, arg2) -- Line 44
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	arg1.maid.sound:Play()
	task.spawn(function() -- Line 47
		--[[ Upvalues[3]:
			[1]: arg2 (readonly)
			[2]: TweenService_upvr (copied, readonly)
			[3]: arg1 (readonly)
		]]
		if arg2 then
			task.wait(arg2)
			TweenService_upvr:Create(arg1.maid.sound, TweenInfo.new(0.5), {
				Volume = 0;
			}):Play()
			task.wait(0.5)
			arg1.maid.sound:Stop()
		else
			arg1.maid.sound.Ended:Connect(function() -- Line 56
				--[[ Upvalues[1]:
					[1]: arg1 (copied, readonly)
				]]
				arg1:Destroy()
			end)
		end
	end)
end
function module_upvr_2.Destroy(arg1) -- Line 64
	arg1.maid:Destroy()
end
return module_upvr_2