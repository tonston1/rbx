-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:04
-- Luau version 6, Types version 3
-- Time taken: 0.001593 seconds

local TweenService_upvr = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local InventoryHelpers_upvr = require(ReplicatedStorage.Libraries.Helpers.InventoryHelpers)
local module_upvr = {
	notification = script.Notification;
	canOverrideSelf = false;
	parent = "PackNotifications";
}
local PlayerGui_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
function module_upvr.new(arg1) -- Line 21
	--[[ Upvalues[3]:
		[1]: InventoryHelpers_upvr (readonly)
		[2]: module_upvr (readonly)
		[3]: PlayerGui_upvr (readonly)
	]]
	local clone = script.Notification:Clone()
	local any_CreateAthleteCard_result1 = InventoryHelpers_upvr:CreateAthleteCard({
		athlete = arg1.values.athleteName;
		style = arg1.values.athleteStyle;
	}, clone)
	any_CreateAthleteCard_result1.AnchorPoint = Vector2.new(0.5, 0.5)
	any_CreateAthleteCard_result1.Position = UDim2.fromScale(0.5, 0.5)
	local module = {
		notificationLabel = clone;
	}
	module.notificationInstance = arg1
	local parent = arg1.values.parent
	if not parent then
		parent = module_upvr.parent
	end
	module.parent = parent
	clone.Parent = PlayerGui_upvr:FindFirstChild(module.parent, true)
	return module
end
local Sounds_upvr = require(ReplicatedStorage.Libraries.Classes.Sounds)
function module_upvr.Show(arg1) -- Line 42
	--[[ Upvalues[3]:
		[1]: TweenService_upvr (readonly)
		[2]: Sounds_upvr (readonly)
		[3]: InventoryHelpers_upvr (readonly)
	]]
	arg1.notificationLabel.Size = UDim2.new(0, 0, 0, 0)
	TweenService_upvr:Create(arg1.notificationLabel, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
		Size = UDim2.new(1, 0, 1, 0);
	}):Play()
	local tbl = {
		athlete = arg1.notificationInstance.values.athleteName;
		style = arg1.notificationInstance.values.athleteStyle;
	}
	Sounds_upvr.Play(Sounds_upvr.new({"Loot", InventoryHelpers_upvr.GetAthleteSound(tbl.style..tbl.athlete)}, nil), nil, true)
	task.wait(2.5)
end
function module_upvr.Hide(arg1) -- Line 59
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	TweenService_upvr:Create(arg1.notificationLabel, TweenInfo.new(0.3), {
		Size = UDim2.new(0, 0, 0, 0);
	}):Play()
	task.wait(0.3)
end
function module_upvr.Destroy(arg1) -- Line 66
	arg1.notificationLabel:Destroy()
end
return module_upvr