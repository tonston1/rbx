-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:01
-- Luau version 6, Types version 3
-- Time taken: 0.001411 seconds

local module_2_upvr = {
	notification = script.Notification;
	canOverrideSelf = true;
	parent = "MiddleNotifications";
}
local PlayerGui_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
function module_2_upvr.new(arg1) -- Line 16
	--[[ Upvalues[2]:
		[1]: module_2_upvr (readonly)
		[2]: PlayerGui_upvr (readonly)
	]]
	local clone = script.Notification:Clone()
	clone.Name = Random.new():NextInteger(1, 100)
	local module = {
		notificationLabel = clone;
	}
	module.notificationInstance = arg1
	local parent = arg1.values.parent
	if not parent then
		parent = module_2_upvr.parent
	end
	module.parent = parent
	clone.LayoutOrder = arg1.layoutOrder
	clone.Label.Text = arg1.values.message
	clone.Parent = PlayerGui_upvr:FindFirstChild(module.parent, true)
	local colour = arg1.values.colour
	if not colour then
		colour = Color3.fromRGB(255, 255, 255)
	end
	clone.Label.TextColor3 = colour
	return module
end
function module_2_upvr.Show(arg1) -- Line 33
	task.wait(arg1.notificationInstance.values.length or 3)
end
local TweenService_upvr = game:GetService("TweenService")
function module_2_upvr.Hide(arg1) -- Line 37
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	TweenService_upvr:Create(arg1.notificationLabel, TweenInfo.new(0.2), {
		Size = UDim2.new(1, 0, 0, 0);
	}):Play()
	task.wait(0.2)
end
function module_2_upvr.Destroy(arg1) -- Line 45
	arg1.notificationLabel:Destroy()
end
return module_2_upvr