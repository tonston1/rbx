-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:06
-- Luau version 6, Types version 3
-- Time taken: 0.004125 seconds

local TweenService_upvr = game:GetService("TweenService")
local module_upvr = {
	notification = script.Notification;
	canOverrideSelf = true;
	parent = "GoalNotifications";
}
local function explodeText_upvr(arg1) -- Line 16, Named "explodeText"
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	local Main = arg1.notificationLabel:FindFirstChild("Main")
	if Main then
		Main = arg1.notificationLabel:FindFirstChild("Main"):FindFirstChild("Goal")
	end
	local Shadow = arg1.notificationLabel:FindFirstChild("Shadow")
	if not Main then
	else
		if not Main:IsA("GuiObject") then return end
		if not Shadow then return end
		if not Shadow:IsA("GuiObject") then return end
		Main.Position = UDim2.new(0.5, 0, 0.5, 0)
		Main.Size = UDim2.new(0.5, 0, 0, 0)
		TweenService_upvr:Create(Main, TweenInfo.new(1.5, Enum.EasingStyle.Elastic), {
			Size = UDim2.new(1, 0, 0.7, 0);
		}):Play()
		task.wait(1.5)
		TweenService_upvr:Create(Main, TweenInfo.new(0.5), {
			Position = UDim2.new(0.5, 0, 1.5, 0);
		}):Play()
		task.wait(0.5)
	end
end
local function text_upvr(arg1, arg2, arg3, arg4) -- Line 37, Named "text"
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	local Main_2 = arg1.notificationLabel:FindFirstChild("Main")
	if Main_2 then
		Main_2 = arg1.notificationLabel:FindFirstChild("Main"):FindFirstChild("Label")
	end
	if not Main_2 then
	else
		if not Main_2:IsA("TextLabel") then return end
		Main_2.Visible = true
		Main_2.Text = arg2
		Main_2.Position = UDim2.new(0.5, 0, -0.4, 0)
		TweenService_upvr:Create(Main_2, TweenInfo.new(0.5), {
			Position = UDim2.new(0.5, 0, 0.5, 0);
		}):Play()
		task.wait(arg3)
		if arg4 then
			TweenService_upvr:Create(Main_2, TweenInfo.new(0.5), {
				Position = UDim2.new(0.5, 0, 1.4, 0);
			}):Play()
			task.wait(0.5)
		end
	end
end
local PlayerGui_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
function module_upvr.new(arg1) -- Line 59
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: PlayerGui_upvr (readonly)
	]]
	local clone = script.Notification:Clone()
	local module = {
		notificationLabel = clone;
	}
	module.notificationInstance = arg1
	local var13
	if not var13 then
		var13 = module_upvr.parent
	end
	module.parent = var13
	local function INLINED() -- Internal function, doesn't exist in bytecode
		var13 = Color3.fromRGB(0, 0, 255)
		return var13
	end
	if arg1.values.team ~= "Blue" or not INLINED() then
		var13 = Color3.fromRGB(255, 0, 0)
	end
	clone.Shadow.ImageColor3 = var13
	clone.Parent = PlayerGui_upvr:FindFirstChild(module.parent, true)
	return module
end
function module_upvr.Show(arg1) -- Line 74
	--[[ Upvalues[3]:
		[1]: TweenService_upvr (readonly)
		[2]: explodeText_upvr (readonly)
		[3]: text_upvr (readonly)
	]]
	local kicker = arg1.notificationInstance.values.kicker
	local assister = arg1.notificationInstance.values.assister
	local magnitude = arg1.notificationInstance.values.magnitude
	local Main_3 = arg1.notificationLabel:FindFirstChild("Main")
	if Main_3 then
		Main_3 = arg1.notificationLabel:FindFirstChild("Main"):FindFirstChild("Label")
	end
	local Shadow_2 = arg1.notificationLabel:FindFirstChild("Shadow")
	if not Main_3 then
	else
		if not Main_3:IsA("TextLabel") then return end
		if not Shadow_2 then return end
		if not Shadow_2:IsA("GuiObject") then return end
		TweenService_upvr:Create(arg1.notificationLabel, TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, true), {
			Rotation = Random.new():NextInteger(-10, 10);
		}):Play()
		Main_3.Visible = false
		Shadow_2.Size = UDim2.new(Shadow_2.Size.X.Scale, 0, 0, 0)
		TweenService_upvr:Create(Shadow_2, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
			Size = UDim2.new(Shadow_2.Size.X.Scale, 0, 0.99, 0);
		}):Play()
		explodeText_upvr(arg1)
		if kicker then
			text_upvr(arg1, kicker.Name, 2, true)
		end
		if assister then
			text_upvr(arg1, assister.Name, 2, true)
		end
		if magnitude then
			text_upvr(arg1, "Distance: "..math.floor(magnitude / 2.47)..'m', 2, false)
		end
	end
end
function module_upvr.Hide(arg1) -- Line 108
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	TweenService_upvr:Create(arg1.notificationLabel, TweenInfo.new(1), {
		Position = UDim2.new(0, 0, 1, 0);
	}):Play()
	task.wait(1)
end
function module_upvr.Destroy(arg1) -- Line 116
	arg1.notificationLabel:Destroy()
end
return module_upvr