-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:07
-- Luau version 6, Types version 3
-- Time taken: 0.002075 seconds

local TweenService_upvr = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Button2_upvr = require(ReplicatedStorage.Libraries.Modules.Button2)
local module_upvr = {
	notification = script.Notification;
	canOverrideSelf = true;
	parent = "FriendNotificationPrompts";
}
local Maid_upvr = require(ReplicatedStorage.Libraries.Classes.Maid)
local PlayerGui_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
function module_upvr.new(arg1) -- Line 22
	--[[ Upvalues[3]:
		[1]: module_upvr (readonly)
		[2]: Maid_upvr (readonly)
		[3]: PlayerGui_upvr (readonly)
	]]
	local clone = script.Notification:Clone()
	local module = {
		notificationLabel = clone;
	}
	module.notificationInstance = arg1
	local parent = arg1.values.parent
	if not parent then
		parent = module_upvr.parent
	end
	module.parent = parent
	module.maid = Maid_upvr.new()
	clone.LayoutOrder = arg1.layoutOrder
	clone.Parent = PlayerGui_upvr:FindFirstChild(module.parent, true)
	return module
end
local any_GetReplica_result1_upvr = require(ReplicatedStorage.Libraries.Modules.Profiles):GetReplica("Game")
local NumberHelper_upvr = require(ReplicatedStorage.Libraries.Helpers.NumberHelper)
function module_upvr.Show(arg1) -- Line 38
	--[[ Upvalues[4]:
		[1]: TweenService_upvr (readonly)
		[2]: Button2_upvr (readonly)
		[3]: any_GetReplica_result1_upvr (readonly)
		[4]: NumberHelper_upvr (readonly)
	]]
	arg1.maid.yield = Instance.new("BindableEvent")
	arg1.notificationLabel.Position = UDim2.fromScale(0.5, 1.5)
	TweenService_upvr:Create(arg1.notificationLabel, TweenInfo.new(0.2), {
		Position = UDim2.fromScale(0.5, 0);
	}):Play()
	Button2_upvr:Create(arg1.notificationLabel.Exit, function() -- Line 46
		--[[ Upvalues[1]:
			[1]: arg1 (readonly)
		]]
		arg1.maid.yield:Fire()
	end)
	Button2_upvr:Create(arg1.notificationLabel.Invite, function() -- Line 50
		--[[ Upvalues[2]:
			[1]: any_GetReplica_result1_upvr (copied, readonly)
			[2]: arg1 (readonly)
		]]
		any_GetReplica_result1_upvr:FireServer("SkipAd")
		arg1.maid.yield:Fire()
	end)
	task.spawn(function() -- Line 55
		--[[ Upvalues[2]:
			[1]: arg1 (readonly)
			[2]: NumberHelper_upvr (copied, readonly)
		]]
		local var16 = 15
		while arg1.maid.yield and 0 <= var16 do
			arg1.notificationLabel.Invite.Content.Timer.Text = NumberHelper_upvr:FormatTimerMS(var16 - 1)
			task.wait(1)
		end
		if arg1.maid.yield then
			arg1.maid.yield:Fire()
		end
	end)
	arg1.maid.yield.Event:Wait()
	arg1.maid.yield = nil
end
function module_upvr.Hide(arg1) -- Line 74
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	TweenService_upvr:Create(arg1.notificationLabel, TweenInfo.new(0.2), {
		Position = UDim2.fromScale(0.5, 1.5);
	}):Play()
	task.wait(0.2)
end
function module_upvr.Destroy(arg1) -- Line 82
	--[[ Upvalues[1]:
		[1]: Button2_upvr (readonly)
	]]
	Button2_upvr:Destroy(arg1.notificationLabel.Exit)
	Button2_upvr:Destroy(arg1.notificationLabel.Invite)
	arg1.maid:Destroy()
	arg1.notificationLabel:Destroy()
end
return module_upvr