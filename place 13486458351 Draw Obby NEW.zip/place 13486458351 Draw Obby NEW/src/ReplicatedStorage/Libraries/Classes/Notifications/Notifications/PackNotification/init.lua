-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:05
-- Luau version 6, Types version 3
-- Time taken: 0.001997 seconds

local TweenService_upvr = game:GetService("TweenService")
local ReplicatedStorage_upvr = game:GetService("ReplicatedStorage")
local module_upvr = {
	notification = script.Notification;
	canOverrideSelf = false;
	parent = "PackNotifications";
}
local SharedConstants_upvr = require(ReplicatedStorage_upvr.Libraries.Modules.Constants.SharedConstants)
local PlayerGui_upvr = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
function module_upvr.new(arg1) -- Line 17
	--[[ Upvalues[3]:
		[1]: module_upvr (readonly)
		[2]: SharedConstants_upvr (readonly)
		[3]: PlayerGui_upvr (readonly)
	]]
	local clone = script.Notification:Clone()
	local module = {
		notificationLabel = clone;
	}
	module.notificationInstance = arg1
	local parent = arg1.values.parent
	if not parent then
		parent = module_upvr.parent
	end
	module.parent = parent
	clone.PackIcon.Image = Packs.image(arg1.values)
	clone.PackName.Text = Packs.labelTop(arg1.values)
	clone.PackType.Text = Packs.labelBottom(arg1.values)
	clone.PackName.TextColor3 = SharedConstants_upvr.ID_COLOUR[module.notificationInstance.values.packName]
	clone.Parent = PlayerGui_upvr:FindFirstChild(module.parent, true)
	return module
end
local Sounds_upvr = require(ReplicatedStorage_upvr.Libraries.Classes.Sounds)
function module_upvr.Show(arg1) -- Line 42
	--[[ Upvalues[3]:
		[1]: TweenService_upvr (readonly)
		[2]: ReplicatedStorage_upvr (readonly)
		[3]: Sounds_upvr (readonly)
	]]
	arg1.notificationLabel.PackIcon.Size = UDim2.new(0, 0, 0, 0)
	TweenService_upvr:Create(arg1.notificationLabel.PackIcon, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
		Size = UDim2.new(1, 0, 1, 0);
	}):Play()
	local var11
	local function INLINED() -- Internal function, doesn't exist in bytecode
		var11 = arg1.notificationInstance.values.packName
		return var11
	end
	if not ReplicatedStorage_upvr.Libraries.Classes.Sounds.Sounds.Notifications:FindFirstChild(arg1.notificationInstance.values.packName) or not INLINED() then
		var11 = "CosmeticPack"
	end
	local any_new_result1_upvr = Sounds_upvr.new({"Notifications", var11}, nil)
	any_new_result1_upvr.Finished:Connect(function() -- Line 49
		--[[ Upvalues[2]:
			[1]: Sounds_upvr (copied, readonly)
			[2]: any_new_result1_upvr (readonly)
		]]
		Sounds_upvr.Destroy(any_new_result1_upvr)
	end)
	Sounds_upvr.Play(any_new_result1_upvr)
	task.wait(2.5)
end
function module_upvr.Hide(arg1) -- Line 56
	--[[ Upvalues[1]:
		[1]: TweenService_upvr (readonly)
	]]
	TweenService_upvr:Create(arg1.notificationLabel, TweenInfo.new(0.3), {
		Size = UDim2.new(0, 0, 0, 0);
	}):Play()
	task.wait(0.3)
end
function module_upvr.Destroy(arg1) -- Line 63
	arg1.notificationLabel:Destroy()
end
return module_upvr