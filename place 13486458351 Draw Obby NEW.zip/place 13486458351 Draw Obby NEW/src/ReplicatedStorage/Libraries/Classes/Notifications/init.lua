-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:00
-- Luau version 6, Types version 3
-- Time taken: 0.001972 seconds

local BindableEvent_3_upvr = Instance.new("BindableEvent")
local module_upvr = {
	notificationCount = 0;
	Added = BindableEvent_3_upvr.Event;
	activeNotifications = {};
}
local Notifications_upvr = script.Notifications
function module_upvr.new(arg1, arg2) -- Line 21
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: Notifications_upvr (readonly)
	]]
	local var4 = module_upvr
	var4.notificationCount += 1
	local BindableEvent = Instance.new("BindableEvent")
	local BindableEvent_2 = Instance.new("BindableEvent")
	local SOME = Notifications_upvr:FindFirstChild(arg1)
	local module = {}
	module.notificationType = arg1
	module.moduleObject = SOME
	module.visualInstance = nil
	module.overrided = false
	module.showedEvent = BindableEvent
	module.Showed = BindableEvent.Event
	module.hideEvent = BindableEvent_2
	module.Hidden = BindableEvent_2.Event
	module.values = arg2
	module.layoutOrder = module_upvr.notificationCount
	module.visualInstance = require(SOME).new(module)
	module_upvr.Init(module)
	return module
end
local LocalPlayer_upvr = game:GetService("Players").LocalPlayer
function module_upvr.Init(arg1) -- Line 47
	--[[ Upvalues[3]:
		[1]: LocalPlayer_upvr (readonly)
		[2]: module_upvr (readonly)
		[3]: BindableEvent_3_upvr (readonly)
	]]
	local var10 = module_upvr.activeNotifications[arg1.notificationType]
	if var10 and not require(arg1.moduleObject).canOverrideSelf then
		module_upvr.Override(var10)
	end
	module_upvr.activeNotifications[arg1.notificationType] = arg1
	BindableEvent_3_upvr:Fire(arg1.notificationType)
	task.spawn(function() -- Line 61
		--[[ Upvalues[2]:
			[1]: module_upvr (copied, readonly)
			[2]: arg1 (readonly)
		]]
		module_upvr.Show(arg1)
		module_upvr.Hide(arg1)
	end)
end
function module_upvr.Show(arg1) -- Line 67
	require(arg1.moduleObject).Show(arg1.visualInstance)
	arg1.showedEvent:Fire()
end
function module_upvr.Hide(arg1) -- Line 73
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	require(arg1.moduleObject).Hide(arg1.visualInstance)
	arg1.hideEvent:Fire()
	module_upvr.Destroy(arg1)
end
function module_upvr.Override(arg1) -- Line 80
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	arg1.visualInstance.notificationLabel.Visible = false
	arg1.overrided = true
	module_upvr.activeNotifications[arg1.notificationType] = nil
end
function module_upvr.Destroy(arg1) -- Line 87
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	if not arg1.overrided then
		module_upvr.activeNotifications[arg1.notificationType] = nil
	end
	require(arg1.moduleObject).Destroy(arg1.visualInstance)
	arg1.showedEvent:Destroy()
	arg1.hideEvent:Destroy()
end
return module_upvr