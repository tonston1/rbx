-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:58
-- Luau version 6, Types version 3
-- Time taken: 0.000476 seconds

return function(arg1) -- Line 1
	return function(arg1_2) -- Line 2
		--[[ Upvalues[1]:
			[1]: arg1 (readonly)
		]]
		-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
		local pairs_result1, pairs_result2, pairs_result3 = pairs(arg1_2)
		-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [35] 29. Error Block 12 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [35] 29. Error Block 12 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [7] 7. Error Block 2 start (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [7] 7. Error Block 2 end (CF ANALYSIS FAILED)
	end
end