-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:59
-- Luau version 6, Types version 3
-- Time taken: 0.001861 seconds

function getNormalFromPartFace(arg1, arg2) -- Line 5
	return arg1.CFrame:VectorToWorldSpace(Vector3.FromNormalId(arg2))
end
function normalVectorToFace(arg1, arg2) -- Line 9
	for _, v in ipairs({Enum.NormalId.Front, Enum.NormalId.Back, Enum.NormalId.Bottom, Enum.NormalId.Top, Enum.NormalId.Left, Enum.NormalId.Right}) do
		if 0.999 < getNormalFromPartFace(arg1, v):Dot(arg2) then
			return v
		end
	end
	return nil
end
function getTopLeftCorners(arg1) -- Line 28
	local Size = arg1.Size
	return {
		[Enum.NormalId.Front] = arg1.CFrame * CFrame.new(Size.X / 2, Size.Y / 2, -Size.Z / 2);
		[Enum.NormalId.Back] = arg1.CFrame * CFrame.new(-Size.X / 2, Size.Y / 2, Size.Z / 2);
		[Enum.NormalId.Right] = arg1.CFrame * CFrame.new(Size.X / 2, Size.Y / 2, Size.Z / 2);
		[Enum.NormalId.Left] = arg1.CFrame * CFrame.new(-Size.X / 2, Size.Y / 2, -Size.Z / 2);
		[Enum.NormalId.Bottom] = arg1.CFrame * CFrame.new(Size.X / 2, -Size.Y / 2, Size.Z / 2);
		[Enum.NormalId.Top] = arg1.CFrame * CFrame.new(-Size.X / 2, Size.Y / 2, Size.Z / 2);
	}
end
function getRotationComponents(arg1) -- Line 40
	local module = {arg1:GetComponents()}
	table.remove(module, 1)
	table.remove(module, 2)
	table.remove(module, 3)
	return module
end
local Switch_upvr = require(script.Parent.Switch)
function mapOffsetToFace(arg1, arg2, arg3) -- Line 49
	--[[ Upvalues[1]:
		[1]: Switch_upvr (readonly)
	]]
	local getRotationComponents_result1 = getRotationComponents(arg1)
	local module_2 = {}
	local tbl = {
		[{Enum.NormalId.Right, Enum.NormalId.Left, Enum.NormalId.Top, Enum.NormalId.Bottom}] = CFrame.new(arg1.Z, arg1.Y, arg1.X, unpack(getRotationComponents_result1));
	}
	tbl[{Enum.NormalId.Front, Enum.NormalId.Back}] = arg1
	module_2.X = Switch_upvr(arg3)(tbl)
	local tbl_2 = {
		[{Enum.NormalId.Right, Enum.NormalId.Left}] = CFrame.new(arg1.Z, arg1.Y, arg1.X, unpack(getRotationComponents_result1));
	}
	tbl_2[{Enum.NormalId.Front, Enum.NormalId.Back}] = arg1
	tbl_2[{Enum.NormalId.Top, Enum.NormalId.Bottom}] = CFrame.new(arg1.Y, arg1.X, arg1.Z, unpack(getRotationComponents_result1))
	module_2.Y = Switch_upvr(arg3)(tbl_2)
	return Switch_upvr(arg2)(module_2)
end
return {
	normalVectorToFace = normalVectorToFace;
	getTopLeftCorners = getTopLeftCorners;
	mapOffsetToFace = mapOffsetToFace;
}