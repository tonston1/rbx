-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:00
-- Luau version 6, Types version 3
-- Time taken: 0.001861 seconds

local module_upvr = {}
local round_upvr = math.round
local clamp_upvr = math.clamp
function module_upvr.snapToScale(arg1, arg2) -- Line 12
	--[[ Upvalues[2]:
		[1]: round_upvr (readonly)
		[2]: clamp_upvr (readonly)
	]]
	return clamp_upvr(round_upvr(arg1 / arg2) * arg2, 0, 1)
end
function lerp(arg1, arg2, arg3) -- Line 16
	return (1 - arg3) * arg1 + arg3 * arg2
end
local min_upvr = math.min
local max_upvr = math.max
function map(arg1, arg2, arg3, arg4, arg5, arg6) -- Line 20
	--[[ Upvalues[3]:
		[1]: module_upvr (readonly)
		[2]: min_upvr (readonly)
		[3]: max_upvr (readonly)
	]]
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	local var6
	if not arg6 then
		return lerp(arg4, arg5, module_upvr.getAlphaBetween(arg2, arg3, arg1))
	end
	if var6 < arg5 then
		var6 = arg5
	end
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	return max_upvr(min_upvr(lerp(arg4, arg5, module_upvr.getAlphaBetween(arg2, arg3, arg1)), var6), var6)
end
local module_upvr_2 = require(script.Parent:WaitForChild("Switch"))
function module_upvr.getNewPosition(arg1) -- Line 33
	--[[ Upvalues[1]:
		[1]: module_upvr_2 (readonly)
	]]
	local var8 = arg1._data.Button.AbsoluteSize[arg1._config.Axis]
	local var9 = arg1._holder.AbsoluteSize[arg1._config.Axis]
	local var10 = arg1._data.Button.AnchorPoint[arg1._config.Axis]
	local var11 = var10 * var8 / var9 + arg1._config.Padding / var9
	local map_result1 = map(arg1._data._percent, 0, 1, var11, 1 - var11 + (2 * var8 * var10 - var8) / var9, true)
	return module_upvr_2(arg1._config.Axis)({
		X = UDim2.fromScale(map_result1, arg1._data.Button.Position.Y.Scale);
		Y = UDim2.fromScale(arg1._data.Button.Position.X.Scale, map_result1);
	})
end
function module_upvr.getScaleIncrement(arg1) -- Line 57
	return (1) / ((arg1._config.SliderData.End - arg1._config.SliderData.Start) / arg1._config.SliderData.Increment)
end
function module_upvr.getAlphaBetween(arg1, arg2, arg3) -- Line 61
	return (arg3 - arg1) / (arg2 - arg1)
end
local floor_upvr = math.floor
function module_upvr.getNewValue(arg1) -- Line 65
	--[[ Upvalues[1]:
		[1]: floor_upvr (readonly)
	]]
	local var15 = 1 / arg1._config.SliderData.Increment
	return floor_upvr(lerp(arg1._config.SliderData.Start, arg1._config.SliderData.End, arg1._data._percent) * var15) / var15
end
return module_upvr