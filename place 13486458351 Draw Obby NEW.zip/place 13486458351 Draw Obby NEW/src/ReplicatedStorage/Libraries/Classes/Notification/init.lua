-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:52
-- Luau version 6, Types version 3
-- Time taken: 0.002466 seconds

local BindableEvent_upvr = Instance.new("BindableEvent")
local module_upvr_2 = {
	Added = BindableEvent_upvr.Event;
	active = {};
}
module_upvr_2.__index = module_upvr_2
local module_upvr = require(game:GetService("ReplicatedStorage"):WaitForChild("Libraries"):WaitForChild("Classes"):WaitForChild("Maid"))
local Notifications_upvr = script.Notifications
function module_upvr_2.new(arg1, arg2, ...) -- Line 22
	--[[ Upvalues[4]:
		[1]: module_upvr_2 (readonly)
		[2]: module_upvr (readonly)
		[3]: Notifications_upvr (readonly)
		[4]: BindableEvent_upvr (readonly)
	]]
	local setmetatable_result1_upvr = setmetatable({}, module_upvr_2)
	setmetatable_result1_upvr.id = arg1
	setmetatable_result1_upvr.maid = module_upvr.new()
	setmetatable_result1_upvr.maid.label = Notifications_upvr:FindFirstChild(arg1):Clone()
	setmetatable_result1_upvr.module = require(setmetatable_result1_upvr.maid.label.Notification.Visuals)
	setmetatable_result1_upvr.module:Init(...)
	setmetatable_result1_upvr.maid.label.LayoutOrder = setmetatable_result1_upvr.count
	setmetatable_result1_upvr.maid.label.Parent = arg2
	local override = setmetatable_result1_upvr.module.override
	if not override then
		override = {}
	end
	setmetatable_result1_upvr.override = override
	setmetatable_result1_upvr.overridedBySelf = false
	setmetatable_result1_upvr.canOverrideSelf = setmetatable_result1_upvr.module.canOverrideSelf
	setmetatable_result1_upvr.showedEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Showed = setmetatable_result1_upvr.showedEvent.Event
	setmetatable_result1_upvr.hideEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Hidden = setmetatable_result1_upvr.hideEvent.Event
	if setmetatable_result1_upvr:CheckOverride() then
		setmetatable_result1_upvr:Override()
		module_upvr_2.active[setmetatable_result1_upvr.id] = nil
		return setmetatable_result1_upvr
	end
	module_upvr_2.active[setmetatable_result1_upvr.id] = true
	BindableEvent_upvr:Fire(setmetatable_result1_upvr.id)
	setmetatable_result1_upvr.maid.addedListener = module_upvr_2.Added:Connect(function(arg1_2) -- Line 47
		--[[ Upvalues[2]:
			[1]: setmetatable_result1_upvr (readonly)
			[2]: module_upvr_2 (copied, readonly)
		]]
		if setmetatable_result1_upvr:CheckOverride() then
			setmetatable_result1_upvr:Override()
			module_upvr_2.active[setmetatable_result1_upvr.id] = nil
		elseif arg1_2 == setmetatable_result1_upvr.id and not setmetatable_result1_upvr.canOverrideSelf then
			setmetatable_result1_upvr.overridedBySelf = true
			setmetatable_result1_upvr:Override()
		end
	end)
	task.spawn(function() -- Line 57
		--[[ Upvalues[1]:
			[1]: setmetatable_result1_upvr (readonly)
		]]
		setmetatable_result1_upvr:Show()
		setmetatable_result1_upvr:Hide()
	end)
	return setmetatable_result1_upvr
end
function module_upvr_2.Show(arg1) -- Line 67
	arg1.module:Show()
	arg1.showedEvent:Fire()
end
function module_upvr_2.Hide(arg1) -- Line 73
	arg1.module:Hide()
	arg1.hideEvent:Fire()
	arg1:Destroy()
end
function module_upvr_2.CheckOverride(arg1) -- Line 80
	--[[ Upvalues[1]:
		[1]: module_upvr_2 (readonly)
	]]
	for _, v in ipairs(arg1.override) do
		if module_upvr_2.active[v] then
			return true
		end
	end
	return false
end
function module_upvr_2.Override(arg1) -- Line 91
	arg1.maid.label.Visible = false
end
function module_upvr_2.Destroy(arg1) -- Line 96
	--[[ Upvalues[1]:
		[1]: module_upvr_2 (readonly)
	]]
	if not arg1.overridedBySelf then
		module_upvr_2.active[arg1.id] = nil
	end
	arg1.maid:Destroy()
	arg1.showedEvent:Destroy()
	arg1.hideEvent:Destroy()
end
return module_upvr_2