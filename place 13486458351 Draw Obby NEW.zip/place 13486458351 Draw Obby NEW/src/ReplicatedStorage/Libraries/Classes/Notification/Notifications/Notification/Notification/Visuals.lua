-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:52
-- Luau version 6, Types version 3
-- Time taken: 0.000816 seconds

local TweenService_upvr = game:GetService("TweenService")
local Parent_upvr = script.Parent.Parent
return {
	canOverrideSelf = true;
	Init = function(arg1, ...) -- Line 12, Named "Init"
		--[[ Upvalues[1]:
			[1]: Parent_upvr (readonly)
		]]
		local args_list = {...}
		Parent_upvr.Notification.InfoLabel.Text = args_list[1]
		Parent_upvr.Notification.Icon.Image = args_list[2]
	end;
	Show = function(arg1) -- Line 22, Named "Show"
		--[[ Upvalues[2]:
			[1]: TweenService_upvr (readonly)
			[2]: Parent_upvr (readonly)
		]]
		TweenService_upvr:Create(Parent_upvr, TweenInfo.new(0.2, Enum.EasingStyle.Quad), {
			Size = UDim2.new(1, 0, 0.14, 0);
		}):Play()
		task.wait(4)
	end;
	Hide = function(arg1) -- Line 30, Named "Hide"
		--[[ Upvalues[2]:
			[1]: TweenService_upvr (readonly)
			[2]: Parent_upvr (readonly)
		]]
		TweenService_upvr:Create(Parent_upvr, TweenInfo.new(0.2), {
			Size = UDim2.new(1, 0, 0, 0);
		}):Play()
		task.wait(0.2)
	end;
}