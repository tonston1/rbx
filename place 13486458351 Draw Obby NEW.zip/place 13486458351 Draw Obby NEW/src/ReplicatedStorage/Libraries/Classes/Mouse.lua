-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:52:47
-- Luau version 6, Types version 3
-- Time taken: 0.004622 seconds

local Workspace_upvr = game:GetService("Workspace")
local module_upvr_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Libraries"):WaitForChild("Modules"):WaitForChild("Device"))
local UserInputService_upvr = game:GetService("UserInputService")
local any_GetGuiInset_result1_upvr, _ = game:GetService("GuiService"):GetGuiInset()
local module_upvr = {}
module_upvr.__index = module_upvr
function module_upvr.new() -- Line 17
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: UserInputService_upvr (readonly)
	]]
	local setmetatable_result1_upvr = setmetatable({}, module_upvr)
	setmetatable_result1_upvr.activatedEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Activated = setmetatable_result1_upvr.activatedEvent.Event
	setmetatable_result1_upvr.deactivatedEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Deactivated = setmetatable_result1_upvr.deactivatedEvent.Event
	setmetatable_result1_upvr.movedEvent = Instance.new("BindableEvent")
	setmetatable_result1_upvr.Moved = setmetatable_result1_upvr.movedEvent.Event
	setmetatable_result1_upvr.whitelist = {}
	setmetatable_result1_upvr.blacklist = {}
	setmetatable_result1_upvr.whitelistAncestry = {}
	setmetatable_result1_upvr.blackListAncestry = {}
	setmetatable_result1_upvr.mousePos = Vector2.new()
	setmetatable_result1_upvr.mouseViewport = Vector2.new()
	setmetatable_result1_upvr.mouseDelta = Vector2.new()
	UserInputService_upvr.InputChanged:Connect(function(arg1, arg2) -- Line 37
		--[[ Upvalues[1]:
			[1]: setmetatable_result1_upvr (readonly)
		]]
		local UserInputType = arg1.UserInputType
		if UserInputType == Enum.UserInputType.MouseMovement then
			local vector2 = Vector2.new(arg1.Position.X, arg1.Position.Y)
			local var11 = vector2 - setmetatable_result1_upvr.mousePos
			setmetatable_result1_upvr.mousePos = vector2
			setmetatable_result1_upvr.mouseDelta = Vector2.new(var11.X, var11.Y)
			setmetatable_result1_upvr.movedEvent:Fire()
		elseif UserInputType == Enum.UserInputType.Touch then
			setmetatable_result1_upvr.movedEvent:Fire()
		end
	end)
	UserInputService_upvr.InputBegan:Connect(function(arg1, arg2) -- Line 52
		--[[ Upvalues[1]:
			[1]: setmetatable_result1_upvr (readonly)
		]]
		local UserInputType_3 = arg1.UserInputType
		if UserInputType_3 == Enum.UserInputType.MouseButton1 then
			setmetatable_result1_upvr.activatedEvent:Fire(arg2)
		elseif UserInputType_3 == Enum.UserInputType.Touch then
			setmetatable_result1_upvr:SetViewportPosition()
			setmetatable_result1_upvr.activatedEvent:Fire(arg2)
		end
	end)
	UserInputService_upvr.InputEnded:Connect(function(arg1, arg2) -- Line 64
		--[[ Upvalues[1]:
			[1]: setmetatable_result1_upvr (readonly)
		]]
		local UserInputType_2 = arg1.UserInputType
		if UserInputType_2 == Enum.UserInputType.MouseButton1 then
			setmetatable_result1_upvr.deactivatedEvent:Fire(arg2)
		elseif UserInputType_2 == Enum.UserInputType.Touch then
			setmetatable_result1_upvr:SetViewportPosition()
			setmetatable_result1_upvr.deactivatedEvent:Fire(arg2)
		end
	end)
	return setmetatable_result1_upvr
end
function module_upvr.GetPosition(arg1) -- Line 80
	--[[ Upvalues[1]:
		[1]: module_upvr_2 (readonly)
	]]
	if module_upvr_2 == "Desktop" then
		return arg1.mousePos
	end
	if module_upvr_2 == "Mobile" then
		return arg1.mouseViewport
	end
end
function module_upvr.SetViewportPosition(arg1) -- Line 89
	--[[ Upvalues[2]:
		[1]: UserInputService_upvr (readonly)
		[2]: any_GetGuiInset_result1_upvr (readonly)
	]]
	local any_GetMouseLocation_result1 = UserInputService_upvr:GetMouseLocation()
	arg1.mouseViewport = Vector2.new(any_GetMouseLocation_result1.X, any_GetMouseLocation_result1.Y - any_GetGuiInset_result1_upvr.Y)
end
function module_upvr.AddList(arg1, arg2, ...) -- Line 95
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	local var25
	local function INLINED() -- Internal function, doesn't exist in bytecode
		var25 = arg1.whitelist
		return var25
	end
	if arg2 ~= "Whitelist" or not INLINED() then
		var25 = arg1.blacklist
	end
	if arg2 ~= "Whitelist" or not arg1.whitelistAncestry then
	end
	for _, v_upvr in ipairs({...}) do
		if not table.find(var25, v_upvr) then
			table.insert(var25, v_upvr)
			arg1.blacklistAncestry[v_upvr] = v_upvr.AncestryChanged:Connect(function(arg1_2, arg2_2) -- Line 103
				--[[ Upvalues[3]:
					[1]: arg1 (readonly)
					[2]: arg2 (readonly)
					[3]: v_upvr (readonly)
				]]
				if arg2_2 == nil then
					arg1:RemoveList(arg2, v_upvr)
				end
			end)
		end
	end
end
function module_upvr.RemoveList(arg1, arg2, ...) -- Line 112
	-- KONSTANTWARNING: Variable analysis failed. Output will have some incorrect variable assignments
	local var31
	local function INLINED_2() -- Internal function, doesn't exist in bytecode
		var31 = arg1.whitelist
		return var31
	end
	if arg2 ~= "Whitelist" or not INLINED_2() then
		var31 = arg1.blacklist
	end
	if arg2 ~= "Whitelist" or not arg1.whitelistAncestry then
		local blacklistAncestry = arg1.blacklistAncestry
	end
	local args_list = {...}
	if 0 < #args_list then
		local table_find_result1 = table.find(var31, args_list[1])
		if table_find_result1 then
			local var35 = var31[table_find_result1]
			if blacklistAncestry[var35] then
				blacklistAncestry[var35]:Disconnect()
				blacklistAncestry[var35] = nil
			end
			table.remove(var31, table_find_result1)
		end
		table.remove(args_list, 1)
		arg1:RemoveList(arg2, table.unpack(args_list))
	end
end
function module_upvr.ClearList(arg1, arg2) -- Line 137
	if arg2 ~= "Whitelist" or not arg1.whitelist then
	end
	arg1:RemoveList(arg2, table.unpack(arg1.blacklist))
end
local CurrentCamera_upvr = Workspace_upvr.CurrentCamera
function module_upvr.Project(arg1, arg2) -- Line 144
	--[[ Upvalues[3]:
		[1]: module_upvr_2 (readonly)
		[2]: CurrentCamera_upvr (readonly)
		[3]: Workspace_upvr (readonly)
	]]
	local RaycastParams_new_result1 = RaycastParams.new()
	local var38
	local function INLINED_3() -- Internal function, doesn't exist in bytecode
		var38 = arg1.whitelist
		return var38
	end
	if arg2 ~= "Whitelist" or not INLINED_3() then
		var38 = arg1.blacklist
	end
	RaycastParams_new_result1.FilterDescendantsInstances = var38
	local function INLINED_4() -- Internal function, doesn't exist in bytecode
		var38 = Enum.RaycastFilterType.Include
		return var38
	end
	if arg2 ~= "Whitelist" or not INLINED_4() then
		var38 = Enum.RaycastFilterType.Exclude
	end
	RaycastParams_new_result1.FilterType = var38
	var38 = nil
	local any_GetPosition_result1 = arg1:GetPosition()
	if module_upvr_2 == "Desktop" then
		var38 = CurrentCamera_upvr:ScreenPointToRay(any_GetPosition_result1.X, any_GetPosition_result1.Y, 0)
	elseif module_upvr_2 == "Mobile" then
		var38 = CurrentCamera_upvr:ViewportPointToRay(any_GetPosition_result1.X, any_GetPosition_result1.Y, 0)
	end
	return Workspace_upvr:Raycast(var38.Origin, var38.Direction * 999, RaycastParams_new_result1)
end
return module_upvr