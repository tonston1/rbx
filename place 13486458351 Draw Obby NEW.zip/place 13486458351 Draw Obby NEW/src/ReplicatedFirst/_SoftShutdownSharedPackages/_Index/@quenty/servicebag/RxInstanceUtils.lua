-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:02
-- Luau version 6, Types version 3
-- Time taken: 0.008998 seconds

local any_load_result1 = require(script.Parent.loader).load(script)
local var1_result1_upvr_4 = any_load_result1("Brio")
local var1_result1_upvr_3 = any_load_result1("Maid")
local var1_result1_upvr = any_load_result1("Observable")
local module_upvr = {
	observeProperty = function(arg1, arg2) -- Line 32, Named "observeProperty"
		--[[ Upvalues[2]:
			[1]: var1_result1_upvr (readonly)
			[2]: var1_result1_upvr_3 (readonly)
		]]
		local var7
		if typeof(arg1) ~= "Instance" then
			var7 = false
		else
			var7 = true
		end
		assert(var7, "'instance' should be of type Instance")
		if type(arg2) ~= "string" then
			var7 = false
		else
			var7 = true
		end
		assert(var7, "'propertyName' should be of type string")
		var7 = var1_result1_upvr
		function var7(arg1_2) -- Line 36
			--[[ Upvalues[3]:
				[1]: var1_result1_upvr_3 (copied, readonly)
				[2]: arg1 (readonly)
				[3]: arg2 (readonly)
			]]
			local any_new_result1_17 = var1_result1_upvr_3.new()
			any_new_result1_17:GiveTask(arg1:GetPropertyChangedSignal(arg2):Connect(function() -- Line 39
				--[[ Upvalues[3]:
					[1]: arg1_2 (readonly)
					[2]: arg1 (copied, readonly)
					[3]: arg2 (copied, readonly)
				]]
				arg1_2:Fire(arg1[arg2], arg1)
			end))
			arg1_2:Fire(arg1[arg2], arg1)
			return any_new_result1_17
		end
		return var7.new(var7)
	end;
}
local var1_result1_upvr_2 = any_load_result1("Rx")
function module_upvr.observeAncestry(arg1) -- Line 54
	--[[ Upvalues[1]:
		[1]: var1_result1_upvr_2 (readonly)
	]]
	return var1_result1_upvr_2.start(function() -- Line 55
		--[[ Upvalues[1]:
			[1]: arg1 (readonly)
		]]
		return arg1, arg1.Parent
	end)(var1_result1_upvr_2.fromSignal(arg1.AncestryChanged))
end
function module_upvr.observeFirstAncestorBrio(arg1, arg2) -- Line 69
	--[[ Upvalues[3]:
		[1]: var1_result1_upvr (readonly)
		[2]: var1_result1_upvr_3 (readonly)
		[3]: var1_result1_upvr_4 (readonly)
	]]
	local var13
	if typeof(arg1) ~= "Instance" then
		var13 = false
	else
		var13 = true
	end
	assert(var13, "Bad instance")
	if type(arg2) ~= "string" then
		var13 = false
	else
		var13 = true
	end
	assert(var13, "Bad className")
	var13 = var1_result1_upvr
	function var13(arg1_3) -- Line 73
		--[[ Upvalues[4]:
			[1]: var1_result1_upvr_3 (copied, readonly)
			[2]: arg1 (readonly)
			[3]: arg2 (readonly)
			[4]: var1_result1_upvr_4 (copied, readonly)
		]]
		-- KONSTANTERROR: [0] 1. Error Block 9 start (CF ANALYSIS FAILED)
		local any_new_result1_13_upvr = var1_result1_upvr_3.new()
		local var15_upvw
		any_new_result1_13_upvr:GiveTask(arg1.AncestryChanged:Connect(function() -- Line 77, Named "handleAncestryChanged"
			--[[ Upvalues[6]:
				[1]: arg1 (copied, readonly)
				[2]: arg2 (copied, readonly)
				[3]: var15_upvw (read and write)
				[4]: var1_result1_upvr_4 (copied, readonly)
				[5]: any_new_result1_13_upvr (readonly)
				[6]: arg1_3 (readonly)
			]]
			-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
			local instance = arg1:FindFirstAncestorWhichIsA(arg2)
			-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [9] 8. Error Block 3 start (CF ANALYSIS FAILED)
			var15_upvw = instance
			local any_new_result1_15 = var1_result1_upvr_4.new(instance)
			any_new_result1_13_upvr._current = any_new_result1_15
			arg1_3:Fire(any_new_result1_15)
			do
				return
			end
			-- KONSTANTERROR: [9] 8. Error Block 3 end (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [24] 20. Error Block 7 start (CF ANALYSIS FAILED)
			if var15_upvw then
				any_new_result1_13_upvr._current = nil
				var15_upvw = nil
			end
			-- KONSTANTERROR: [24] 20. Error Block 7 end (CF ANALYSIS FAILED)
		end))
		local instance_2 = arg1:FindFirstAncestorWhichIsA(arg2)
		if instance_2 then
			if instance_2 ~= var15_upvw then
				var15_upvw = instance_2
				local any_new_result1_7 = var1_result1_upvr_4.new(instance_2)
				any_new_result1_13_upvr._current = any_new_result1_7
				arg1_3:Fire(any_new_result1_7)
				-- KONSTANTWARNING: GOTO [48] #39
			end
		elseif var15_upvw then
			any_new_result1_13_upvr._current = nil
			var15_upvw = nil
		end
		-- KONSTANTERROR: [0] 1. Error Block 9 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [48] 39. Error Block 6 start (CF ANALYSIS FAILED)
		do
			return any_new_result1_13_upvr
		end
		-- KONSTANTERROR: [48] 39. Error Block 6 end (CF ANALYSIS FAILED)
	end
	return var13.new(var13)
end
local any_named_result1_upvr = any_load_result1("Symbol").named("unsetValue")
function module_upvr.observePropertyBrio(arg1, arg2, arg3) -- Line 108
	--[[ Upvalues[4]:
		[1]: var1_result1_upvr (readonly)
		[2]: var1_result1_upvr_3 (readonly)
		[3]: any_named_result1_upvr (readonly)
		[4]: var1_result1_upvr_4 (readonly)
	]]
	local var22
	if typeof(arg1) ~= "Instance" then
		var22 = false
	else
		var22 = true
	end
	assert(var22, "Bad instance")
	if type(arg2) ~= "string" then
		var22 = false
	else
		var22 = true
	end
	assert(var22, "Bad propertyName")
	var22 = true
	if type(arg3) ~= "function" then
		if arg3 ~= nil then
			var22 = false
		else
			var22 = true
		end
	end
	assert(var22, "Bad predicate")
	var22 = var1_result1_upvr
	function var22(arg1_4) -- Line 113
		--[[ Upvalues[6]:
			[1]: var1_result1_upvr_3 (copied, readonly)
			[2]: any_named_result1_upvr (copied, readonly)
			[3]: arg1 (readonly)
			[4]: arg2 (readonly)
			[5]: arg3 (readonly)
			[6]: var1_result1_upvr_4 (copied, readonly)
		]]
		-- KONSTANTERROR: [0] 1. Error Block 14 start (CF ANALYSIS FAILED)
		local any_new_result1_6_upvr = var1_result1_upvr_3.new()
		local var24_upvw = any_named_result1_upvr
		any_new_result1_6_upvr:GiveTask(arg1:GetPropertyChangedSignal(arg2):Connect(function() -- Line 117, Named "handlePropertyChanged"
			--[[ Upvalues[7]:
				[1]: arg1 (copied, readonly)
				[2]: arg2 (copied, readonly)
				[3]: var24_upvw (read and write)
				[4]: arg3 (copied, readonly)
				[5]: var1_result1_upvr_4 (copied, readonly)
				[6]: any_new_result1_6_upvr (readonly)
				[7]: arg1_4 (readonly)
			]]
			-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [13] 13. Error Block 9 start (CF ANALYSIS FAILED)
			local any_new_result1_18 = var1_result1_upvr_4.new(arg1[arg2])
			any_new_result1_6_upvr._lastBrio = any_new_result1_18
			-- KONSTANTERROR: [13] 13. Error Block 9 end (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [34] 29. Error Block 7 start (CF ANALYSIS FAILED)
			any_new_result1_6_upvr._lastBrio = nil
			-- KONSTANTERROR: [34] 29. Error Block 7 end (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [38] 32. Error Block 8 start (CF ANALYSIS FAILED)
			-- KONSTANTERROR: [38] 32. Error Block 8 end (CF ANALYSIS FAILED)
		end))
		local var26 = arg1[arg2]
		if var24_upvw ~= var26 then
			var24_upvw = var26
			if not arg3 or arg3(var26) then
				local any_new_result1_12 = var1_result1_upvr_4.new(arg1[arg2])
				any_new_result1_6_upvr._lastBrio = any_new_result1_12
				if any_new_result1_6_upvr._lastBrio == any_new_result1_12 then
					arg1_4:Fire(any_new_result1_12)
					-- KONSTANTWARNING: GOTO [58] #48
				end
			else
				any_new_result1_6_upvr._lastBrio = nil
			end
		end
		-- KONSTANTERROR: [0] 1. Error Block 14 end (CF ANALYSIS FAILED)
		-- KONSTANTERROR: [58] 48. Error Block 9 start (CF ANALYSIS FAILED)
		do
			return any_new_result1_6_upvr
		end
		-- KONSTANTERROR: [58] 48. Error Block 9 end (CF ANALYSIS FAILED)
	end
	return var22.new(var22)
end
function module_upvr.observeLastNamedChildBrio(arg1, arg2, arg3) -- Line 156
	--[[ Upvalues[3]:
		[1]: var1_result1_upvr (readonly)
		[2]: var1_result1_upvr_3 (readonly)
		[3]: var1_result1_upvr_4 (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 20 start (CF ANALYSIS FAILED)
	local var29
	if typeof(arg1) ~= "Instance" then
		var29 = false
	else
		var29 = true
	end
	assert(var29, "Bad parent")
	if type(arg2) ~= "string" then
		var29 = false
		-- KONSTANTWARNING: GOTO [24] #19
	end
	-- KONSTANTERROR: [0] 1. Error Block 20 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [23] 18. Error Block 22 start (CF ANALYSIS FAILED)
	var29 = true
	assert(var29, "Bad className")
	if type(arg3) ~= "string" then
		var29 = false
	else
		var29 = true
	end
	assert(var29, "Bad name")
	var29 = var1_result1_upvr
	function var29(arg1_5) -- Line 161
		--[[ Upvalues[5]:
			[1]: var1_result1_upvr_3 (copied, readonly)
			[2]: arg2 (readonly)
			[3]: arg3 (readonly)
			[4]: var1_result1_upvr_4 (copied, readonly)
			[5]: arg1 (readonly)
		]]
		local any_new_result1_4_upvr = var1_result1_upvr_3.new()
		local function handleChild(arg1_6) -- Line 164
			--[[ Upvalues[6]:
				[1]: arg2 (copied, readonly)
				[2]: var1_result1_upvr_3 (copied, readonly)
				[3]: arg3 (copied, readonly)
				[4]: var1_result1_upvr_4 (copied, readonly)
				[5]: any_new_result1_4_upvr (readonly)
				[6]: arg1_5 (readonly)
			]]
			if not arg1_6:IsA(arg2) then
			else
				local any_new_result1_3_upvr = var1_result1_upvr_3.new()
				local function handleNameChanged() -- Line 171
					--[[ Upvalues[6]:
						[1]: arg1_6 (readonly)
						[2]: arg3 (copied, readonly)
						[3]: var1_result1_upvr_4 (copied, readonly)
						[4]: any_new_result1_3_upvr (readonly)
						[5]: any_new_result1_4_upvr (copied, readonly)
						[6]: arg1_5 (copied, readonly)
					]]
					if arg1_6.Name == arg3 then
						local any_new_result1_16 = var1_result1_upvr_4.new(arg1_6)
						any_new_result1_3_upvr._brio = any_new_result1_16
						any_new_result1_4_upvr._lastBrio = any_new_result1_16
						arg1_5:Fire(any_new_result1_16)
					else
						any_new_result1_3_upvr._brio = nil
					end
				end
				any_new_result1_3_upvr:GiveTask(arg1_6:GetPropertyChangedSignal("Name"):Connect(handleNameChanged))
				if arg1_6.Name == arg3 then
					local any_new_result1_14 = var1_result1_upvr_4.new(arg1_6)
					any_new_result1_3_upvr._brio = any_new_result1_14
					any_new_result1_4_upvr._lastBrio = any_new_result1_14
					arg1_5:Fire(any_new_result1_14)
				else
					any_new_result1_3_upvr._brio = nil
				end
				any_new_result1_4_upvr[arg1_6] = any_new_result1_3_upvr
			end
		end
		any_new_result1_4_upvr:GiveTask(arg1.ChildAdded:Connect(handleChild))
		any_new_result1_4_upvr:GiveTask(arg1.ChildRemoved:Connect(function(arg1_7) -- Line 190
			--[[ Upvalues[1]:
				[1]: any_new_result1_4_upvr (readonly)
			]]
			any_new_result1_4_upvr[arg1_7] = nil
		end))
		for _, v in pairs(arg1:GetChildren()) do
			handleChild(v)
		end
		return any_new_result1_4_upvr
	end
	do
		return var29.new(var29)
	end
	-- KONSTANTERROR: [23] 18. Error Block 22 end (CF ANALYSIS FAILED)
end
function module_upvr.observeChildrenOfNameBrio(arg1, arg2, arg3) -- Line 210
	--[[ Upvalues[3]:
		[1]: var1_result1_upvr (readonly)
		[2]: var1_result1_upvr_3 (readonly)
		[3]: var1_result1_upvr_4 (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 20 start (CF ANALYSIS FAILED)
	local var43
	if typeof(arg1) ~= "Instance" then
		var43 = false
	else
		var43 = true
	end
	assert(var43, "Bad parent")
	if type(arg2) ~= "string" then
		var43 = false
		-- KONSTANTWARNING: GOTO [24] #19
	end
	-- KONSTANTERROR: [0] 1. Error Block 20 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [23] 18. Error Block 22 start (CF ANALYSIS FAILED)
	var43 = true
	assert(var43, "Bad className")
	if type(arg3) ~= "string" then
		var43 = false
	else
		var43 = true
	end
	assert(var43, "Bad name")
	var43 = var1_result1_upvr
	function var43(arg1_8) -- Line 215
		--[[ Upvalues[5]:
			[1]: var1_result1_upvr_3 (copied, readonly)
			[2]: arg2 (readonly)
			[3]: arg3 (readonly)
			[4]: var1_result1_upvr_4 (copied, readonly)
			[5]: arg1 (readonly)
		]]
		local any_new_result1_8_upvr = var1_result1_upvr_3.new()
		local function handleChild(arg1_9) -- Line 218
			--[[ Upvalues[6]:
				[1]: arg2 (copied, readonly)
				[2]: var1_result1_upvr_3 (copied, readonly)
				[3]: arg3 (copied, readonly)
				[4]: var1_result1_upvr_4 (copied, readonly)
				[5]: arg1_8 (readonly)
				[6]: any_new_result1_8_upvr (readonly)
			]]
			if not arg1_9:IsA(arg2) then
			else
				local any_new_result1_2_upvr = var1_result1_upvr_3.new()
				any_new_result1_2_upvr:GiveTask(arg1_9:GetPropertyChangedSignal("Name"):Connect(function() -- Line 225, Named "handleNameChanged"
					--[[ Upvalues[5]:
						[1]: arg1_9 (readonly)
						[2]: arg3 (copied, readonly)
						[3]: var1_result1_upvr_4 (copied, readonly)
						[4]: any_new_result1_2_upvr (readonly)
						[5]: arg1_8 (copied, readonly)
					]]
					if arg1_9.Name == arg3 then
						local any_new_result1_10 = var1_result1_upvr_4.new(arg1_9)
						any_new_result1_2_upvr._brio = any_new_result1_10
						arg1_8:Fire(any_new_result1_10)
					else
						any_new_result1_2_upvr._brio = nil
					end
				end))
				if arg1_9.Name == arg3 then
					local any_new_result1_5 = var1_result1_upvr_4.new(arg1_9)
					any_new_result1_2_upvr._brio = any_new_result1_5
					arg1_8:Fire(any_new_result1_5)
				else
					any_new_result1_2_upvr._brio = nil
				end
				any_new_result1_8_upvr[arg1_9] = any_new_result1_2_upvr
			end
		end
		any_new_result1_8_upvr:GiveTask(arg1.ChildAdded:Connect(handleChild))
		any_new_result1_8_upvr:GiveTask(arg1.ChildRemoved:Connect(function(arg1_10) -- Line 243
			--[[ Upvalues[1]:
				[1]: any_new_result1_8_upvr (readonly)
			]]
			any_new_result1_8_upvr[arg1_10] = nil
		end))
		for _, v_2 in pairs(arg1:GetChildren()) do
			handleChild(v_2)
		end
		return any_new_result1_8_upvr
	end
	do
		return var43.new(var43)
	end
	-- KONSTANTERROR: [23] 18. Error Block 22 end (CF ANALYSIS FAILED)
end
function module_upvr.observeChildrenOfClassBrio(arg1, arg2) -- Line 262
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	local var56
	if typeof(arg1) ~= "Instance" then
		var56 = false
	else
		var56 = true
	end
	assert(var56, "Bad parent")
	if type(arg2) ~= "string" then
		var56 = false
	else
		var56 = true
	end
	assert(var56, "Bad className")
	var56 = module_upvr
	var56 = arg1
	return var56.observeChildrenBrio(var56, function(arg1_11) -- Line 266
		--[[ Upvalues[1]:
			[1]: arg2 (readonly)
		]]
		return arg1_11:IsA(arg2)
	end)
end
function module_upvr.observeChildrenBrio(arg1, arg2) -- Line 278
	--[[ Upvalues[3]:
		[1]: var1_result1_upvr (readonly)
		[2]: var1_result1_upvr_3 (readonly)
		[3]: var1_result1_upvr_4 (readonly)
	]]
	local var59
	if typeof(arg1) ~= "Instance" then
		var59 = false
	else
		var59 = true
	end
	assert(var59, "Bad parent")
	var59 = true
	if type(arg2) ~= "function" then
		if arg2 ~= nil then
			var59 = false
		else
			var59 = true
		end
	end
	assert(var59, "Bad predicate")
	var59 = var1_result1_upvr
	function var59(arg1_12) -- Line 282
		--[[ Upvalues[4]:
			[1]: var1_result1_upvr_3 (copied, readonly)
			[2]: arg2 (readonly)
			[3]: var1_result1_upvr_4 (copied, readonly)
			[4]: arg1 (readonly)
		]]
		local any_new_result1_upvr = var1_result1_upvr_3.new()
		any_new_result1_upvr:GiveTask(arg1.ChildAdded:Connect(function(arg1_13) -- Line 285, Named "handleChild"
			--[[ Upvalues[4]:
				[1]: arg2 (copied, readonly)
				[2]: var1_result1_upvr_4 (copied, readonly)
				[3]: any_new_result1_upvr (readonly)
				[4]: arg1_12 (readonly)
			]]
			if not arg2 or arg2(arg1_13) then
				local any_new_result1 = var1_result1_upvr_4.new(arg1_13)
				any_new_result1_upvr[arg1_13] = any_new_result1
				arg1_12:Fire(any_new_result1)
			end
		end))
		any_new_result1_upvr:GiveTask(arg1.ChildRemoved:Connect(function(arg1_14) -- Line 294
			--[[ Upvalues[1]:
				[1]: any_new_result1_upvr (readonly)
			]]
			any_new_result1_upvr[arg1_14] = nil
		end))
		for _, v_3 in pairs(arg1:GetChildren()) do
			if not arg2 or arg2(v_3) then
				local any_new_result1_11 = var1_result1_upvr_4.new(v_3)
				any_new_result1_upvr[v_3] = any_new_result1_11
				arg1_12:Fire(any_new_result1_11)
			end
		end
		return any_new_result1_upvr
	end
	return var59.new(var59)
end
function module_upvr.observeDescendants(arg1, arg2) -- Line 313
	--[[ Upvalues[2]:
		[1]: var1_result1_upvr (readonly)
		[2]: var1_result1_upvr_3 (readonly)
	]]
	local var70
	if typeof(arg1) ~= "Instance" then
		var70 = false
	else
		var70 = true
	end
	assert(var70, "Bad parent")
	var70 = true
	if type(arg2) ~= "function" then
		if arg2 ~= nil then
			var70 = false
		else
			var70 = true
		end
	end
	assert(var70, "Bad predicate")
	var70 = var1_result1_upvr
	function var70(arg1_15) -- Line 317
		--[[ Upvalues[3]:
			[1]: var1_result1_upvr_3 (copied, readonly)
			[2]: arg2 (readonly)
			[3]: arg1 (readonly)
		]]
		local any_new_result1_9 = var1_result1_upvr_3.new()
		local tbl_upvr = {}
		any_new_result1_9:GiveTask(arg1.DescendantAdded:Connect(function(arg1_16) -- Line 321, Named "handleDescendant"
			--[[ Upvalues[3]:
				[1]: arg2 (copied, readonly)
				[2]: tbl_upvr (readonly)
				[3]: arg1_15 (readonly)
			]]
			if not arg2 or arg2(arg1_16) then
				tbl_upvr[arg1_16] = true
				arg1_15:Fire(arg1_16, true)
			end
		end))
		any_new_result1_9:GiveTask(arg1.DescendantRemoving:Connect(function(arg1_17) -- Line 329
			--[[ Upvalues[2]:
				[1]: tbl_upvr (readonly)
				[2]: arg1_15 (readonly)
			]]
			if tbl_upvr[arg1_17] then
				tbl_upvr[arg1_17] = nil
				arg1_15:Fire(arg1_17, false)
			end
		end))
		for _, v_4 in pairs(arg1:GetDescendants()) do
			if not arg2 or arg2(v_4) then
				tbl_upvr[v_4] = true
				arg1_15:Fire(v_4, true)
			end
		end
		return any_new_result1_9
	end
	return var70.new(var70)
end
return module_upvr