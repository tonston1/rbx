-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:51:28
-- Luau version 6, Types version 3
-- Time taken: 0.000471 seconds

local var2_upvr = require(script.Parent.loader).load(script)("Promise")
return function(arg1) -- Line 11
	--[[ Upvalues[1]:
		[1]: var2_upvr (readonly)
	]]
	return var2_upvr.new(function(arg1_2, arg2) -- Line 12
		--[[ Upvalues[1]:
			[1]: arg1 (readonly)
		]]
		task.delay(arg1, function() -- Line 13
			--[[ Upvalues[1]:
				[1]: arg1_2 (readonly)
			]]
			arg1_2()
		end)
	end)
end