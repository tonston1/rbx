-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:50:59
-- Luau version 6, Types version 3
-- Time taken: 0.002251 seconds

local module = {}
local var2_upvr = require(script.Parent.loader).load(script)("Maid")
local RunService_upvr = game:GetService("RunService")
function module.bindToBinder(arg1, arg2, arg3) -- Line 23
	--[[ Upvalues[2]:
		[1]: var2_upvr (readonly)
		[2]: RunService_upvr (readonly)
	]]
	local syncAttribute = arg3
	assert(syncAttribute, "Bad binder")
	if typeof(arg1) ~= "Instance" then
		syncAttribute = false
	else
		syncAttribute = true
	end
	assert(syncAttribute, "Bad instance")
	if type(arg2) ~= "string" then
		syncAttribute = false
	else
		syncAttribute = true
	end
	assert(syncAttribute, "Bad attributeName")
	syncAttribute = var2_upvr
	local any_new_result1_upvr = syncAttribute.new()
	function syncAttribute() -- Line 30
		--[[ Upvalues[4]:
			[1]: arg1 (readonly)
			[2]: arg2 (readonly)
			[3]: RunService_upvr (copied, readonly)
			[4]: arg3 (readonly)
		]]
		if arg1:GetAttribute(arg2) then
			if RunService_upvr:IsClient() then
				arg3:BindClient(arg1)
			else
				arg3:Bind(arg1)
			end
		end
		if RunService_upvr:IsClient() then
			arg3:UnbindClient(arg1)
		else
			arg3:Unbind(arg1)
		end
	end
	any_new_result1_upvr:GiveTask(arg1:GetAttributeChangedSignal(arg2):Connect(syncAttribute))
	any_new_result1_upvr:GiveTask(arg3:ObserveInstance(arg1, function() -- Line 47, Named "syncBoundClass"
		--[[ Upvalues[3]:
			[1]: arg3 (readonly)
			[2]: arg1 (readonly)
			[3]: arg2 (readonly)
		]]
		if arg3:Get(arg1) then
			arg1:SetAttribute(arg2, true)
		else
			arg1:SetAttribute(arg2, false)
		end
	end))
	if arg3:Get(arg1) or arg1:GetAttribute(arg2) then
		arg1:SetAttribute(arg2, true)
		if RunService_upvr:IsClient() then
			arg3:BindClient(arg1)
		else
			arg3:Bind(arg1)
		end
	else
		arg1:SetAttribute(arg2, false)
	end
	any_new_result1_upvr:GiveTask(function() -- Line 69
		--[[ Upvalues[3]:
			[1]: any_new_result1_upvr (readonly)
			[2]: arg1 (readonly)
			[3]: arg2 (readonly)
		]]
		any_new_result1_upvr:DoCleaning()
		arg1:SetAttribute(arg2, nil)
	end)
	return any_new_result1_upvr
end
function module.initAttribute(arg1, arg2, arg3) -- Line 88
	local var7
	if typeof(arg1) ~= "Instance" then
		var7 = false
	else
		var7 = true
	end
	assert(var7, "Bad instance")
	if typeof(arg2) ~= "string" then
		var7 = false
	else
		var7 = true
	end
	assert(var7, "Bad attributeName")
	local attribute = arg1:GetAttribute(arg2)
	if attribute == nil then
		var7 = arg1:SetAttribute
		var7(arg2, arg3)
		attribute = arg3
	end
	return attribute
end
function module.getAttribute(arg1, arg2, arg3) -- Line 108
	local attribute_2 = arg1:GetAttribute(arg2)
	if attribute_2 == nil then
		return arg3
	end
	return attribute_2
end
return module