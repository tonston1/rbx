-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:50:31
-- Luau version 6, Types version 3
-- Time taken: 0.002541 seconds

local module_upvr = {}
local function recurseAdd_upvr(arg1, arg2, arg3, arg4) -- Line 22, Named "recurseAdd"
	--[[ Upvalues[1]:
		[1]: recurseAdd_upvr (readonly)
	]]
	if arg3 ~= "" then
	end
	for i, v in pairs(arg4) do
		if type(v) == "table" then
			recurseAdd_upvr(arg1, arg2, arg3..'.'..i, v)
		elseif type(v) == "string" then
			local var9 = ""
			if arg2 == "en" then
				var9 = v
			end
			-- KONSTANTERROR: Expression was reused, decompilation is incorrect
			arg1:SetEntryValue(arg3..'.'..i, var9, "", arg2, v)
		else
			-- KONSTANTERROR: Expression was reused, decompilation is incorrect
			error("Bad type for value in '"..arg3..'.'..i.."'.")
		end
	end
end
function module_upvr.localeFromName(arg1) -- Line 51
	if arg1:sub(-5) == ".json" then
		return arg1:sub(1, #arg1 - 5)
	end
	return arg1
end
local LocalizationService_upvr = game:GetService("LocalizationService")
local RunService_upvr = game:GetService("RunService")
function module_upvr.getOrCreateLocalizationTable() -- Line 59
	--[[ Upvalues[2]:
		[1]: LocalizationService_upvr (readonly)
		[2]: RunService_upvr (readonly)
	]]
	local GeneratedJSONTable = LocalizationService_upvr:FindFirstChild("GeneratedJSONTable")
	if not GeneratedJSONTable then
		GeneratedJSONTable = Instance.new("LocalizationTable")
		GeneratedJSONTable.Name = "GeneratedJSONTable"
		if RunService_upvr:IsRunning() then
			GeneratedJSONTable.Parent = LocalizationService_upvr
		end
	end
	return GeneratedJSONTable
end
function module_upvr.loadFolder(arg1) -- Line 78
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: recurseAdd_upvr (readonly)
	]]
	for _, v_2 in pairs(arg1:GetDescendants()) do
		if v_2:IsA("StringValue") then
			module_upvr.addJsonToTable(module_upvr.getOrCreateLocalizationTable(), module_upvr.localeFromName(v_2.Name), v_2.Value)
		elseif v_2:IsA("ModuleScript") then
			-- KONSTANTERROR: Expression was reused, decompilation is incorrect
			recurseAdd_upvr(module_upvr.getOrCreateLocalizationTable(), module_upvr.localeFromName(v_2.Name), "", require(v_2))
		end
	end
	-- KONSTANTERROR: Expression was reused, decompilation is incorrect
	return module_upvr.getOrCreateLocalizationTable()
end
function module_upvr.toLocalizationTable(arg1, arg2) -- Line 99
	--[[ Upvalues[1]:
		[1]: module_upvr (readonly)
	]]
	if typeof(arg1) == "Instance" then
		return module_upvr.loadFolder(arg1)
	end
	if type(arg1) == "string" and type(arg2) == "table" then
		return module_upvr.loadTable(arg1, arg2)
	end
	error("Bad args")
end
function module_upvr.loadTable(arg1, arg2) -- Line 118
	--[[ Upvalues[2]:
		[1]: module_upvr (readonly)
		[2]: recurseAdd_upvr (readonly)
	]]
	local any_getOrCreateLocalizationTable_result1 = module_upvr.getOrCreateLocalizationTable()
	recurseAdd_upvr(any_getOrCreateLocalizationTable_result1, arg1, "", arg2)
	return any_getOrCreateLocalizationTable_result1
end
local HttpService_upvr = game:GetService("HttpService")
function module_upvr.addJsonToTable(arg1, arg2, arg3) -- Line 132
	--[[ Upvalues[2]:
		[1]: HttpService_upvr (readonly)
		[2]: recurseAdd_upvr (readonly)
	]]
	recurseAdd_upvr(arg1, arg2, "", HttpService_upvr:JSONDecode(arg3))
end
return module_upvr