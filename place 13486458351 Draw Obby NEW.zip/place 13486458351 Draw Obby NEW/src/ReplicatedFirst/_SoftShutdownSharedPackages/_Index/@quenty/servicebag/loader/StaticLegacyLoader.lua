-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:50:50
-- Luau version 6, Types version 3
-- Time taken: 0.005673 seconds

local ScriptInfoUtils_upvr = require(script.Parent.ScriptInfoUtils)
local module_2_upvr = {
	ClassName = "StaticLegacyLoader";
}
module_2_upvr.__index = module_2_upvr
function module_2_upvr.new() -- Line 15
	--[[ Upvalues[1]:
		[1]: module_2_upvr (readonly)
	]]
	return setmetatable({
		_packageLookups = {};
	}, module_2_upvr)
end
local function __call(arg1, arg2) -- Line 23
	return arg1:Require(arg2)
end
module_2_upvr.__call = __call
function module_2_upvr.Lock(arg1) -- Line 27
	error("Cannot start loader while not running")
end
function module_2_upvr.Require(arg1, arg2, arg3) -- Line 31
	if type(arg3) == "number" then
		return require(arg3)
	end
	if type(arg3) == "string" then
		local any__findModule_result1 = arg1:_findModule(arg2, arg3)
		if any__findModule_result1 then
			arg1:_ensureFakeLoader(any__findModule_result1)
			return require(any__findModule_result1)
		end
		error("Error: Library '"..tostring(arg3).."' does not exist.", 2)
	else
		if typeof(arg3) == "Instance" and arg3:IsA("ModuleScript") then
			return require(arg3)
		end
		error("Error: module must be a string or ModuleScript, got '%s' for '%s'":format(typeof(arg3), tostring(arg3)))
	end
end
function module_2_upvr._findModule(arg1, arg2, arg3) -- Line 51
	--[[ Upvalues[1]:
		[1]: ScriptInfoUtils_upvr (readonly)
	]]
	local var13
	if typeof(arg2) ~= "Instance" then
		var13 = false
	else
		var13 = true
	end
	assert(var13, "Bad root")
	if type(arg3) ~= "string" then
		var13 = false
	else
		var13 = true
	end
	assert(var13, "Bad name")
	local any__findPackageRoot_result1 = arg1:_findPackageRoot(arg2)
	while any__findPackageRoot_result1 do
		var13 = arg1:_getOrCreateLookup(any__findPackageRoot_result1)
		if var13[arg3] then
			return var13[arg3]
		end
		local SOME = any__findPackageRoot_result1:FindFirstChild(ScriptInfoUtils_upvr.DEPENDENCY_FOLDER_NAME)
		if SOME then
			for _, v in pairs(SOME:GetChildren()) do
				if v:IsA("Folder") and v.Name:sub(1, 1) == '@' then
					for _, v_2 in pairs(v:GetChildren()) do
						local any__getPackageFolderLookup_result1 = arg1:_getPackageFolderLookup(v_2)
						if any__getPackageFolderLookup_result1[arg3] then
							return any__getPackageFolderLookup_result1[arg3]
						end
					end
				else
					local any__getPackageFolderLookup_result1_2 = arg1:_getPackageFolderLookup(v)
					if any__getPackageFolderLookup_result1_2[arg3] then
						return any__getPackageFolderLookup_result1_2[arg3]
					end
				end
			end
		end
	end
	var13 = nil
	return var13
end
function module_2_upvr.GetLoader(arg1, arg2) -- Line 91
	local var24
	if typeof(arg2) ~= "Instance" then
		var24 = false
	else
		var24 = true
	end
	assert(var24, "Bad moduleScript")
	var24 = {}
	return setmetatable(var24, {
		__call = function(arg1_2, arg2_2) -- Line 95, Named "__call"
			--[[ Upvalues[2]:
				[1]: arg1 (readonly)
				[2]: arg2 (readonly)
			]]
			return arg1:Require(arg2, arg2_2)
		end;
		__index = function(arg1_3, arg2_3) -- Line 98, Named "__index"
			--[[ Upvalues[2]:
				[1]: arg1 (readonly)
				[2]: arg2 (readonly)
			]]
			return arg1:Require(arg2, arg2_3)
		end;
	})
end
function module_2_upvr._getPackageFolderLookup(arg1, arg2) -- Line 104
	if arg2:IsA("ObjectValue") then
		if arg2.Value then
			return arg1:_getOrCreateLookup(arg2.Value)
		end
		warn("[StaticLegacyLoader] - Bad link in packageFolder")
		return {}
	end
	if arg2:IsA("Folder") then
		return arg1:_getOrCreateLookup(arg2)
	end
	if arg2:IsA("ModuleScript") then
		return arg1:_getOrCreateLookup(arg2)
	end
	warn("Unknown instance %q (%s) in dependencyFolder - %q":format(arg2.Name, arg2.ClassName, arg2:GetFullName()))
	return {}
end
function module_2_upvr._getOrCreateLookup(arg1, arg2) -- Line 123
	local var26
	if typeof(arg2) ~= "Instance" then
		var26 = false
	else
		var26 = true
	end
	assert(var26, "Bad packageFolderOrModuleScript")
	var26 = arg1._packageLookups
	if var26[arg2] then
		var26 = arg1._packageLookups
		return var26[arg2]
	end
	local module = {}
	var26 = arg1:_buildLookup
	var26(module, arg2)
	var26 = arg1._packageLookups
	var26[arg2] = module
	return module
end
function module_2_upvr._buildLookup(arg1, arg2, arg3) -- Line 138
	--[[ Upvalues[1]:
		[1]: ScriptInfoUtils_upvr (readonly)
	]]
	-- KONSTANTERROR: [0] 1. Error Block 1 start (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [0] 1. Error Block 1 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [12] 9. Error Block 12 start (CF ANALYSIS FAILED)
	for _, v_3 in pairs(arg3:GetChildren()) do
		arg1:_buildLookup(arg2, v_3)
	end
	do
		return
	end
	-- KONSTANTERROR: [12] 9. Error Block 12 end (CF ANALYSIS FAILED)
	-- KONSTANTERROR: [27] 20. Error Block 9 start (CF ANALYSIS FAILED)
	if arg3:IsA("ModuleScript") then
		arg2[arg3.Name] = arg3
	end
	-- KONSTANTERROR: [27] 20. Error Block 9 end (CF ANALYSIS FAILED)
end
local LoaderUtils_upvr = require(script.Parent.LoaderUtils)
function module_2_upvr._findPackageRoot(arg1, arg2) -- Line 150
	--[[ Upvalues[1]:
		[1]: LoaderUtils_upvr (readonly)
	]]
	local var34
	if typeof(arg2) ~= "Instance" then
		var34 = false
	else
		var34 = true
	end
	assert(var34, "Bad instance")
	local Parent = arg2.Parent
	while Parent do
		var34 = game
		if Parent == var34 then break end
		var34 = LoaderUtils_upvr.isPackage(Parent)
		if var34 then
			return Parent
		end
	end
	var34 = nil
	return var34
end
local BounceTemplateUtils_upvr = require(script.Parent.BounceTemplateUtils)
local Parent_2_upvr = script.Parent
function module_2_upvr._ensureFakeLoader(arg1, arg2) -- Line 166
	--[[ Upvalues[2]:
		[1]: BounceTemplateUtils_upvr (readonly)
		[2]: Parent_2_upvr (readonly)
	]]
	local var38
	if typeof(arg2) ~= "Instance" then
		var38 = false
	else
		var38 = true
	end
	assert(var38, "Bad module")
	local Parent_3 = arg2.Parent
	if not Parent_3 then
		var38 = warn
		var38("[StaticLegacyLoader] - No parent")
	else
		if Load then
			var38 = true
		else
			var38 = false
		end
		local loader = Parent_3:FindFirstChild("loader")
		if loader then
			if BounceTemplateUtils_upvr.isBounceTemplate(loader) then
				loader.Archivable = var38
			end
			return
		end
		local any_create_result1 = BounceTemplateUtils_upvr.create(Parent_2_upvr, "loader")
		any_create_result1.Archivable = var38
		any_create_result1.Parent = Parent_3
	end
end
return module_2_upvr