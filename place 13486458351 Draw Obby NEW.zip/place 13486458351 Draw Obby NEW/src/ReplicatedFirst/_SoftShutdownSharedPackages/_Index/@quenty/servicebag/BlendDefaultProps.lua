-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:50:53
-- Luau version 6, Types version 3
-- Time taken: 0.001259 seconds

return {
	ScreenGui = {
		ResetOnSpawn = false;
		ZIndexBehavior = "Sibling";
	};
	BillboardGui = {
		ResetOnSpawn = false;
		ZIndexBehavior = "Sibling";
	};
	SurfaceGui = {
		ResetOnSpawn = false;
		ZIndexBehavior = "Sibling";
		SizingMode = "PixelsPerStud";
		PixelsPerStud = 50;
	};
	Frame = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
	};
	ScrollingFrame = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
		ScrollBarImageColor3 = Color3.new(0, 0, 0);
	};
	TextLabel = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
		Font = "SourceSans";
		Text = "";
		TextColor3 = Color3.new(0, 0, 0);
		TextSize = 14;
	};
	TextButton = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
		AutoButtonColor = false;
		Font = "SourceSans";
		Text = "";
		TextColor3 = Color3.new(0, 0, 0);
		TextSize = 14;
	};
	TextBox = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
		ClearTextOnFocus = false;
		Font = "SourceSans";
		Text = "";
		TextColor3 = Color3.new(0, 0, 0);
		TextSize = 14;
	};
	ImageLabel = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
	};
	ImageButton = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
		AutoButtonColor = false;
	};
	ViewportFrame = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
	};
	VideoFrame = {
		BackgroundColor3 = Color3.new(1, 1, 1);
		BorderColor3 = Color3.new(0, 0, 0);
		BorderSizePixel = 0;
	};
	UIListLayout = {
		SortOrder = Enum.SortOrder.LayoutOrder;
	};
}