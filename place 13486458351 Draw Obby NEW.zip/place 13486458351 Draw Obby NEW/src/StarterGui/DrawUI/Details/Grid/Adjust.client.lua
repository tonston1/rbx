-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:15
-- Luau version 6, Types version 3
-- Time taken: 0.000313 seconds

script.Parent:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- Line 1
	script.Parent.TileSize = UDim2.new(0, script.Parent.AbsoluteSize.X / 10, 0, script.Parent.AbsoluteSize.X / 10)
end)