-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-10-18 23:53:16
-- Luau version 6, Types version 3
-- Time taken: 0.000747 seconds

local TweenService = game:GetService("TweenService")
local Frame = script.Parent:WaitForChild("Frame")
while true do
	for _, v in ipairs({Frame:WaitForChild("Left"), Frame:WaitForChild("Middle"), Frame:WaitForChild("Right")}) do
		TweenService:Create(v, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true, 0), {
			Position = UDim2.new(v.Position.X.Scale, 0, 0.47, 0);
		}):Play()
		task.wait(0.3)
	end
	task.wait(0.25)
end